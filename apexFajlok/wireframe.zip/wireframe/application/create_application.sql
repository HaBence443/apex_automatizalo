prompt --application/create_application

begin

--   Manifest

--     FLOW: 200

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp.create_flow(

 p_id=>wwv_flow.g_flow_id

,p_owner=>nvl(wwv_flow_application_install.get_schema,'HOTEL_APP')

,p_name=>nvl(wwv_flow_application_install.get_application_name,'Általános irat adatok megadása')

,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'FRM_ELJ0221')

,p_page_view_logging=>'YES'

,p_checksum_salt_last_reset=>'20260326194837'

,p_bookmark_checksum_function=>'MD5'

,p_compatibility_mode=>'21.2'

,p_theme_id=>42

,p_flow_language=>'hu'

,p_flow_language_derived_from=>'0'

,p_direction_right_to_left=>'N'

,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')

,p_authentication_id=>wwv_flow_imp.id(450099302331286875)

,p_application_tab_set=>0

,p_logo_type=>'T'

,p_logo_text=>'Általános irat adatok megadása'

,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')

,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')

,p_flow_status=>'AVAILABLE_W_EDIT_LINK'

,p_exact_substitutions_only=>'N'

,p_rejoin_existing_sessions=>'N'

,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')

,p_print_server_type=>'NATIVE'

,p_is_pwa=>'N'

,p_vpd=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_TERRITORY = ''''HUNGARY'''''';',
'  EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '''', '''''';',
'  EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_DATE_FORMAT = ''''YYYY.MM.DD'''''';',
'END;'))

);

wwv_flow_imp.component_end;

end;

/

