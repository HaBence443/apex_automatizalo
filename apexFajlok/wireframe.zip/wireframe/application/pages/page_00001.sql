

prompt --application/pages/page_00001

begin

wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>1800494358559161
,p_default_application_id=>9230
,p_default_id_offset=>80000000000000000
,p_default_owner=>'NAV'
);

wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Általános irat adatok megadása'
,p_alias=>'WINDOW'
,p_step_title=>'Általános irat adatok megadása'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_javascript_code_onload=>q'|var header=document.querySelector(".t-Header"); if(header){header.style.position="relative"; var tag=document.createElement("span"); tag.style.cssText="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:0.9em;color:#cccccc;pointer-events:none;white-space:nowrap;"; tag.textContent="&APP_ALIAS."; header.appendChild(tag);}|'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'N'
,p_page_component_map=>'13'
);



wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000300)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000301)
,p_name=>'P1_FR_bbc9_UGYSZAM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'Ügyszám'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000302)
,p_name=>'P1_FR_bbc9_DOK_UGYFEL_APEH_KULCS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'Ügyfél'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000303)
,p_name=>'P1_FR_bbc9_VPID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'VPID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000304)
,p_name=>'P1_FR_bbc9_DOK_UGYFEL_NEV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'Név'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>9
,p_cSize=>30
,p_cMaxlength=>250
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000400)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000401)
,p_name=>'P1_FR_3253_ETS_MEGNEVEZES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000400)
,p_prompt=>'Eljárás típus'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>9
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000402)
,p_name=>'P1_FR_3253_UGY_KEZDET_DAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000400)
,p_prompt=>'Ügykezdet dátuma'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000403)
,p_name=>'P1_FR_3253_USSZ_MEGNEVEZES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000000400)
,p_prompt=>'Ügy állapota'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000600)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>3
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000601)
,p_name=>'P1_FR_2bbe_DOK_BARKOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000600)
,p_prompt=>'Iktatószám'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000602)
,p_name=>'P1_FR_2bbe_ICST_MEGNEVEZES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000600)
,p_prompt=>'Irat csoport'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-fld-readonly'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
,p_read_only_when_type=>'ALWAYS'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000700)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000701)
,p_name=>'P1_FR_5e7e_orphans_1_KELTEZES_DAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_prompt=>'Keltezés'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date'
,p_begin_on_new_line=>'Y'
,p_colspan=>3
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000702)
,p_name=>'P1_FR_5e7e_orphans_1_ISSZ_MEGNEVEZES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_prompt=>'Irat állapota'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000703)
,p_name=>'P1_FR_5e7e_orphans_1_BEEMELT_IRAT_JEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_prompt=>'Rendszeren kívül készült (beemelt) irat'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_tag_css_classes=>'app-fld-readonly'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_lov=>'STATIC2:I;I,N;N'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
,p_read_only_when_type=>'ALWAYS'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000704)
,p_name=>'P1_FR_5e7e_orphans_1_DOK_IRATTIPUS_KOD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_prompt=>'Irat típus'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>1
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000705)
,p_name=>'P1_FR_5e7e_orphans_1_IRAT_TIPUS_NEV'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_prompt=>''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-fld-readonly'
,p_begin_on_new_line=>'N'
,p_colspan=>11
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
,p_read_only_when_type=>'ALWAYS'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000800)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000801)
,p_name=>'P1_FR_253d_DOK_UGYINTEZO_KOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000800)
,p_prompt=>'Ügyintéző'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>2
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000802)
,p_name=>'P1_FR_253d_DOK_UGYINTEZO_NEV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000800)
,p_prompt=>''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>10
,p_cSize=>30
,p_cMaxlength=>400
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000803)
,p_name=>'P1_FR_253d_DOK_JOVAHAGYO_KOD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000000800)
,p_prompt=>'Jóváhagyó'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>2
,p_is_required=>true
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(450183409494277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000804)
,p_name=>'P1_FR_253d_DOK_JOVAHAGYO_NEV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000000800)
,p_prompt=>''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>10
,p_cSize=>30
,p_cMaxlength=>400
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000901)
,p_name=>'P1_FR_1d5f_JOVAHAGYAS_DOKUBAN_JEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_prompt=>'Jóváhagyás (láttamozás) a DOKU-ban'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'Y'
,p_colspan=>8
,p_grid_label_column_span=>0
,p_is_required=>true
,p_lov=>'STATIC2:Jóváhagyás (láttamozás) a DOKU-ban;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000952)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_button_name=>'P1_FR_1d5f_BTN_LATTAM'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Láttamozók karbantartása'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000903)
,p_name=>'P1_FR_1d5f_IRATMINTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_prompt=>'Iratminta'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_is_required=>true
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183409494277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000904)
,p_name=>'P1_FR_1d5f_KMA_MEGNEVEZES'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_prompt=>'Kézbesítés módja'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_is_required=>true
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(450183409494277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001000)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>100
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001001)
,p_name=>'P1_FR_686e_DOK_FELADO_NEV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>'Feladó'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_is_required=>true
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>250
,p_field_template=>wwv_flow_imp.id(450183409494277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001002)
,p_name=>'P1_FR_686e_DOK_FELADO_CIM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>'Feladó címe'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_is_required=>true
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183409494277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001100)
,p_plug_name=>'Címzett az iraton'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001200)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>120
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS CIMZETT_APEH_KULCS, number_col1 AS CIMZETT_KRPS_AZON, varchar_col2 AS CIMZETT_ASZ_KOD, varchar_col3 AS CIMZETT_NEV, varchar_col4 AS E_UGYINTEZESRE_KOT, varchar_col5 AS CIMZETT_CIM FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000001201)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000001201
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001201)
,p_db_column_name=>'CIMZETT_APEH_KULCS'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Adóalany'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001202)
,p_db_column_name=>'CIMZETT_KRPS_AZON'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'KÉR partner'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001203)
,p_db_column_name=>'CIMZETT_ASZ_KOD'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Szervezet'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001204)
,p_db_column_name=>'CIMZETT_NEV'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'Név'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001205)
,p_db_column_name=>'E_UGYINTEZESRE_KOT'
,p_display_order=>50
,p_column_identifier=>'COL05'
,p_column_label=>'E_UGYINTEZESRE_KOT'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001206)
,p_db_column_name=>'CIMZETT_CIM'
,p_display_order=>60
,p_column_identifier=>'COL06'
,p_column_label=>'Cím'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000001202)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_12'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CIMZETT_APEH_KULCS:CIMZETT_KRPS_AZON:CIMZETT_ASZ_KOD:CIMZETT_NEV:E_UGYINTEZESRE_KOT:CIMZETT_CIM'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001300)
,p_plug_name=>'Kézbesítés információk'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>130
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001400)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>140
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001451)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_USER_DEFINED1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'1'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001452)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_USER_DEFINED2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'2'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001453)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_USER_DEFINED3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'3'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001454)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_USER_DEFINED4'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'4'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001455)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_USER_DEFINED5'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'5'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001456)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_VISSZA'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Vissza'
,p_icon_css_classes=>'fa-undo-arrow'
,p_button_css_classes=>'btn-cat-vissza-elozmeny'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001407)
,p_name=>'P1_FR_c5fb_LEHETSEGES_TEVEKENYSEGEK'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_prompt=>''
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_lov=>'STATIC2:1;1'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001458)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_c5fb_OK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'OK'
,p_icon_css_classes=>'fa-check-circle-o'
,p_button_css_classes=>'btn-cat-pozitiv-muvelet'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001500)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>150
,p_query_type=>'SQL'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001600)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>160
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS CIMZETT_NEV, varchar_col2 AS KBS_ALLAPOT, varchar_col3 AS KBS_TIPUS, varchar_col4 AS CIMZETT_CIM, date_col1 AS ATVETEL_DAT FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000001601)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000001601
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001601)
,p_db_column_name=>'CIMZETT_NEV'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Címzett'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001602)
,p_db_column_name=>'KBS_ALLAPOT'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'Kézbesítés állapota'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001603)
,p_db_column_name=>'KBS_TIPUS'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Kézbesítés típusa'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001604)
,p_db_column_name=>'CIMZETT_CIM'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'Cím'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001605)
,p_db_column_name=>'ATVETEL_DAT'
,p_display_order=>50
,p_column_identifier=>'COL05'
,p_column_label=>'Átvétel'
,p_column_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'CENTER'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000001602)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_16'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CIMZETT_NEV:KBS_ALLAPOT:KBS_TIPUS:CIMZETT_CIM:ATVETEL_DAT'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001700)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>170
,p_query_type=>'SQL'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001800)
,p_plug_name=>'Kézbesítés információk'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>180
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001700)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001900)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>190
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS KPCIM_TIPUS_MEGNEVEZES, varchar_col2 AS CIMZETT, varchar_col3 AS CIM, varchar_col4 AS UBI_KIJELOLT FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001800)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000001901)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000001901
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001901)
,p_db_column_name=>'KPCIM_TIPUS_MEGNEVEZES'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Típus'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001902)
,p_db_column_name=>'CIMZETT'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'Címzett'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001903)
,p_db_column_name=>'CIM'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Cím'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001904)
,p_db_column_name=>'UBI_KIJELOLT'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'UBI_KIJELOLT'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000001902)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_19'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'KPCIM_TIPUS_MEGNEVEZES:CIMZETT:CIM:UBI_KIJELOLT'
);


wwv_flow_imp.component_end;

end;

/
