prompt --application/pages/page_00000

begin

wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1471193222291710
,p_default_application_id=>300
,p_default_id_offset=>70000000000000000
,p_default_owner=>'HOTEL_APP'
);

wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);

wwv_flow_imp.component_end;

end;

/
