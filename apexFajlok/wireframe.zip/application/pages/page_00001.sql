

prompt --application/pages/page_00001

begin

wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>1800494358559161
,p_default_application_id=>9300
,p_default_id_offset=>80000000000000000
,p_default_owner=>'NAV'
);

wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Határozatkészítés'
,p_alias=>'WINDOW'
,p_step_title=>'Határozatkészítés'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_javascript_code_onload=>q'|var showAll=document.querySelector(".apex-rds a[href='#SHOW_ALL']"); if(showAll){showAll.querySelector("span").textContent="Mindent mutat"; showAll.click();} var header=document.querySelector(".t-Header"); if(header){header.style.position="relative"; var tag=document.createElement("span"); tag.style.cssText="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:0.9em;color:#cccccc;pointer-events:none;white-space:nowrap;"; tag.textContent="&APP_ALIAS."; header.appendChild(tag);}|'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'N'
,p_page_component_map=>'13'
);



wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000300)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>6
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000301)
,p_name=>'P1_FR_a29a_UGYSZAM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'Ügyszám'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>4
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000302)
,p_name=>'P1_FR_a29a_DOK_UGYFEL_APEH_KULCS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'Ügyfél'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000303)
,p_name=>'P1_FR_a29a_VPID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000000300)
,p_prompt=>'VPID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000400)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000401)
,p_name=>'P1_FR_ef6a_orphans_1_DOK_UGYFEL_NEV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000400)
,p_prompt=>'Név'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>6
,p_cSize=>30
,p_cMaxlength=>250
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000500)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>8
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000501)
,p_name=>'P1_FR_3c65_ETS_MEGNEVEZES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000500)
,p_prompt=>'Eljárás típus'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000600)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000200)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000601)
,p_name=>'P1_FR_ef6a_orphans_2_UGY_KEZDET_DAT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000000600)
,p_prompt=>'Ügykezdet dátuma'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date'
,p_begin_on_new_line=>'Y'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000602)
,p_name=>'P1_FR_ef6a_orphans_2_USSZ_MEGNEVEZES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000000600)
,p_prompt=>'Ügy állapota'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000700)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000751)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_USER_DEFINED1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'1'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000752)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_USER_DEFINED2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'2'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000753)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_USER_DEFINED3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'3'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000754)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_USER_DEFINED4'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'4'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000755)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_USER_DEFINED5'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'5'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000756)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_VISSZA'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Vissza'
,p_icon_css_classes=>'fa-undo-arrow'
,p_button_css_classes=>'btn-cat-vissza-elozmeny'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000757)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_USER_DEFINED6'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'6'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000000708)
,p_name=>'P1_FR_8be9_LEHETSEGES_TEVEKENYSEGEK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_prompt=>''
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_lov=>'STATIC2:1;1'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000000759)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(500000000000000700)
,p_button_name=>'P1_FR_8be9_OK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'OK'
,p_icon_css_classes=>'fa-check-circle-o'
,p_button_css_classes=>'btn-cat-pozitiv-muvelet'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000800)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>80
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_name=>'Határozat'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001000)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>100
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001001)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_1_orphans_1_DOK_IRATTIPUS_KOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>'Irat típus'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001002)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_1_orphans_1_DOK_MEGNEVEZES_IRATTIP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>11
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001003)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_1_orphans_1_DOK_BARKOD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>'Iktatószám'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>4
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001004)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_1_orphans_1_DSP_KELTEZES_DAT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>'Határozat kelte'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date app-fld-readonly'
,p_begin_on_new_line=>'Y'
,p_colspan=>4
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_read_only_when_type=>'ALWAYS'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001005)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_1_orphans_1_REFERENCIASZAM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(500000000000001000)
,p_prompt=>'Referenciaszám'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>8
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001100)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001101)
,p_name=>'P1_FR_49f7_POTLEK_MENTES_JEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001100)
,p_prompt=>'Pótlékmentes'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'Y'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_is_required=>true
,p_lov=>'STATIC2:Pótlékmentes;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001102)
,p_name=>'P1_FR_49f7_POTLEKSZAMITAS_HATAR_DAT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000001100)
,p_prompt=>'Pótlékmentesség/jóváírás kezdete'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001153)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(500000000000001100)
,p_button_name=>'P1_FR_49f7_RIPORT_MELLEKLET'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Tételes táblázat'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001104)
,p_name=>'P1_FR_49f7_HITELKAMAT_MELLOZES_JEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000001100)
,p_prompt=>'Hitelkamat mellőzése'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'Y'
,p_colspan=>4
,p_grid_label_column_span=>0
,p_is_required=>true
,p_lov=>'STATIC2:Hitelkamat mellőzése;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001200)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>120
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001201)
,p_name=>'P1_FR_b22b_ILLETEK_MENTES_JEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001200)
,p_prompt=>'Költségmentes'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'Y'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_is_required=>true
,p_lov=>'STATIC2:Költségmentes;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001202)
,p_name=>'P1_FR_b22b_EGYEB_FELTETEL_JEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000001200)
,p_prompt=>'Egyéb feltétel'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_lov=>'STATIC2:Egyéb feltétel;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001203)
,p_name=>'P1_FR_b22b_EGYSZERUSITETT_HATAROZAT_JEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000001200)
,p_prompt=>'Egyszerűsített határozat'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_label_column_span=>0
,p_is_required=>true
,p_lov=>'STATIC2:Egyszerűsített határozat;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001204)
,p_name=>'P1_FR_b22b_VAMBIZTOSITEK_MELLOZES_JEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000001200)
,p_prompt=>'Vámbiztosíték mellőzése'
,p_display_as=>'NATIVE_CHECKBOX'
,p_begin_on_new_line=>'Y'
,p_colspan=>4
,p_grid_label_column_span=>0
,p_is_required=>true
,p_lov=>'STATIC2:Vámbiztosíték mellőzése;Y'
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183753472277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001300)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>130
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001301)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_1_orphans_2_ELBIRALAS_MODJA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001300)
,p_prompt=>'Elbírálás módja'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_tag_css_classes=>'app-amount'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_is_required=>true
,p_lov=>'STATIC2:.;B_0,mmmmmmmmmmmmmmmmmmmm;B_1,mmmmmmmmmmmmmmmmmmmm;B_2,mmmmmmmmmmmmmmmmmmmm;B_3'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183409494277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001400)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>140
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000000900)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001451)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_76c1_AUTO_DONTES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Gépi döntés'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb app-btnInline'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001452)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_76c1_TORLES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Döntési tételek törlése'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb app-btnInline'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001453)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(500000000000001400)
,p_button_name=>'P1_FR_76c1_AMIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Az adósminősítés adatai'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb app-btnInline'
,p_button_position=>'BODY'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001500)
,p_plug_name=>'Megkeresések'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>150
,p_include_in_reg_disp_sel_yn=>'Y'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001600)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>160
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS MTS_MEGNEVEZES, varchar_col2 AS ADONEM_KOD, varchar_col3 AS JOGCIM_KOD, date_col1 AS EREDETI_ESEDEKESSEG_DAT, number_col1 AS KONYVELESI_TETEL_OSSZEG, varchar_col4 AS MEGK_REGISZTRACIOS_SZAM, varchar_col5 AS MEGK_ADOSZAM, varchar_col6 AS MEGK_NEV, varchar_col7 AS MEGKERESO_VALASZ_BARKOD, varchar_col8 AS MEGKERESES_EREDMENYE FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001500)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000001601)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000001601
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001601)
,p_db_column_name=>'MTS_MEGNEVEZES'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Típus'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001602)
,p_db_column_name=>'ADONEM_KOD'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'Adó&#10;nem'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001603)
,p_db_column_name=>'JOGCIM_KOD'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Jogcím'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001604)
,p_db_column_name=>'EREDETI_ESEDEKESSEG_DAT'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'Eredeti&#10;esedékesség'
,p_column_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001605)
,p_db_column_name=>'KONYVELESI_TETEL_OSSZEG'
,p_display_order=>50
,p_column_identifier=>'COL05'
,p_column_label=>'Összeg'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001606)
,p_db_column_name=>'MEGK_REGISZTRACIOS_SZAM'
,p_display_order=>60
,p_column_identifier=>'COL06'
,p_column_label=>'Megker.&#10;reg.szám'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001607)
,p_db_column_name=>'MEGK_ADOSZAM'
,p_display_order=>70
,p_column_identifier=>'COL07'
,p_column_label=>'Adószám'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001608)
,p_db_column_name=>'MEGK_NEV'
,p_display_order=>80
,p_column_identifier=>'COL08'
,p_column_label=>'MEGK_NEV'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001609)
,p_db_column_name=>'MEGKERESO_VALASZ_BARKOD'
,p_display_order=>90
,p_column_identifier=>'COL09'
,p_column_label=>'Válasz&#10;bárkód'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000001610)
,p_db_column_name=>'MEGKERESES_EREDMENYE'
,p_display_order=>100
,p_column_identifier=>'COL10'
,p_column_label=>'Megkereső válasza'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000001602)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_16'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MTS_MEGNEVEZES:ADONEM_KOD:JOGCIM_KOD:EREDETI_ESEDEKESSEG_DAT:KONYVELESI_TETEL_OSSZEG:MEGK_REGISZTRACIOS_SZAM:MEGK_ADOSZAM:MEGK_NEV:MEGKERESO_VALASZ_BARKOD:MEGKERESES_EREDMENYE'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001700)
,p_plug_name=>'Kérelem'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>170
,p_include_in_reg_disp_sel_yn=>'Y'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001800)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>180
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001700)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>3
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001801)
,p_name=>'P1_FR_d821_HIBAKOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001800)
,p_prompt=>'Hibakód'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_begin_on_new_line=>'Y'
,p_colspan=>4
,p_lov=>'STATIC2:- - -;'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001852)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000001800)
,p_button_name=>'P1_FR_d821_ELLENORZES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Ellenőrzés'
,p_icon_css_classes=>'fa-clipboard-check-alt'
,p_button_css_classes=>'btn-cat-ellenorzes'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000001900)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>190
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001700)
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>9
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000001901)
,p_name=>'P1_FR_a55d_IXELT_DB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000001900)
,p_prompt=>'Kiválasztva'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount app-fld-readonly'
,p_begin_on_new_line=>'Y'
,p_colspan=>3
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_read_only_when_type=>'ALWAYS'
,p_format_mask=>'999G999G999G999'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001952)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000001900)
,p_button_name=>'P1_FR_a55d_CSOPORTOS_DONTES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Döntés másolása'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001953)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(500000000000001900)
,p_button_name=>'P1_FR_a55d_CSOPORTOS_TORLES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Döntések törlése'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000001954)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(500000000000001900)
,p_button_name=>'P1_FR_a55d_GLOBALIS_RESZLET'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Globális részlet'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002000)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>200
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS MTS_MEGNEVEZES, varchar_col2 AS ADONEM_KOD, varchar_col3 AS JOGCIM_KOD, date_col1 AS EREDETI_ESEDEKESSEG_DAT, number_col1 AS KONYVELESI_TETEL_OSSZEG, varchar_col4 AS BIZONYLAT_TIPUS_KOD, varchar_col5 AS TETEL_TIPUS_KOD, varchar_col6 AS ILLETEK_FAJTA_KOD, varchar_col7 AS DSPELOFORDULO_HIVATKOZO_MTS_OK, varchar_col8 AS ILLETEK_VOK_KOD, varchar_col9 AS ALAP_REFERENCIASZAM, varchar_col10 AS INGATLAN_ERTEKESITES_JOVEDELME, varchar_col11 AS JELOL, number_col2 AS ENGEDELYEZENDO_OSSZEG, number_col3 AS SORSZAM, varchar_col12 AS OBV_ERINTETT_JEL FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000001700)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000002001)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000002001
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002001)
,p_db_column_name=>'MTS_MEGNEVEZES'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Típus'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002002)
,p_db_column_name=>'ADONEM_KOD'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'Adó&#10;nem'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002003)
,p_db_column_name=>'JOGCIM_KOD'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Jogcím'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002004)
,p_db_column_name=>'EREDETI_ESEDEKESSEG_DAT'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'Eredeti esed.'
,p_column_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002005)
,p_db_column_name=>'KONYVELESI_TETEL_OSSZEG'
,p_display_order=>50
,p_column_identifier=>'COL05'
,p_column_label=>'Összeg'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002006)
,p_db_column_name=>'BIZONYLAT_TIPUS_KOD'
,p_display_order=>60
,p_column_identifier=>'COL06'
,p_column_label=>' Biz&#10; kód'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002007)
,p_db_column_name=>'TETEL_TIPUS_KOD'
,p_display_order=>70
,p_column_identifier=>'COL07'
,p_column_label=>'Tt&#10;kód'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002008)
,p_db_column_name=>'ILLETEK_FAJTA_KOD'
,p_display_order=>80
,p_column_identifier=>'COL08'
,p_column_label=>'Ill&#10;fajta'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002009)
,p_db_column_name=>'DSPELOFORDULO_HIVATKOZO_MTS_OK'
,p_display_order=>90
,p_column_identifier=>'COL09'
,p_column_label=>'Elbírálva'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002010)
,p_db_column_name=>'ILLETEK_VOK_KOD'
,p_display_order=>100
,p_column_identifier=>'COL10'
,p_column_label=>'VOK'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002011)
,p_db_column_name=>'ALAP_REFERENCIASZAM'
,p_display_order=>110
,p_column_identifier=>'COL11'
,p_column_label=>' Alap referenciaszám'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002012)
,p_db_column_name=>'INGATLAN_ERTEKESITES_JOVEDELME'
,p_display_order=>120
,p_column_identifier=>'COL12'
,p_column_label=>'Ing.'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002013)
,p_db_column_name=>'JELOL'
,p_display_order=>130
,p_column_identifier=>'COL13'
,p_column_label=>'JELOL'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002014)
,p_db_column_name=>'ENGEDELYEZENDO_OSSZEG'
,p_display_order=>140
,p_column_identifier=>'COL14'
,p_column_label=>'Engedélyezendő'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002015)
,p_db_column_name=>'SORSZAM'
,p_display_order=>150
,p_column_identifier=>'COL15'
,p_column_label=>'Sorszám'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002016)
,p_db_column_name=>'OBV_ERINTETT_JEL'
,p_display_order=>160
,p_column_identifier=>'COL16'
,p_column_label=>' ÖBV&#10; érintett'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000002002)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_20'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MTS_MEGNEVEZES:ADONEM_KOD:JOGCIM_KOD:EREDETI_ESEDEKESSEG_DAT:KONYVELESI_TETEL_OSSZEG:BIZONYLAT_TIPUS_KOD:TETEL_TIPUS_KOD:ILLETEK_FAJTA_KOD:DSPELOFORDULO_HIVATKOZO_MTS_OK:ILLETEK_VOK_KOD:ALAP_REFERENCIASZAM:INGATLAN_ERTEKESITES_JOVEDELME:JELOL:ENGEDELYEZENDO_OSSZEG:SORSZAM:OBV_ERINTETT_JEL'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002100)
,p_plug_name=>'Tételek'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>210
,p_include_in_reg_disp_sel_yn=>'Y'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002200)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>220
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000002100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002201)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_MTS_MEGNEVEZES_DSP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Típus'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'Y'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002202)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_ADONEM_KOD_DSP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Adó-&#10;nem'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>3
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002203)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_JOGCIM_KOD_DSP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Jogcím'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>240
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002204)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_ADONEM_NEV_DSP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Megnevezés'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>250
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002205)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_EREDETI_ESEDEKESSEG_DAT_DSP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Eredeti&#10;esedékesség'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002206)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_KONYVELESI_TETEL_OSSZEG_DSP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Összeg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_format_mask=>'999G999G999G999G990'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002207)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_ILLETEK_FAJTA_KOD_DSP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Illeték&#10;fajta'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>1
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002208)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_ILLETEK_VOK_KOD_DSP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'VOK'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>2
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'VARCHAR2'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002209)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_POTLEK_DSP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Pótlék'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount app-fld-readonly'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_read_only_when_type=>'ALWAYS'
,p_format_mask=>'999G999G999G990'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002210)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_1_POTLEK_KONYV_DSP'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(500000000000002200)
,p_prompt=>'Összes&#10;könyvelt pótlék'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount app-fld-readonly'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_read_only_when_type=>'ALWAYS'
,p_format_mask=>'999G999G999G990'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002300)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>230
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS MTS_MEGNEVEZES, date_col1 AS ESEDEKESSEG_DAT, number_col1 AS KONYVELESI_TETEL_OSSZEG, varchar_col2 AS FELT_MERS_JOVAIRAS_NAPJA FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000002100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>8
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000002301)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000002301
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002301)
,p_db_column_name=>'MTS_MEGNEVEZES'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Típus'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002302)
,p_db_column_name=>'ESEDEKESSEG_DAT'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'Esedékesség'
,p_column_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002303)
,p_db_column_name=>'KONYVELESI_TETEL_OSSZEG'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Összeg'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002304)
,p_db_column_name=>'FELT_MERS_JOVAIRAS_NAPJA'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'Jóváírás napja'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000002302)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_23'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MTS_MEGNEVEZES:ESEDEKESSEG_DAT:KONYVELESI_TETEL_OSSZEG:FELT_MERS_JOVAIRAS_NAPJA'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002400)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>240
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000002100)
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
);


wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000002451)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(500000000000002400)
,p_button_name=>'P1_FR_77f3_ELOZO_KERELEM'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Előző kérelem tétel'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000002452)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(500000000000002400)
,p_button_name=>'P1_FR_77f3_KOVETKEZO_KERELEM'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Következő kérelem tétel'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002500)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>250
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000002100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002501)
,p_name=>'P1_FR_bcbe_ELSO_ESEDEKESSEG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000002500)
,p_prompt=>'Első esedékesség'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_tag_css_classes=>'app-date'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002502)
,p_name=>'P1_FR_bcbe_HONAPOK'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(500000000000002500)
,p_prompt=>'Hónapok'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
);

wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002503)
,p_name=>'P1_FR_bcbe_KEREKITES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(500000000000002500)
,p_prompt=>'Kerekítés'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
);

wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(500000000000002554)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(500000000000002500)
,p_button_name=>'P1_FR_bcbe_FELOSZTAS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(450185093093277003)
,p_button_image_alt=>'Részletekre osztás'
,p_icon_css_classes=>'fa-angle-right'
,p_button_css_classes=>'btn-cat-minden-egyeb'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002600)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>260
,p_query_type=>'SQL'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000002100)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);


wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(500000000000002601)
,p_name=>'P1_TP_CG_M_TAB_1_CG_M_TAB_1_PAGE_4_orphans_2_SUM_OSSZEG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(500000000000002600)
,p_prompt=>''
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_tag_css_classes=>'app-amount app-fld-readonly'
,p_begin_on_new_line=>'Y'
,p_colspan=>12
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(450183366684277001)
,p_item_template_options=>'#DEFAULT#'
,p_source_data_type=>'NUMBER'
,p_read_only_when_type=>'ALWAYS'
,p_format_mask=>'999G999G999G999G990'
);

wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002700)
,p_plug_name=>'Feltételek'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450130417347276955)
,p_plug_display_sequence=>270
,p_include_in_reg_disp_sel_yn=>'Y'
);


wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500000000000002800)
,p_plug_name=>' '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(450134743187276959)
,p_plug_display_sequence=>280
,p_query_type=>'SQL'
,p_plug_source=>'SELECT varchar_col1 AS FELTETEL_TIPUS, date_col1 AS HATARIDO_DAT, varchar_col2 AS HATARNAP, number_col1 AS HATARNAP_ELTOLAS, varchar_col3 AS FELTETEL, varchar_col4 AS ADONEM_KOD, number_col2 AS OSSZEG FROM DEMO_DATA WHERE ROWNUM <= 5'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_parent_plug_id=>wwv_flow_imp.id(500000000000002700)
,p_plug_new_grid_row=>true
,p_plug_grid_column_span=>12
);

wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(500000000000002801)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nincs megjeleníthető adat.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_internal_uid=>500000000000002801
);

wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002801)
,p_db_column_name=>'FELTETEL_TIPUS'
,p_display_order=>10
,p_column_identifier=>'COL01'
,p_column_label=>'Feltétel típus'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002802)
,p_db_column_name=>'HATARIDO_DAT'
,p_display_order=>20
,p_column_identifier=>'COL02'
,p_column_label=>'Határidő'
,p_column_type=>'DATE'
,p_format_mask=>'YYYY.MM.DD'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002803)
,p_db_column_name=>'HATARNAP'
,p_display_order=>30
,p_column_identifier=>'COL03'
,p_column_label=>'Határnap'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002804)
,p_db_column_name=>'HATARNAP_ELTOLAS'
,p_display_order=>40
,p_column_identifier=>'COL04'
,p_column_label=>'Eltolás'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002805)
,p_db_column_name=>'FELTETEL'
,p_display_order=>50
,p_column_identifier=>'COL05'
,p_column_label=>'Feltétel'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002806)
,p_db_column_name=>'ADONEM_KOD'
,p_display_order=>60
,p_column_identifier=>'COL06'
,p_column_label=>'Adónem'
,p_column_type=>'STRING'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'LEFT'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(500000000000002807)
,p_db_column_name=>'OSSZEG'
,p_display_order=>70
,p_column_identifier=>'COL07'
,p_column_label=>'Összeg'
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999'
,p_heading_alignment=>'CENTER'
,p_column_alignment=>'RIGHT'
);

wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500000000000002802)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'DEFAULT_RPT_28'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FELTETEL_TIPUS:HATARIDO_DAT:HATARNAP:HATARNAP_ELTOLAS:FELTETEL:ADONEM_KOD:OSSZEG'
);


wwv_flow_imp.component_end;

end;

/
