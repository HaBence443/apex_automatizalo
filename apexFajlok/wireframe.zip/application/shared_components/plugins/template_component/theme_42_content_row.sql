prompt --application/shared_components/plugins/template_component/theme_42_content_row
begin
null;
end;
/
