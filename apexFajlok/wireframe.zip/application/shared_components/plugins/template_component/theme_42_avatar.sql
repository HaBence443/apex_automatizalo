prompt --application/shared_components/plugins/template_component/theme_42_avatar
begin
null;
end;
/
