prompt --application/shared_components/plugins/template_component/theme_42_button
begin
null;
end;
/
