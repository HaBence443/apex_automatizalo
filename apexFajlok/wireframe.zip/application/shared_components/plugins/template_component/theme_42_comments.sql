prompt --application/shared_components/plugins/template_component/theme_42_comments
begin
null;
end;
/
