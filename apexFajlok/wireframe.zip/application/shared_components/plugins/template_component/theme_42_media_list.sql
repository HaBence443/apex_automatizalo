prompt --application/shared_components/plugins/template_component/theme_42_media_list
begin
null;
end;
/
