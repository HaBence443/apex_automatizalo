prompt --application/shared_components/globalization/language

begin

--   Manifest

--     LANGUAGE MAP: 100

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

null;

wwv_flow_imp.component_end;

end;

/

