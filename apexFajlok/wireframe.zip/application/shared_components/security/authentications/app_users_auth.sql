prompt --application/shared_components/security/authentications/app_users_auth

begin

wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0'
,p_default_workspace_id=>1471193222291710
,p_default_application_id=>300
,p_default_id_offset=>70000000000000000
,p_default_owner=>'HOTEL_APP'
);

wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(450099302331286875)
,p_name=>'No Authentication'
,p_scheme_type=>'NATIVE_DAD'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);

wwv_flow_imp.component_end;

end;
/
