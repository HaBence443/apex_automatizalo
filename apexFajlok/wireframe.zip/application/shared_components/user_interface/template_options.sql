prompt --application/shared_components/user_interface/template_options

begin

--   Manifest

--     THEME OPTIONS: 100

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450115413820276945)

,p_theme_id=>42

,p_name=>'STICKY_HEADER_ON_MOBILE'

,p_display_name=>'Sticky Header on Mobile'

,p_display_sequence=>100

,p_page_template_id=>wwv_flow_imp.id(450114292367276944)

,p_css_classes=>'js-pageStickyMobileHeader'

,p_template_types=>'PAGE'

,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450116852293276946)

,p_theme_id=>42

,p_name=>'STICKY_HEADER_ON_MOBILE'

,p_display_name=>'Sticky Header on Mobile'

,p_display_sequence=>100

,p_page_template_id=>wwv_flow_imp.id(450115511327276945)

,p_css_classes=>'js-pageStickyMobileHeader'

,p_template_types=>'PAGE'

,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450118086147276947)

,p_theme_id=>42

,p_name=>'STICKY_HEADER_ON_MOBILE'

,p_display_name=>'Sticky Header on Mobile'

,p_display_sequence=>100

,p_page_template_id=>wwv_flow_imp.id(450116937532276946)

,p_css_classes=>'js-pageStickyMobileHeader'

,p_template_types=>'PAGE'

,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450119262918276947)

,p_theme_id=>42

,p_name=>'STICKY_HEADER_ON_MOBILE'

,p_display_name=>'Sticky Header on Mobile'

,p_display_sequence=>100

,p_page_template_id=>wwv_flow_imp.id(450118183428276947)

,p_css_classes=>'js-pageStickyMobileHeader'

,p_template_types=>'PAGE'

,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450119792743276948)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>20

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'t-Dialog--noPadding'

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450119895989276948)

,p_theme_id=>42

,p_name=>'POSITION_END'

,p_display_name=>'End'

,p_display_sequence=>20

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'js-dialog-class-t-Drawer--pullOutEnd'

,p_group_id=>wwv_flow_imp.id(450107156170276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450119959878276948)

,p_theme_id=>42

,p_name=>'POSITION_START'

,p_display_name=>'Start'

,p_display_sequence=>10

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'js-dialog-class-t-Drawer--pullOutStart'

,p_group_id=>wwv_flow_imp.id(450107156170276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450120042658276948)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'js-dialog-class-t-Drawer--sm'

,p_group_id=>wwv_flow_imp.id(450106893613276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450120101756276948)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>20

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'js-dialog-class-t-Drawer--md'

,p_group_id=>wwv_flow_imp.id(450106893613276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450120221618276948)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>30

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'js-dialog-class-t-Drawer--lg'

,p_group_id=>wwv_flow_imp.id(450106893613276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450120364288276948)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_EXTRA_LARGE'

,p_display_name=>'Extra Large'

,p_display_sequence=>40

,p_page_template_id=>wwv_flow_imp.id(450119335004276947)

,p_css_classes=>'js-dialog-class-t-Drawer--xl'

,p_group_id=>wwv_flow_imp.id(450106893613276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450121738809276949)

,p_theme_id=>42

,p_name=>'STICKY_HEADER_ON_MOBILE'

,p_display_name=>'Sticky Header on Mobile'

,p_display_sequence=>100

,p_page_template_id=>wwv_flow_imp.id(450120400799276948)

,p_css_classes=>'js-pageStickyMobileHeader'

,p_template_types=>'PAGE'

,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450122221270276949)

,p_theme_id=>42

,p_name=>'STRETCH_TO_FIT_WINDOW'

,p_display_name=>'Stretch to Fit Window'

,p_display_sequence=>1

,p_page_template_id=>wwv_flow_imp.id(450121884387276949)

,p_css_classes=>'ui-dialog--stretch'

,p_template_types=>'PAGE'

,p_help_text=>'Stretch the dialog to fit the browser window.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450122351809276949)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>20

,p_page_template_id=>wwv_flow_imp.id(450121884387276949)

,p_css_classes=>'t-Dialog--noPadding'

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450122933835276950)

,p_theme_id=>42

,p_name=>'PAGE_BACKGROUND_3'

,p_display_name=>'Background 3'

,p_display_sequence=>30

,p_page_template_id=>wwv_flow_imp.id(450122427938276949)

,p_css_classes=>'t-LoginPage--bg3'

,p_group_id=>wwv_flow_imp.id(450106912230276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450123099059276950)

,p_theme_id=>42

,p_name=>'PAGE_LAYOUT_SPLIT'

,p_display_name=>'Split'

,p_display_sequence=>1

,p_page_template_id=>wwv_flow_imp.id(450122427938276949)

,p_css_classes=>'t-LoginPage--split'

,p_group_id=>wwv_flow_imp.id(450107015773276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450123185444276950)

,p_theme_id=>42

,p_name=>'PAGE_BACKGROUND_1'

,p_display_name=>'Background 1'

,p_display_sequence=>10

,p_page_template_id=>wwv_flow_imp.id(450122427938276949)

,p_css_classes=>'t-LoginPage--bg1'

,p_group_id=>wwv_flow_imp.id(450106912230276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450123252731276950)

,p_theme_id=>42

,p_name=>'PAGE_BACKGROUND_2'

,p_display_name=>'Background 2'

,p_display_sequence=>20

,p_page_template_id=>wwv_flow_imp.id(450122427938276949)

,p_css_classes=>'t-LoginPage--bg2'

,p_group_id=>wwv_flow_imp.id(450106912230276941)

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450123732182276950)

,p_theme_id=>42

,p_name=>'STRETCH_TO_FIT_WINDOW'

,p_display_name=>'Stretch to Fit Window'

,p_display_sequence=>10

,p_page_template_id=>wwv_flow_imp.id(450123385566276950)

,p_css_classes=>'ui-dialog--stretch'

,p_template_types=>'PAGE'

,p_help_text=>'Stretch the dialog to fit the browser window.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450123859922276950)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>20

,p_page_template_id=>wwv_flow_imp.id(450123385566276950)

,p_css_classes=>'t-Dialog--noPadding'

,p_template_types=>'PAGE'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450125122077276951)

,p_theme_id=>42

,p_name=>'STICKY_HEADER_ON_MOBILE'

,p_display_name=>'Sticky Header on Mobile'

,p_display_sequence=>100

,p_page_template_id=>wwv_flow_imp.id(450123939841276950)

,p_css_classes=>'js-pageStickyMobileHeader'

,p_template_types=>'PAGE'

,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450126472501276952)

,p_theme_id=>42

,p_name=>'SHOW_REGION_ICON'

,p_display_name=>'Show Region Icon'

,p_display_sequence=>50

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--showIcon'

,p_template_types=>'REGION'

,p_help_text=>'Displays the region icon in the region header beside the region title'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450126586515276952)

,p_theme_id=>42

,p_name=>'240PX'

,p_display_name=>'240px'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'i-h240'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets region body height to 240px.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450126623491276952)

,p_theme_id=>42

,p_name=>'320PX'

,p_display_name=>'320px'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'i-h320'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets region body height to 320px.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450126772059276952)

,p_theme_id=>42

,p_name=>'480PX'

,p_display_name=>'480px'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'i-h480'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450126852424276952)

,p_theme_id=>42

,p_name=>'5_SECONDS'

,p_display_name=>'5 Seconds'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'js-cycle5s'

,p_group_id=>wwv_flow_imp.id(450111864614276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450126993026276952)

,p_theme_id=>42

,p_name=>'640PX'

,p_display_name=>'640px'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'i-h640'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127044781276952)

,p_theme_id=>42

,p_name=>'ACCENT_1'

,p_display_name=>'Accent 1'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--accent1'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127123610276953)

,p_theme_id=>42

,p_name=>'ACCENT_2'

,p_display_name=>'Accent 2'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--accent2'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127253473276953)

,p_theme_id=>42

,p_name=>'ACCENT_3'

,p_display_name=>'Accent 3'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--accent3'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127363818276953)

,p_theme_id=>42

,p_name=>'ACCENT_4'

,p_display_name=>'Accent 4'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--accent4'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127425261276953)

,p_theme_id=>42

,p_name=>'ACCENT_5'

,p_display_name=>'Accent 5'

,p_display_sequence=>50

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--accent5'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127591070276953)

,p_theme_id=>42

,p_name=>'HIDDENHEADERNOAT'

,p_display_name=>'Hidden'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--removeHeader js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450109060960276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127628651276953)

,p_theme_id=>42

,p_name=>'HIDEOVERFLOW'

,p_display_name=>'Hide'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--hiddenOverflow'

,p_group_id=>wwv_flow_imp.id(450108009437276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127789412276953)

,p_theme_id=>42

,p_name=>'HIDEREGIONHEADER'

,p_display_name=>'Hidden but accessible'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--hideHeader js-addHiddenHeadingRoleDesc'

,p_group_id=>wwv_flow_imp.id(450109060960276942)

,p_template_types=>'REGION'

,p_help_text=>'This option will hide the region header. Note that the region title will still be audible for Screen Readers. Buttons placed in the region header will be hidden and inaccessible.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127827468276953)

,p_theme_id=>42

,p_name=>'NOBODYPADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes padding from region body.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450127963930276953)

,p_theme_id=>42

,p_name=>'NOBORDER'

,p_display_name=>'Remove Borders'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--noBorder'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes borders from the region.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128076843276953)

,p_theme_id=>42

,p_name=>'REMEMBER_CAROUSEL_SLIDE'

,p_display_name=>'Remember Carousel Slide'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'js-useLocalStorage'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128127523276953)

,p_theme_id=>42

,p_name=>'SCROLLBODY'

,p_display_name=>'Scroll'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--scrollBody'

,p_group_id=>wwv_flow_imp.id(450108009437276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128229447276953)

,p_theme_id=>42

,p_name=>'SLIDE'

,p_display_name=>'Slide'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--carouselSlide'

,p_group_id=>wwv_flow_imp.id(450107844607276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128358512276953)

,p_theme_id=>42

,p_name=>'SPIN'

,p_display_name=>'Spin'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--carouselSpin'

,p_group_id=>wwv_flow_imp.id(450107844607276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128472869276954)

,p_theme_id=>42

,p_name=>'STACKED'

,p_display_name=>'Stack Region'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--stacked'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes side borders and shadows, and can be useful for accordions and regions that need to be grouped together vertically.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128550688276954)

,p_theme_id=>42

,p_name=>'SHOW_NEXT_AND_PREVIOUS_BUTTONS'

,p_display_name=>'Show Next and Previous Buttons'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'t-Region--showCarouselControls'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128652054276954)

,p_theme_id=>42

,p_name=>'SHOW_MAXIMIZE_BUTTON'

,p_display_name=>'Show Maximize Button'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'js-showMaximizeButton'

,p_template_types=>'REGION'

,p_help_text=>'Displays a button in the Region Header to maximize the region. Clicking this button will toggle the maximize state and stretch the region to fill the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128744200276954)

,p_theme_id=>42

,p_name=>'10_SECONDS'

,p_display_name=>'10 Seconds'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'js-cycle10s'

,p_group_id=>wwv_flow_imp.id(450111864614276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128881091276954)

,p_theme_id=>42

,p_name=>'15_SECONDS'

,p_display_name=>'15 Seconds'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'js-cycle15s'

,p_group_id=>wwv_flow_imp.id(450111864614276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450128933931276954)

,p_theme_id=>42

,p_name=>'20_SECONDS'

,p_display_name=>'20 Seconds'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450125208201276951)

,p_css_classes=>'js-cycle20s'

,p_group_id=>wwv_flow_imp.id(450111864614276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450129363560276954)

,p_theme_id=>42

,p_name=>'REMEMBER_ACTIVE_TAB'

,p_display_name=>'Remember Active Tab'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450129020113276954)

,p_css_classes=>'js-useLocalStorage'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450129467221276955)

,p_theme_id=>42

,p_name=>'FILL_TAB_LABELS'

,p_display_name=>'Fill Tab Labels'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450129020113276954)

,p_css_classes=>'t-TabsRegion-mod--fillLabels'

,p_group_id=>wwv_flow_imp.id(450110598220276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450129531388276955)

,p_theme_id=>42

,p_name=>'SIMPLE'

,p_display_name=>'Simple'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450129020113276954)

,p_css_classes=>'t-TabsRegion-mod--simple'

,p_group_id=>wwv_flow_imp.id(450111764583276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450129624227276955)

,p_theme_id=>42

,p_name=>'PILL'

,p_display_name=>'Pill'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450129020113276954)

,p_css_classes=>'t-TabsRegion-mod--pill'

,p_group_id=>wwv_flow_imp.id(450111764583276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450129768206276955)

,p_theme_id=>42

,p_name=>'TABS_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450129020113276954)

,p_css_classes=>'t-TabsRegion-mod--small'

,p_group_id=>wwv_flow_imp.id(450111634544276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450129862338276955)

,p_theme_id=>42

,p_name=>'TABSLARGE'

,p_display_name=>'Large'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450129020113276954)

,p_css_classes=>'t-TabsRegion-mod--large'

,p_group_id=>wwv_flow_imp.id(450111634544276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450131788380276956)

,p_theme_id=>42

,p_name=>'SHOW_REGION_ICON'

,p_display_name=>'Show Region Icon'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--showIcon'

,p_template_types=>'REGION'

,p_help_text=>'Displays the region icon in the region header beside the region title'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450131893725276956)

,p_theme_id=>42

,p_name=>'TEXT_CONTENT'

,p_display_name=>'Text Content'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--textContent'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Useful for displaying primarily text-based content, such as FAQs and more.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450131971387276956)

,p_theme_id=>42

,p_name=>'NOBORDER'

,p_display_name=>'Remove Borders'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--noBorder'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes borders from the region.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132014766276956)

,p_theme_id=>42

,p_name=>'NOBODYPADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes padding from region body.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132150073276956)

,p_theme_id=>42

,p_name=>'STACKED'

,p_display_name=>'Stack Region'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--stacked'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes side borders and shadows, and can be useful for accordions and regions that need to be grouped together vertically.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132226825276956)

,p_theme_id=>42

,p_name=>'240PX'

,p_display_name=>'240px'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'i-h240'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets region body height to 240px.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132302311276956)

,p_theme_id=>42

,p_name=>'320PX'

,p_display_name=>'320px'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'i-h320'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets region body height to 320px.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132455715276956)

,p_theme_id=>42

,p_name=>'SCROLLBODY'

,p_display_name=>'Scroll - Default'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--scrollBody'

,p_group_id=>wwv_flow_imp.id(450108009437276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132501285276956)

,p_theme_id=>42

,p_name=>'HIDEREGIONHEADER'

,p_display_name=>'Hidden but accessible'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--hideHeader js-addHiddenHeadingRoleDesc'

,p_group_id=>wwv_flow_imp.id(450108979820276942)

,p_template_types=>'REGION'

,p_help_text=>'This option will hide the region header. Note that the region title will still be audible for Screen Readers. Buttons placed in the region header will be hidden and inaccessible.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132688486276956)

,p_theme_id=>42

,p_name=>'HIDEOVERFLOW'

,p_display_name=>'Hide'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--hiddenOverflow'

,p_group_id=>wwv_flow_imp.id(450108009437276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132761053276957)

,p_theme_id=>42

,p_name=>'HIDDENHEADERNOAT'

,p_display_name=>'Hidden'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--removeHeader js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450108979820276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132873679276957)

,p_theme_id=>42

,p_name=>'ACCENT_1'

,p_display_name=>'Accent 1'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent1'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450132950330276957)

,p_theme_id=>42

,p_name=>'ACCENT_2'

,p_display_name=>'Accent 2'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent2'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133014684276957)

,p_theme_id=>42

,p_name=>'ACCENT_3'

,p_display_name=>'Accent 3'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent3'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133112449276957)

,p_theme_id=>42

,p_name=>'ACCENT_4'

,p_display_name=>'Accent 4'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent4'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133234480276957)

,p_theme_id=>42

,p_name=>'ACCENT_5'

,p_display_name=>'Accent 5'

,p_display_sequence=>50

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent5'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133398405276957)

,p_theme_id=>42

,p_name=>'480PX'

,p_display_name=>'480px'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'i-h480'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133441552276958)

,p_theme_id=>42

,p_name=>'640PX'

,p_display_name=>'640px'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'i-h640'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133536853276958)

,p_theme_id=>42

,p_name=>'ACCENT_6'

,p_display_name=>'Accent 6'

,p_display_sequence=>60

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent6'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133628313276958)

,p_theme_id=>42

,p_name=>'ACCENT_7'

,p_display_name=>'Accent 7'

,p_display_sequence=>70

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent7'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133797925276958)

,p_theme_id=>42

,p_name=>'ACCENT_8'

,p_display_name=>'Accent 8'

,p_display_sequence=>80

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent8'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133833346276958)

,p_theme_id=>42

,p_name=>'ACCENT_9'

,p_display_name=>'Accent 9'

,p_display_sequence=>90

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent9'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450133973774276958)

,p_theme_id=>42

,p_name=>'ACCENT_10'

,p_display_name=>'Accent 10'

,p_display_sequence=>100

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent10'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134068032276958)

,p_theme_id=>42

,p_name=>'ACCENT_11'

,p_display_name=>'Accent 11'

,p_display_sequence=>110

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent11'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134195134276958)

,p_theme_id=>42

,p_name=>'ACCENT_12'

,p_display_name=>'Accent 12'

,p_display_sequence=>120

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent12'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134295596276958)

,p_theme_id=>42

,p_name=>'ACCENT_13'

,p_display_name=>'Accent 13'

,p_display_sequence=>130

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent13'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134300863276959)

,p_theme_id=>42

,p_name=>'ACCENT_14'

,p_display_name=>'Accent 14'

,p_display_sequence=>140

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent14'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134487294276959)

,p_theme_id=>42

,p_name=>'ACCENT_15'

,p_display_name=>'Accent 15'

,p_display_sequence=>150

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--accent15'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134567661276959)

,p_theme_id=>42

,p_name=>'SHOW_MAXIMIZE_BUTTON'

,p_display_name=>'Show Maximize Button'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'js-showMaximizeButton'

,p_template_types=>'REGION'

,p_help_text=>'Displays a button in the Region Header to maximize the region. Clicking this button will toggle the maximize state and stretch the region to fill the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450134649505276959)

,p_theme_id=>42

,p_name=>'REMOVE_UI_DECORATION'

,p_display_name=>'Remove UI Decoration'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450130417347276955)

,p_css_classes=>'t-Region--noUI'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes UI decoration (borders, backgrounds, shadows, etc) from the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136196811276959)

,p_theme_id=>42

,p_name=>'DISPLAY_POPUP_CALLOUT'

,p_display_name=>'Display Popup Callout'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-callout'

,p_template_types=>'REGION'

,p_help_text=>'Use this option to add display a callout for the popup. Note that callout will only be displayed if the data-parent-element custom attribute is defined.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136226825276960)

,p_theme_id=>42

,p_name=>'BEFORE'

,p_display_name=>'Before'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-pos-before'

,p_group_id=>wwv_flow_imp.id(450108302880276942)

,p_template_types=>'REGION'

,p_help_text=>'Positions the callout before or typically to the left of the parent.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136307564276960)

,p_theme_id=>42

,p_name=>'AFTER'

,p_display_name=>'After'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-pos-after'

,p_group_id=>wwv_flow_imp.id(450108302880276942)

,p_template_types=>'REGION'

,p_help_text=>'Positions the callout after or typically to the right of the parent.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136497140276960)

,p_theme_id=>42

,p_name=>'ABOVE'

,p_display_name=>'Above'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-pos-above'

,p_group_id=>wwv_flow_imp.id(450108302880276942)

,p_template_types=>'REGION'

,p_help_text=>'Positions the callout above or typically on top of the parent.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136549424276960)

,p_theme_id=>42

,p_name=>'BELOW'

,p_display_name=>'Below'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-pos-below'

,p_group_id=>wwv_flow_imp.id(450108302880276942)

,p_template_types=>'REGION'

,p_help_text=>'Positions the callout below or typically to the bottom of the parent.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136601195276960)

,p_theme_id=>42

,p_name=>'INSIDE'

,p_display_name=>'Inside'

,p_display_sequence=>50

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-pos-inside'

,p_group_id=>wwv_flow_imp.id(450108302880276942)

,p_template_types=>'REGION'

,p_help_text=>'Positions the callout inside of the parent. This is useful when the parent is sufficiently large, such as a report or large region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136740779276960)

,p_theme_id=>42

,p_name=>'AUTO_HEIGHT_INLINE_DIALOG'

,p_display_name=>'Auto Height'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-dialog-autoheight'

,p_template_types=>'REGION'

,p_help_text=>'This option will set the height of the dialog to fit its contents.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136833401276960)

,p_theme_id=>42

,p_name=>'LARGE_720X480'

,p_display_name=>'Large (720x480)'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-dialog-size720x480'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450136984058276960)

,p_theme_id=>42

,p_name=>'MEDIUM_600X400'

,p_display_name=>'Medium (600x400)'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-dialog-size600x400'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450137041594276960)

,p_theme_id=>42

,p_name=>'SMALL_480X320'

,p_display_name=>'Small (480x320)'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-dialog-size480x320'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450137182408276960)

,p_theme_id=>42

,p_name=>'NONE'

,p_display_name=>'None'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-dialog-nosize'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450137256747276960)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'t-DialogRegion--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes the padding around the region body.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450137380276276960)

,p_theme_id=>42

,p_name=>'REMOVE_PAGE_OVERLAY'

,p_display_name=>'Remove Page Overlay'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450135253134276959)

,p_css_classes=>'js-popup-noOverlay'

,p_template_types=>'REGION'

,p_help_text=>'This option will display the inline dialog without an overlay on the background.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450137871736276961)

,p_theme_id=>42

,p_name=>'APPLY_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450137468528276960)

,p_css_classes=>'u-colors'

,p_template_types=>'REGION'

,p_help_text=>'Applies the colors from the theme''s color palette to the icons or initials within search results.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450137919759276961)

,p_theme_id=>42

,p_name=>'RESULT_APPEARANCE_BOXED'

,p_display_name=>'Boxed'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450137468528276960)

,p_css_classes=>'t-ResultsRegion--boxed'

,p_group_id=>wwv_flow_imp.id(450111318777276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450138070449276961)

,p_theme_id=>42

,p_name=>'RESULT_APPEARANCE_FLAT'

,p_display_name=>'Flat'

,p_display_sequence=>2

,p_region_template_id=>wwv_flow_imp.id(450137468528276960)

,p_css_classes=>'t-ResultsRegion--flat'

,p_group_id=>wwv_flow_imp.id(450111318777276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450138141649276961)

,p_theme_id=>42

,p_name=>'ICON_SIZE_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450137468528276960)

,p_css_classes=>'t-ResultsRegion--iconSm'

,p_group_id=>wwv_flow_imp.id(450109518423276942)

,p_template_types=>'REGION'

,p_help_text=>'Sets the icon size to small (16px).'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450138277990276961)

,p_theme_id=>42

,p_name=>'ICON_SIZE_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>2

,p_region_template_id=>wwv_flow_imp.id(450137468528276960)

,p_css_classes=>'t-ResultsRegion--iconMd'

,p_group_id=>wwv_flow_imp.id(450109518423276942)

,p_template_types=>'REGION'

,p_help_text=>'Sets the icon size to medium (32px).'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450138309204276961)

,p_theme_id=>42

,p_name=>'ICON_SIZE_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>3

,p_region_template_id=>wwv_flow_imp.id(450137468528276960)

,p_css_classes=>'t-ResultsRegion--iconLg'

,p_group_id=>wwv_flow_imp.id(450109518423276942)

,p_template_types=>'REGION'

,p_help_text=>'Sets the icon size to large (64px).'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450138832813276961)

,p_theme_id=>42

,p_name=>'STACK_MOBILE'

,p_display_name=>'Stack on Mobile'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450138488634276961)

,p_css_classes=>'t-ItemContainer--stackMobile'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450138930991276962)

,p_theme_id=>42

,p_name=>'WRAP_ITEMS'

,p_display_name=>'Wrap Items'

,p_display_sequence=>2

,p_region_template_id=>wwv_flow_imp.id(450138488634276961)

,p_css_classes=>'t-ItemContainer--wrap'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450139013257276962)

,p_theme_id=>42

,p_name=>'ALIGNMENT_START'

,p_display_name=>'Start'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450138488634276961)

,p_css_classes=>'t-ItemContainer--alignStart'

,p_group_id=>wwv_flow_imp.id(450107708434276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450139189834276962)

,p_theme_id=>42

,p_name=>'ALIGNMENT_CENTER'

,p_display_name=>'Center'

,p_display_sequence=>11

,p_region_template_id=>wwv_flow_imp.id(450138488634276961)

,p_css_classes=>'t-ItemContainer--alignCenter'

,p_group_id=>wwv_flow_imp.id(450107708434276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450139293457276962)

,p_theme_id=>42

,p_name=>'ALIGNMENT_END'

,p_display_name=>'End'

,p_display_sequence=>12

,p_region_template_id=>wwv_flow_imp.id(450138488634276961)

,p_css_classes=>'t-ItemContainer--alignEnd'

,p_group_id=>wwv_flow_imp.id(450107708434276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450139318502276962)

,p_theme_id=>42

,p_name=>'ALIGNMENT_STRETCH'

,p_display_name=>'Stretch'

,p_display_sequence=>13

,p_region_template_id=>wwv_flow_imp.id(450138488634276961)

,p_css_classes=>'t-ItemContainer--alignStretch'

,p_group_id=>wwv_flow_imp.id(450107708434276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140385164276962)

,p_theme_id=>42

,p_name=>'MODAL'

,p_display_name=>'Modal'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-modal'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140447892276962)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>5

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'t-DialogRegion--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes the padding around the region body.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140531050276962)

,p_theme_id=>42

,p_name=>'NONE'

,p_display_name=>'None (Auto)'

,p_display_sequence=>5

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-nosize'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140667385276962)

,p_theme_id=>42

,p_name=>'POSITION_START'

,p_display_name=>'Start'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-class-t-Drawer--pullOutStart'

,p_group_id=>wwv_flow_imp.id(450110942638276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140704610276963)

,p_theme_id=>42

,p_name=>'POSITION_END'

,p_display_name=>'End'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-class-t-Drawer--pullOutEnd'

,p_group_id=>wwv_flow_imp.id(450110942638276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140865028276963)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-class-t-Drawer--sm'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450140956791276963)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-class-t-Drawer--md'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141016126276963)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-class-t-Drawer--lg'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141118552276963)

,p_theme_id=>42

,p_name=>'DRAWER_SIZE_EXTRA_LARGE'

,p_display_name=>'Extra Large'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450139427103276962)

,p_css_classes=>'js-dialog-class-t-Drawer--xl'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141539793276963)

,p_theme_id=>42

,p_name=>'RATIO_AUTO'

,p_display_name=>'Auto'

,p_display_sequence=>100

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--auto'

,p_group_id=>wwv_flow_imp.id(450109750672276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141662127276964)

,p_theme_id=>42

,p_name=>'RATIO_1_1'

,p_display_name=>'1:1 (Square)'

,p_display_sequence=>110

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--1x1'

,p_group_id=>wwv_flow_imp.id(450109750672276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141794732276964)

,p_theme_id=>42

,p_name=>'RATIO_16_9'

,p_display_name=>'16:9 (Widescreen)'

,p_display_sequence=>120

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--16x9'

,p_group_id=>wwv_flow_imp.id(450109750672276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141844642276964)

,p_theme_id=>42

,p_name=>'RATIO_4_3'

,p_display_name=>'4:3 (Standard)'

,p_display_sequence=>130

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--4x3'

,p_group_id=>wwv_flow_imp.id(450109750672276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450141969286276964)

,p_theme_id=>42

,p_name=>'IMAGE_STRETCH'

,p_display_name=>'Image Stretch'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--stretch'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142076186276964)

,p_theme_id=>42

,p_name=>'SCALE_CONTAIN'

,p_display_name=>'Contain'

,p_display_sequence=>200

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--contain'

,p_group_id=>wwv_flow_imp.id(450109887400276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142100916276964)

,p_theme_id=>42

,p_name=>'SCALE_COVER'

,p_display_name=>'Cover'

,p_display_sequence=>210

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--cover'

,p_group_id=>wwv_flow_imp.id(450109887400276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142208935276964)

,p_theme_id=>42

,p_name=>'SCALE_FILL'

,p_display_name=>'Fill'

,p_display_sequence=>220

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--fill'

,p_group_id=>wwv_flow_imp.id(450109887400276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142337097276964)

,p_theme_id=>42

,p_name=>'SCALE_DOWN'

,p_display_name=>'Scale Down'

,p_display_sequence=>230

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--scale-down'

,p_group_id=>wwv_flow_imp.id(450109887400276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142426946276964)

,p_theme_id=>42

,p_name=>'SHAPE_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>300

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--square'

,p_group_id=>wwv_flow_imp.id(450109901409276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142592251276964)

,p_theme_id=>42

,p_name=>'SHAPE_ROUNDED'

,p_display_name=>'Rounded'

,p_display_sequence=>310

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--rounded'

,p_group_id=>wwv_flow_imp.id(450109901409276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142641190276964)

,p_theme_id=>42

,p_name=>'SHAPE_CIRCLE'

,p_display_name=>'Circle'

,p_display_sequence=>320

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--circle'

,p_group_id=>wwv_flow_imp.id(450109901409276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142731696276964)

,p_theme_id=>42

,p_name=>'RATIO_2_1'

,p_display_name=>'2:1 (Univisium)'

,p_display_sequence=>140

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--2x1'

,p_group_id=>wwv_flow_imp.id(450109750672276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142836753276964)

,p_theme_id=>42

,p_name=>'FILTER_NONE'

,p_display_name=>'None'

,p_display_sequence=>400

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--noFilter'

,p_group_id=>wwv_flow_imp.id(450109608997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450142968850276965)

,p_theme_id=>42

,p_name=>'FILTER_GRAYSCALE'

,p_display_name=>'Grayscale'

,p_display_sequence=>410

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--grayscale'

,p_group_id=>wwv_flow_imp.id(450109608997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450143065359276965)

,p_theme_id=>42

,p_name=>'FILTER_SEPIA'

,p_display_name=>'Sepia'

,p_display_sequence=>420

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--sepia'

,p_group_id=>wwv_flow_imp.id(450109608997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450143117842276965)

,p_theme_id=>42

,p_name=>'FILTER_BLUR'

,p_display_name=>'Blur'

,p_display_sequence=>430

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--blur'

,p_group_id=>wwv_flow_imp.id(450109608997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450143214045276965)

,p_theme_id=>42

,p_name=>'FILTER_INVERT'

,p_display_name=>'Invert'

,p_display_sequence=>440

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--invert'

,p_group_id=>wwv_flow_imp.id(450109608997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450143321971276965)

,p_theme_id=>42

,p_name=>'FILTER_SATURATE'

,p_display_name=>'Saturate'

,p_display_sequence=>450

,p_region_template_id=>wwv_flow_imp.id(450141285121276963)

,p_css_classes=>'t-ImageRegion--saturate'

,p_group_id=>wwv_flow_imp.id(450109608997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144165735276965)

,p_theme_id=>42

,p_name=>'WIZARD'

,p_display_name=>'Wizard'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--wizard'

,p_group_id=>wwv_flow_imp.id(450107385223276941)

,p_template_types=>'REGION'

,p_help_text=>'Show the alert in a wizard style region.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144217214276965)

,p_theme_id=>42

,p_name=>'HORIZONTAL'

,p_display_name=>'Horizontal'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--horizontal'

,p_group_id=>wwv_flow_imp.id(450107385223276941)

,p_template_types=>'REGION'

,p_help_text=>'Show horizontal alert with buttons to the right.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144320360276965)

,p_theme_id=>42

,p_name=>'WARNING'

,p_display_name=>'Warning'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--warning'

,p_group_id=>wwv_flow_imp.id(450107623647276941)

,p_template_types=>'REGION'

,p_help_text=>'Show a warning alert.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144485451276965)

,p_theme_id=>42

,p_name=>'SUCCESS'

,p_display_name=>'Success'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--success'

,p_group_id=>wwv_flow_imp.id(450107623647276941)

,p_template_types=>'REGION'

,p_help_text=>'Show success alert.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144552557276966)

,p_theme_id=>42

,p_name=>'DANGER'

,p_display_name=>'Danger'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--danger'

,p_group_id=>wwv_flow_imp.id(450107623647276941)

,p_template_types=>'REGION'

,p_help_text=>'Show an error or danger alert.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144620824276966)

,p_theme_id=>42

,p_name=>'COLOREDBACKGROUND'

,p_display_name=>'Highlight Background'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--colorBG'

,p_template_types=>'REGION'

,p_help_text=>'Set alert background color to that of the alert type (warning, success, etc.)'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144758128276966)

,p_theme_id=>42

,p_name=>'INFORMATION'

,p_display_name=>'Information'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--info'

,p_group_id=>wwv_flow_imp.id(450107623647276941)

,p_template_types=>'REGION'

,p_help_text=>'Show informational alert.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144815047276966)

,p_theme_id=>42

,p_name=>'USEDEFAULTICONS'

,p_display_name=>'Show Default Icons'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--defaultIcons'

,p_group_id=>wwv_flow_imp.id(450107486567276941)

,p_template_types=>'REGION'

,p_help_text=>'Uses default icons for alert types.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450144944815276966)

,p_theme_id=>42

,p_name=>'HIDDENHEADERNOAT'

,p_display_name=>'Hidden'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--removeHeading js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450107550737276941)

,p_template_types=>'REGION'

,p_help_text=>'Hides the Alert Title from being displayed.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450145051727276966)

,p_theme_id=>42

,p_name=>'HIDDENHEADER'

,p_display_name=>'Hidden but Accessible'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--accessibleHeading'

,p_group_id=>wwv_flow_imp.id(450107550737276941)

,p_template_types=>'REGION'

,p_help_text=>'Visually hides the alert title, but assistive technologies can still read it.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450145109830276966)

,p_theme_id=>42

,p_name=>'HIDE_ICONS'

,p_display_name=>'Hide Icons'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--noIcon'

,p_group_id=>wwv_flow_imp.id(450107486567276941)

,p_template_types=>'REGION'

,p_help_text=>'Hides alert icons'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450145252000276966)

,p_theme_id=>42

,p_name=>'SHOW_CUSTOM_ICONS'

,p_display_name=>'Show Custom Icons'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450143493156276965)

,p_css_classes=>'t-Alert--customIcons'

,p_group_id=>wwv_flow_imp.id(450107486567276941)

,p_template_types=>'REGION'

,p_help_text=>'Set custom icons by modifying the Alert Region''s Icon CSS Classes property.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450145700641276966)

,p_theme_id=>42

,p_name=>'STYLE_A'

,p_display_name=>'Style A'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450145332728276966)

,p_css_classes=>'t-CardsRegion--styleA'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450145812528276966)

,p_theme_id=>42

,p_name=>'STYLE_B'

,p_display_name=>'Style B'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450145332728276966)

,p_css_classes=>'t-CardsRegion--styleB'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450145982964276966)

,p_theme_id=>42

,p_name=>'STYLE_C'

,p_display_name=>'Style C'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450145332728276966)

,p_css_classes=>'t-CardsRegion--styleC'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450146088437276967)

,p_theme_id=>42

,p_name=>'APPLY_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450145332728276966)

,p_css_classes=>'u-colors'

,p_template_types=>'REGION'

,p_help_text=>'Applies the colors from the theme''s color palette to the icons or initials within cards.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450146188684276967)

,p_theme_id=>42

,p_name=>'HIDEREGIONHEADER'

,p_display_name=>'Hidden but accessible'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450145332728276966)

,p_css_classes=>'t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'

,p_group_id=>wwv_flow_imp.id(450109060960276942)

,p_template_types=>'REGION'

,p_help_text=>'This option will hide the region header. Note that the region title will still be audible for Screen Readers.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450146227777276967)

,p_theme_id=>42

,p_name=>'HIDDENHEADERNOAT'

,p_display_name=>'Hidden'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450145332728276966)

,p_css_classes=>'t-CardsRegion--removeHeader js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450109060960276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450146945767276967)

,p_theme_id=>42

,p_name=>'REMOVEBORDERS'

,p_display_name=>'Remove Borders'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450146394097276967)

,p_css_classes=>'t-IRR-region--noBorders'

,p_template_types=>'REGION'

,p_help_text=>'Removes borders around the Interactive Report'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450147034851276967)

,p_theme_id=>42

,p_name=>'SHOW_MAXIMIZE_BUTTON'

,p_display_name=>'Show Maximize Button'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450146394097276967)

,p_css_classes=>'js-showMaximizeButton'

,p_template_types=>'REGION'

,p_help_text=>'Displays a button in the Interactive Reports toolbar to maximize the report. Clicking this button will toggle the maximize state and stretch the report to fill the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450147152885276967)

,p_theme_id=>42

,p_name=>'HIDEREGIONHEADER'

,p_display_name=>'Hidden but accessible'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450146394097276967)

,p_css_classes=>'t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'

,p_group_id=>wwv_flow_imp.id(450109060960276942)

,p_template_types=>'REGION'

,p_help_text=>'This option will hide the region header. Note that the region title will still be audible for Screen Readers.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450147216390276967)

,p_theme_id=>42

,p_name=>'HIDDENHEADERNOAT'

,p_display_name=>'Hidden'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450146394097276967)

,p_css_classes=>'t-IRR-region--removeHeader js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450109060960276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450147949678276968)

,p_theme_id=>42

,p_name=>'HIDESMALLSCREENS'

,p_display_name=>'Small Screens (Tablet)'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450147371228276967)

,p_css_classes=>'t-Wizard--hideStepsSmall'

,p_group_id=>wwv_flow_imp.id(450109326267276942)

,p_template_types=>'REGION'

,p_help_text=>'Hides the wizard progress steps for screens that are smaller than 768px wide.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450148056386276968)

,p_theme_id=>42

,p_name=>'HIDEXSMALLSCREENS'

,p_display_name=>'X Small Screens (Mobile)'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450147371228276967)

,p_css_classes=>'t-Wizard--hideStepsXSmall'

,p_group_id=>wwv_flow_imp.id(450109326267276942)

,p_template_types=>'REGION'

,p_help_text=>'Hides the wizard progress steps for screens that are smaller than 768px wide.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450148104093276968)

,p_theme_id=>42

,p_name=>'SHOW_TITLE'

,p_display_name=>'Show Title'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450147371228276967)

,p_css_classes=>'t-Wizard--showTitle'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450149280762276968)

,p_theme_id=>42

,p_name=>'BORDERLESS'

,p_display_name=>'Borderless'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450148253115276968)

,p_css_classes=>'t-ButtonRegion--noBorder'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450149374022276968)

,p_theme_id=>42

,p_name=>'SLIMPADDING'

,p_display_name=>'Slim Padding'

,p_display_sequence=>5

,p_region_template_id=>wwv_flow_imp.id(450148253115276968)

,p_css_classes=>'t-ButtonRegion--slimPadding'

,p_group_id=>wwv_flow_imp.id(450108145444276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450149418148276968)

,p_theme_id=>42

,p_name=>'NOPADDING'

,p_display_name=>'No Padding'

,p_display_sequence=>3

,p_region_template_id=>wwv_flow_imp.id(450148253115276968)

,p_css_classes=>'t-ButtonRegion--noPadding'

,p_group_id=>wwv_flow_imp.id(450108145444276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450149594512276969)

,p_theme_id=>42

,p_name=>'STICK_TO_BOTTOM'

,p_display_name=>'Stick to Bottom for Mobile'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450148253115276968)

,p_css_classes=>'t-ButtonRegion--stickToBottom'

,p_template_types=>'REGION'

,p_help_text=>'This will position the button container region to the bottom of the screen for small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450149627820276969)

,p_theme_id=>42

,p_name=>'REMOVEUIDECORATION'

,p_display_name=>'Remove UI Decoration'

,p_display_sequence=>4

,p_region_template_id=>wwv_flow_imp.id(450148253115276968)

,p_css_classes=>'t-ButtonRegion--noUI'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450150473649276969)

,p_theme_id=>42

,p_name=>'HIDEREGIONHEADER'

,p_display_name=>'Hidden but accessible'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'

,p_group_id=>wwv_flow_imp.id(450108979820276942)

,p_template_types=>'REGION'

,p_help_text=>'This option will hide the region header. Note that the region title will still be audible for Screen Readers. Buttons placed in the region header will be hidden and inaccessible.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450150588145276969)

,p_theme_id=>42

,p_name=>'HIDDENHEADERNOAT'

,p_display_name=>'Hidden'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-Region--removeHeader js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450108979820276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450150623827276969)

,p_theme_id=>42

,p_name=>'HEADING_FONT_ALTERNATIVE'

,p_display_name=>'Alternative'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--headingFontAlt'

,p_group_id=>wwv_flow_imp.id(450109106687276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450150758384276970)

,p_theme_id=>42

,p_name=>'CONTENT_TITLE_H1'

,p_display_name=>'Large'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--h1'

,p_group_id=>wwv_flow_imp.id(450111142520276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450150819146276970)

,p_theme_id=>42

,p_name=>'CONTENT_TITLE_H2'

,p_display_name=>'Medium'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--h2'

,p_group_id=>wwv_flow_imp.id(450111142520276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450150935728276970)

,p_theme_id=>42

,p_name=>'CONTENT_TITLE_H3'

,p_display_name=>'Small'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--h3'

,p_group_id=>wwv_flow_imp.id(450111142520276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450151042110276970)

,p_theme_id=>42

,p_name=>'ADD_BODY_PADDING'

,p_display_name=>'Add Body Padding'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--padded'

,p_template_types=>'REGION'

,p_help_text=>'Adds padding to the region''s body container.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450151179708276970)

,p_theme_id=>42

,p_name=>'SHADOW_BACKGROUND'

,p_display_name=>'Shadow Background'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--shadowBG'

,p_group_id=>wwv_flow_imp.id(450108294389276942)

,p_template_types=>'REGION'

,p_help_text=>'Gives the region body a slightly darker background.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450151292155276970)

,p_theme_id=>42

,p_name=>'LIGHT_BACKGROUND'

,p_display_name=>'Light Background'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--lightBG'

,p_group_id=>wwv_flow_imp.id(450108294389276942)

,p_template_types=>'REGION'

,p_help_text=>'Gives the region body a slightly lighter background.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450151365074276970)

,p_theme_id=>42

,p_name=>'SHOW_REGION_ICON'

,p_display_name=>'Show Region Icon'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450149724285276969)

,p_css_classes=>'t-ContentBlock--showIcon'

,p_template_types=>'REGION'

,p_help_text=>'Displays the region icon in the region header beside the region title'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450152856822276971)

,p_theme_id=>42

,p_name=>'USE_COMPACT_STYLE'

,p_display_name=>'Use Compact Style'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450151473035276970)

,p_css_classes=>'t-BreadcrumbRegion--compactTitle'

,p_template_types=>'REGION'

,p_help_text=>'Uses a compact style for the breadcrumbs.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450152924867276971)

,p_theme_id=>42

,p_name=>'HEADING_FONT_ALTERNATIVE'

,p_display_name=>'Alternative'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450151473035276970)

,p_css_classes=>'t-BreadcrumbRegion--headingFontAlt'

,p_group_id=>wwv_flow_imp.id(450109106687276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450153071998276971)

,p_theme_id=>42

,p_name=>'HIDE_BREADCRUMB'

,p_display_name=>'Show Breadcrumbs'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450151473035276970)

,p_css_classes=>'t-BreadcrumbRegion--showBreadcrumb'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450153175713276971)

,p_theme_id=>42

,p_name=>'GET_TITLE_FROM_BREADCRUMB'

,p_display_name=>'Use Current Breadcrumb Entry'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450151473035276970)

,p_css_classes=>'t-BreadcrumbRegion--useBreadcrumbTitle'

,p_group_id=>wwv_flow_imp.id(450111142520276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450153224244276971)

,p_theme_id=>42

,p_name=>'REGION_HEADER_VISIBLE'

,p_display_name=>'Use Region Title'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450151473035276970)

,p_css_classes=>'t-BreadcrumbRegion--useRegionTitle'

,p_group_id=>wwv_flow_imp.id(450111142520276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450154452384276971)

,p_theme_id=>42

,p_name=>'ACCENT_6'

,p_display_name=>'Accent 6'

,p_display_sequence=>60

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent6'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450154533446276971)

,p_theme_id=>42

,p_name=>'ACCENT_7'

,p_display_name=>'Accent 7'

,p_display_sequence=>70

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent7'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450154630876276972)

,p_theme_id=>42

,p_name=>'ACCENT_8'

,p_display_name=>'Accent 8'

,p_display_sequence=>80

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent8'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450154768742276972)

,p_theme_id=>42

,p_name=>'ACCENT_9'

,p_display_name=>'Accent 9'

,p_display_sequence=>90

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent9'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450154829385276972)

,p_theme_id=>42

,p_name=>'ACCENT_10'

,p_display_name=>'Accent 10'

,p_display_sequence=>100

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent10'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450154956900276972)

,p_theme_id=>42

,p_name=>'ACCENT_11'

,p_display_name=>'Accent 11'

,p_display_sequence=>110

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent11'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155013237276972)

,p_theme_id=>42

,p_name=>'ACCENT_12'

,p_display_name=>'Accent 12'

,p_display_sequence=>120

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent12'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155114753276972)

,p_theme_id=>42

,p_name=>'ACCENT_13'

,p_display_name=>'Accent 13'

,p_display_sequence=>130

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent13'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155217620276972)

,p_theme_id=>42

,p_name=>'ACCENT_14'

,p_display_name=>'Accent 14'

,p_display_sequence=>140

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent14'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155390124276972)

,p_theme_id=>42

,p_name=>'ACCENT_15'

,p_display_name=>'Accent 15'

,p_display_sequence=>150

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent15'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155426535276972)

,p_theme_id=>42

,p_name=>'240PX'

,p_display_name=>'240px'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'i-h240'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets region body height to 240px.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155557738276973)

,p_theme_id=>42

,p_name=>'320PX'

,p_display_name=>'320px'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'i-h320'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets region body height to 320px.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155684814276973)

,p_theme_id=>42

,p_name=>'ACCENT_1'

,p_display_name=>'Accent 1'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent1'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155702269276973)

,p_theme_id=>42

,p_name=>'ACCENT_2'

,p_display_name=>'Accent 2'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent2'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155818810276973)

,p_theme_id=>42

,p_name=>'ACCENT_3'

,p_display_name=>'Accent 3'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent3'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450155900639276973)

,p_theme_id=>42

,p_name=>'ACCENT_4'

,p_display_name=>'Accent 4'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent4'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156040904276973)

,p_theme_id=>42

,p_name=>'ACCENT_5'

,p_display_name=>'Accent 5'

,p_display_sequence=>50

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--accent5'

,p_group_id=>wwv_flow_imp.id(450107200313276941)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156169673276973)

,p_theme_id=>42

,p_name=>'HIDEOVERFLOW'

,p_display_name=>'Hide'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--hiddenOverflow'

,p_group_id=>wwv_flow_imp.id(450108009437276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156238785276973)

,p_theme_id=>42

,p_name=>'NOBODYPADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes padding from region body.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156346133276973)

,p_theme_id=>42

,p_name=>'NOBORDER'

,p_display_name=>'Remove Borders'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--noBorder'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes borders from the region.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156493487276974)

,p_theme_id=>42

,p_name=>'SCROLLBODY'

,p_display_name=>'Scroll - Default'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--scrollBody'

,p_group_id=>wwv_flow_imp.id(450108009437276942)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156502360276974)

,p_theme_id=>42

,p_name=>'STACKED'

,p_display_name=>'Stack Region'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--stacked'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes side borders and shadows, and can be useful for accordions and regions that need to be grouped together vertically.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156685477276974)

,p_theme_id=>42

,p_name=>'EXPANDED'

,p_display_name=>'Expanded'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'is-expanded'

,p_group_id=>wwv_flow_imp.id(450108695521276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156726339276974)

,p_theme_id=>42

,p_name=>'COLLAPSED'

,p_display_name=>'Collapsed'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'is-collapsed'

,p_group_id=>wwv_flow_imp.id(450108695521276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156870942276974)

,p_theme_id=>42

,p_name=>'REMEMBER_COLLAPSIBLE_STATE'

,p_display_name=>'Remember Collapsible State'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'js-useLocalStorage'

,p_template_types=>'REGION'

,p_help_text=>'This option saves the current state of the collapsible region for the duration of the session.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450156979723276974)

,p_theme_id=>42

,p_name=>'480PX'

,p_display_name=>'480px'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'i-h480'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets body height to 480px.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450157036326276974)

,p_theme_id=>42

,p_name=>'640PX'

,p_display_name=>'640px'

,p_display_sequence=>40

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'i-h640'

,p_group_id=>wwv_flow_imp.id(450107952972276941)

,p_template_types=>'REGION'

,p_help_text=>'Sets body height to 640px.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450157129266276974)

,p_theme_id=>42

,p_name=>'REMOVE_UI_DECORATION'

,p_display_name=>'Remove UI Decoration'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--noUI'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes UI decoration (borders, backgrounds, shadows, etc) from the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450157214245276975)

,p_theme_id=>42

,p_name=>'ICONS_PLUS_OR_MINUS'

,p_display_name=>'Plus or Minus'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--hideShowIconsMath'

,p_group_id=>wwv_flow_imp.id(450108487873276942)

,p_template_types=>'REGION'

,p_help_text=>'Use the plus and minus icons for the expand and collapse button.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450157303676276975)

,p_theme_id=>42

,p_name=>'CONRTOLS_POSITION_END'

,p_display_name=>'End'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450153318611276971)

,p_css_classes=>'t-Region--controlsPosEnd'

,p_group_id=>wwv_flow_imp.id(450108500802276942)

,p_template_types=>'REGION'

,p_help_text=>'Position the expand / collapse button to the end of the region header.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158385023276975)

,p_theme_id=>42

,p_name=>'AUTO_HEIGHT_INLINE_DIALOG'

,p_display_name=>'Auto Height'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-dialog-autoheight'

,p_template_types=>'REGION'

,p_help_text=>'This option will set the height of the dialog to fit its contents.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158437701276975)

,p_theme_id=>42

,p_name=>'DRAGGABLE'

,p_display_name=>'Draggable'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-draggable'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158512916276976)

,p_theme_id=>42

,p_name=>'MODAL'

,p_display_name=>'Modal'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-modal'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158677204276976)

,p_theme_id=>42

,p_name=>'RESIZABLE'

,p_display_name=>'Resizable'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-resizable'

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158717333276976)

,p_theme_id=>42

,p_name=>'SMALL_480X320'

,p_display_name=>'Small (480x320)'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-dialog-size480x320'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158878848276976)

,p_theme_id=>42

,p_name=>'LARGE_720X480'

,p_display_name=>'Large (720x480)'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-dialog-size720x480'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450158952317276976)

,p_theme_id=>42

,p_name=>'MEDIUM_600X400'

,p_display_name=>'Medium (600x400)'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-dialog-size600x400'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450159019138276976)

,p_theme_id=>42

,p_name=>'NONE'

,p_display_name=>'None'

,p_display_sequence=>5

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'js-dialog-nosize'

,p_group_id=>wwv_flow_imp.id(450108746997276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450159177239276976)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>5

,p_region_template_id=>wwv_flow_imp.id(450157442219276975)

,p_css_classes=>'t-DialogRegion--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes the padding around the region body.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450159852734276977)

,p_theme_id=>42

,p_name=>'HEADING_FONT_ALTERNATIVE'

,p_display_name=>'Alternative'

,p_display_sequence=>1

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--headingFontAlt'

,p_group_id=>wwv_flow_imp.id(450109106687276942)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450159996543276977)

,p_theme_id=>42

,p_name=>'FEATURED'

,p_display_name=>'Featured'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--featured'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450160067866276977)

,p_theme_id=>42

,p_name=>'STACKED_FEATURED'

,p_display_name=>'Stacked Featured'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--featured t-HeroRegion--centered'

,p_group_id=>wwv_flow_imp.id(450111592325276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450160143257276977)

,p_theme_id=>42

,p_name=>'DISPLAY_ICON_NO'

,p_display_name=>'No'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--hideIcon'

,p_group_id=>wwv_flow_imp.id(450108801173276942)

,p_template_types=>'REGION'

,p_help_text=>'Hide the Hero Region icon.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450160232471276977)

,p_theme_id=>42

,p_name=>'REMOVE_BODY_PADDING'

,p_display_name=>'Remove Body Padding'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--noPadding'

,p_template_types=>'REGION'

,p_help_text=>'Removes the padding around the hero region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450160311531276977)

,p_theme_id=>42

,p_name=>'ICONS_CIRCULAR'

,p_display_name=>'Circle'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--iconsCircle'

,p_group_id=>wwv_flow_imp.id(450109407907276942)

,p_template_types=>'REGION'

,p_help_text=>'The icons are displayed within a circle.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450160495906276977)

,p_theme_id=>42

,p_name=>'ICONS_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450159209189276976)

,p_css_classes=>'t-HeroRegion--iconsSquare'

,p_group_id=>wwv_flow_imp.id(450109407907276942)

,p_template_types=>'REGION'

,p_help_text=>'The icons are displayed within a square.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161188225276978)

,p_theme_id=>42

,p_name=>'LOGIN_HEADER_ICON'

,p_display_name=>'Icon'

,p_display_sequence=>10

,p_region_template_id=>wwv_flow_imp.id(450160585225276977)

,p_css_classes=>'t-Login-region--headerIcon'

,p_group_id=>wwv_flow_imp.id(450110653936276943)

,p_template_types=>'REGION'

,p_help_text=>'Displays only the Region Icon in the Login region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161279503276978)

,p_theme_id=>42

,p_name=>'LOGIN_HEADER_TITLE'

,p_display_name=>'Title'

,p_display_sequence=>20

,p_region_template_id=>wwv_flow_imp.id(450160585225276977)

,p_css_classes=>'t-Login-region--headerTitle js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450110653936276943)

,p_template_types=>'REGION'

,p_help_text=>'Displays only the Region Title in the Login region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161371405276978)

,p_theme_id=>42

,p_name=>'LOGO_HEADER_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>30

,p_region_template_id=>wwv_flow_imp.id(450160585225276977)

,p_css_classes=>'t-Login-region--headerHidden js-removeLandmark'

,p_group_id=>wwv_flow_imp.id(450110653936276943)

,p_template_types=>'REGION'

,p_help_text=>'Hides both the Region Icon and Title from the Login region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161559618276979)

,p_theme_id=>42

,p_name=>'APPLY_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'u-colors'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161628166276979)

,p_theme_id=>42

,p_name=>'CIRCULAR'

,p_display_name=>'Circular'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--circular'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161767709276979)

,p_theme_id=>42

,p_name=>'GRID'

,p_display_name=>'Grid'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--dash'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161884309276979)

,p_theme_id=>42

,p_name=>'128PX'

,p_display_name=>'128px'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--xxlarge'

,p_group_id=>wwv_flow_imp.id(450112164892276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450161951216276979)

,p_theme_id=>42

,p_name=>'32PX'

,p_display_name=>'32px'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--small'

,p_group_id=>wwv_flow_imp.id(450112164892276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162007986276979)

,p_theme_id=>42

,p_name=>'48PX'

,p_display_name=>'48px'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--medium'

,p_group_id=>wwv_flow_imp.id(450112164892276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162152778276979)

,p_theme_id=>42

,p_name=>'64PX'

,p_display_name=>'64px'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--large'

,p_group_id=>wwv_flow_imp.id(450112164892276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162265493276980)

,p_theme_id=>42

,p_name=>'96PX'

,p_display_name=>'96px'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--xlarge'

,p_group_id=>wwv_flow_imp.id(450112164892276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162376720276980)

,p_theme_id=>42

,p_name=>'2COLUMNGRID'

,p_display_name=>'2 Column Grid'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_help_text=>'Arrange badges in a two column grid'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162455623276980)

,p_theme_id=>42

,p_name=>'3COLUMNGRID'

,p_display_name=>'3 Column Grid'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--cols t-BadgeList--3cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_help_text=>'Arrange badges in a 3 column grid'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162553725276980)

,p_theme_id=>42

,p_name=>'4COLUMNGRID'

,p_display_name=>'4 Column Grid'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--cols t-BadgeList--4cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162679592276980)

,p_theme_id=>42

,p_name=>'5COLUMNGRID'

,p_display_name=>'5 Column Grid'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--cols t-BadgeList--5cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162790436276980)

,p_theme_id=>42

,p_name=>'FLEXIBLEBOX'

,p_display_name=>'Flexible Box'

,p_display_sequence=>80

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--flex'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162820397276980)

,p_theme_id=>42

,p_name=>'FLOATITEMS'

,p_display_name=>'Float Items'

,p_display_sequence=>70

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--float'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450162980005276981)

,p_theme_id=>42

,p_name=>'FIXED'

,p_display_name=>'Span Horizontally'

,p_display_sequence=>60

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--fixed'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163028060276981)

,p_theme_id=>42

,p_name=>'STACKED'

,p_display_name=>'Stacked'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450161498188276978)

,p_css_classes=>'t-BadgeList--stacked'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163289840276981)

,p_theme_id=>42

,p_name=>'DISPLAY_ITEMS_STACKED'

,p_display_name=>'Stacked'

,p_display_sequence=>1

,p_report_template_id=>wwv_flow_imp.id(450163193715276981)

,p_css_classes=>'t-ContextualInfo-item--stacked'

,p_group_id=>wwv_flow_imp.id(450113104190276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163333841276981)

,p_theme_id=>42

,p_name=>'DISPLAY_LABELS_STACKED'

,p_display_name=>'Stacked'

,p_display_sequence=>1

,p_report_template_id=>wwv_flow_imp.id(450163193715276981)

,p_css_classes=>'t-ContextualInfo-label--stacked'

,p_group_id=>wwv_flow_imp.id(450113249275276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163498659276981)

,p_theme_id=>42

,p_name=>'HIDE_EMPTY_VALUES'

,p_display_name=>'Hide Empty Values'

,p_display_sequence=>1

,p_report_template_id=>wwv_flow_imp.id(450163193715276981)

,p_css_classes=>'t-ContextualInfo--hideNulls'

,p_template_types=>'REPORT'

,p_help_text=>'This option will hide the null rows. Note: This only works in browsers that supports :has() pseudo-class.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163687637276981)

,p_theme_id=>42

,p_name=>'REMOVEALLBORDERS'

,p_display_name=>'No Borders'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--noBorders'

,p_group_id=>wwv_flow_imp.id(450113879974276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163751155276981)

,p_theme_id=>42

,p_name=>'STRETCHREPORT'

,p_display_name=>'Stretch Report'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--stretch'

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163888342276981)

,p_theme_id=>42

,p_name=>'REMOVEOUTERBORDERS'

,p_display_name=>'No Outer Borders'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--inline'

,p_group_id=>wwv_flow_imp.id(450113879974276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450163970920276982)

,p_theme_id=>42

,p_name=>'ALTROWCOLORSDISABLE'

,p_display_name=>'Disable'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--staticRowColors'

,p_group_id=>wwv_flow_imp.id(450111951409276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164078733276982)

,p_theme_id=>42

,p_name=>'ALTROWCOLORSENABLE'

,p_display_name=>'Enable'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--altRowsDefault'

,p_group_id=>wwv_flow_imp.id(450111951409276943)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164196785276982)

,p_theme_id=>42

,p_name=>'HORIZONTALBORDERS'

,p_display_name=>'Horizontal Only'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--horizontalBorders'

,p_group_id=>wwv_flow_imp.id(450113879974276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164287763276982)

,p_theme_id=>42

,p_name=>'VERTICALBORDERS'

,p_display_name=>'Vertical Only'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--verticalBorders'

,p_group_id=>wwv_flow_imp.id(450113879974276944)

,p_template_types=>'REPORT'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164318802276982)

,p_theme_id=>42

,p_name=>'ENABLE'

,p_display_name=>'Enable'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--rowHighlight'

,p_group_id=>wwv_flow_imp.id(450113906679276944)

,p_template_types=>'REPORT'

,p_help_text=>'Enable row highlighting on mouse over'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164433426276982)

,p_theme_id=>42

,p_name=>'ROWHIGHLIGHTDISABLE'

,p_display_name=>'Disable'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450163518385276981)

,p_css_classes=>'t-Report--rowHighlightOff'

,p_group_id=>wwv_flow_imp.id(450113906679276944)

,p_template_types=>'REPORT'

,p_help_text=>'Disable row highlighting on mouse over'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164638672276982)

,p_theme_id=>42

,p_name=>'BASIC'

,p_display_name=>'Basic'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450164535065276982)

,p_css_classes=>'t-Comments--basic'

,p_group_id=>wwv_flow_imp.id(450112939391276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164784707276982)

,p_theme_id=>42

,p_name=>'SPEECH_BUBBLES'

,p_display_name=>'Speech Bubbles'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450164535065276982)

,p_css_classes=>'t-Comments--chat'

,p_group_id=>wwv_flow_imp.id(450112939391276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164849296276982)

,p_theme_id=>42

,p_name=>'ICONS_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450164535065276982)

,p_css_classes=>'t-Comments--iconsSquare'

,p_group_id=>wwv_flow_imp.id(450113435400276943)

,p_template_types=>'REPORT'

,p_help_text=>'The icons are displayed within a square shape.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450164954581276983)

,p_theme_id=>42

,p_name=>'ICONS_ROUNDED'

,p_display_name=>'Rounded Corners'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450164535065276982)

,p_css_classes=>'t-Comments--iconsRounded'

,p_group_id=>wwv_flow_imp.id(450113435400276943)

,p_template_types=>'REPORT'

,p_help_text=>'The icons are displayed within a square with rounded corners.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165297739276983)

,p_theme_id=>42

,p_name=>'BLOCK'

,p_display_name=>'Block'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--featured t-Cards--block force-fa-lg'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165310471276983)

,p_theme_id=>42

,p_name=>'DISPLAY_SUBTITLE'

,p_display_name=>'Display Subtitle'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--displaySubtitle'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165484201276983)

,p_theme_id=>42

,p_name=>'CARDS_COLOR_FILL'

,p_display_name=>'Color Fill'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--animColorFill'

,p_group_id=>wwv_flow_imp.id(450112058259276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165525603276983)

,p_theme_id=>42

,p_name=>'CARD_RAISE_CARD'

,p_display_name=>'Raise Card'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--animRaiseCard'

,p_group_id=>wwv_flow_imp.id(450112058259276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165692050276983)

,p_theme_id=>42

,p_name=>'2_COLUMNS'

,p_display_name=>'2 Columns'

,p_display_sequence=>15

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165714216276983)

,p_theme_id=>42

,p_name=>'3_COLUMNS'

,p_display_name=>'3 Columns'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--3cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165886851276983)

,p_theme_id=>42

,p_name=>'4_COLUMNS'

,p_display_name=>'4 Columns'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--4cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450165994346276983)

,p_theme_id=>42

,p_name=>'5_COLUMNS'

,p_display_name=>'5 Columns'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--5cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166013984276983)

,p_theme_id=>42

,p_name=>'FLOAT'

,p_display_name=>'Float'

,p_display_sequence=>60

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--float'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166143516276984)

,p_theme_id=>42

,p_name=>'SPAN_HORIZONTALLY'

,p_display_name=>'Span Horizontally'

,p_display_sequence=>70

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--spanHorizontally'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166226991276984)

,p_theme_id=>42

,p_name=>'2_LINES'

,p_display_name=>'2 Lines'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--desc-2ln'

,p_group_id=>wwv_flow_imp.id(450112255533276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166352662276984)

,p_theme_id=>42

,p_name=>'3_LINES'

,p_display_name=>'3 Lines'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--desc-3ln'

,p_group_id=>wwv_flow_imp.id(450112255533276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166459678276984)

,p_theme_id=>42

,p_name=>'4_LINES'

,p_display_name=>'4 Lines'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--desc-4ln'

,p_group_id=>wwv_flow_imp.id(450112255533276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166518145276984)

,p_theme_id=>42

,p_name=>'USE_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'u-colors'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166670755276984)

,p_theme_id=>42

,p_name=>'DISPLAY_ICONS'

,p_display_name=>'Display Icons'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--displayIcons'

,p_group_id=>wwv_flow_imp.id(450113391425276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166705718276984)

,p_theme_id=>42

,p_name=>'DISPLAY_INITIALS'

,p_display_name=>'Display Initials'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--displayInitials'

,p_group_id=>wwv_flow_imp.id(450113391425276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166827242276985)

,p_theme_id=>42

,p_name=>'FEATURED'

,p_display_name=>'Featured'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--featured force-fa-lg'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450166988335276985)

,p_theme_id=>42

,p_name=>'BASIC'

,p_display_name=>'Basic'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--basic'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167015907276985)

,p_theme_id=>42

,p_name=>'COMPACT'

,p_display_name=>'Compact'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--compact'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

,p_help_text=>'Use this option when you want to show smaller cards.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167105489276985)

,p_theme_id=>42

,p_name=>'HIDDEN_BODY_TEXT'

,p_display_name=>'Hidden'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--hideBody'

,p_group_id=>wwv_flow_imp.id(450112255533276943)

,p_template_types=>'REPORT'

,p_help_text=>'This option hides the card body which contains description and subtext.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167210248276985)

,p_theme_id=>42

,p_name=>'ICONS_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--iconsSquare'

,p_group_id=>wwv_flow_imp.id(450113435400276943)

,p_template_types=>'REPORT'

,p_help_text=>'The icons are displayed within a square shape.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167315934276985)

,p_theme_id=>42

,p_name=>'ICONS_ROUNDED'

,p_display_name=>'Rounded Corners'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450165159206276983)

,p_css_classes=>'t-Cards--iconsRounded'

,p_group_id=>wwv_flow_imp.id(450113435400276943)

,p_template_types=>'REPORT'

,p_help_text=>'The icons are displayed within a square with rounded corners.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167655513276985)

,p_theme_id=>42

,p_name=>'COMPACT'

,p_display_name=>'Compact'

,p_display_sequence=>1

,p_report_template_id=>wwv_flow_imp.id(450167585374276985)

,p_css_classes=>'t-Timeline--compact'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

,p_help_text=>'Displays a compact version of timeline with smaller text and fewer columns.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167858884276986)

,p_theme_id=>42

,p_name=>'TITLE_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--hideTitle'

,p_group_id=>wwv_flow_imp.id(450112592358276943)

,p_template_types=>'REPORT'

,p_help_text=>'Hides the Title from being rendered on the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450167944254276986)

,p_theme_id=>42

,p_name=>'SELECTION_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--hideSelection'

,p_group_id=>wwv_flow_imp.id(450112862643276943)

,p_template_types=>'REPORT'

,p_help_text=>'Hides the Selection column from being rendered on the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168009030276986)

,p_theme_id=>42

,p_name=>'ICON_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--hideIcon'

,p_group_id=>wwv_flow_imp.id(450112663878276943)

,p_template_types=>'REPORT'

,p_help_text=>'Hides the Icon from being rendered on the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168186264276986)

,p_theme_id=>42

,p_name=>'DESCRIPTION_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--hideDescription'

,p_group_id=>wwv_flow_imp.id(450112485678276943)

,p_template_types=>'REPORT'

,p_help_text=>'Hides the Description from being rendered on the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168206442276986)

,p_theme_id=>42

,p_name=>'MISC_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--hideMisc'

,p_group_id=>wwv_flow_imp.id(450112784794276943)

,p_template_types=>'REPORT'

,p_help_text=>'Hides the Misc column from being rendered on the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168339085276986)

,p_theme_id=>42

,p_name=>'ACTIONS_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>60

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--hideActions'

,p_group_id=>wwv_flow_imp.id(450112374628276943)

,p_template_types=>'REPORT'

,p_help_text=>'Hides the Actions column from being rendered on the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168484806276986)

,p_theme_id=>42

,p_name=>'ALIGNMENT_TOP'

,p_display_name=>'Top'

,p_display_sequence=>100

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--alignTop'

,p_group_id=>wwv_flow_imp.id(450113038953276943)

,p_template_types=>'REPORT'

,p_help_text=>'Aligns the content to the top of the row. This is useful when you expect that yours rows will vary in height (e.g. some rows will have longer descriptions than others).'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168592810276986)

,p_theme_id=>42

,p_name=>'STYLE_COMPACT'

,p_display_name=>'Compact'

,p_display_sequence=>1

,p_report_template_id=>wwv_flow_imp.id(450167718477276985)

,p_css_classes=>'t-ContentRow--styleCompact'

,p_group_id=>wwv_flow_imp.id(450114144150276944)

,p_template_types=>'REPORT'

,p_help_text=>'This option reduces the padding and font sizes to present a compact display of the same information.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168753144276986)

,p_theme_id=>42

,p_name=>'LARGE'

,p_display_name=>'Large'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--large force-fa-lg'

,p_group_id=>wwv_flow_imp.id(450114039398276944)

,p_template_types=>'REPORT'

,p_help_text=>'Increases the size of the text and icons in the list.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168846638276987)

,p_theme_id=>42

,p_name=>'2_COLUMN_GRID'

,p_display_name=>'2 Column Grid'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--cols t-MediaList--2cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450168918224276987)

,p_theme_id=>42

,p_name=>'3_COLUMN_GRID'

,p_display_name=>'3 Column Grid'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--cols t-MediaList--3cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169096258276987)

,p_theme_id=>42

,p_name=>'4_COLUMN_GRID'

,p_display_name=>'4 Column Grid'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--cols t-MediaList--4cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169121303276987)

,p_theme_id=>42

,p_name=>'5_COLUMN_GRID'

,p_display_name=>'5 Column Grid'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--cols t-MediaList--5cols'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169230140276987)

,p_theme_id=>42

,p_name=>'STACK'

,p_display_name=>'Stack'

,p_display_sequence=>5

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--stack'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169365580276987)

,p_theme_id=>42

,p_name=>'SPAN_HORIZONTAL'

,p_display_name=>'Span Horizontal'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--horizontal'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169418692276987)

,p_theme_id=>42

,p_name=>'SHOW_ICONS'

,p_display_name=>'Show Icons'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--showIcons'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169554404276987)

,p_theme_id=>42

,p_name=>'SHOW_DESCRIPTION'

,p_display_name=>'Show Description'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--showDesc'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169647409276987)

,p_theme_id=>42

,p_name=>'SHOW_BADGES'

,p_display_name=>'Show Badges'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--showBadges'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169781826276987)

,p_theme_id=>42

,p_name=>'APPLY_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'u-colors'

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169848070276987)

,p_theme_id=>42

,p_name=>'ICONS_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--iconsSquare'

,p_group_id=>wwv_flow_imp.id(450113435400276943)

,p_template_types=>'REPORT'

,p_help_text=>'The icons are displayed within a square shape.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450169974855276987)

,p_theme_id=>42

,p_name=>'ICONS_ROUNDED'

,p_display_name=>'Rounded Corners'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450168604764276986)

,p_css_classes=>'t-MediaList--iconsRounded'

,p_group_id=>wwv_flow_imp.id(450113435400276943)

,p_template_types=>'REPORT'

,p_help_text=>'The icons are displayed within a square with rounded corners.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170183599276988)

,p_theme_id=>42

,p_name=>'FIXED_SMALL'

,p_display_name=>'Fixed - Small'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--fixedLabelSmall'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170207338276988)

,p_theme_id=>42

,p_name=>'FIXED_MEDIUM'

,p_display_name=>'Fixed - Medium'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--fixedLabelMedium'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170335729276988)

,p_theme_id=>42

,p_name=>'FIXED_LARGE'

,p_display_name=>'Fixed - Large'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--fixedLabelLarge'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170432907276988)

,p_theme_id=>42

,p_name=>'VARIABLE_LARGE'

,p_display_name=>'Variable - Large'

,p_display_sequence=>60

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--variableLabelLarge'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170512259276988)

,p_theme_id=>42

,p_name=>'VARIABLE_MEDIUM'

,p_display_name=>'Variable - Medium'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--variableLabelMedium'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170644814276988)

,p_theme_id=>42

,p_name=>'VARIABLE_SMALL'

,p_display_name=>'Variable - Small'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--variableLabelSmall'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170751706276988)

,p_theme_id=>42

,p_name=>'LEFT_ALIGNED_DETAILS'

,p_display_name=>'Left Aligned Details'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--leftAligned'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450170849055276988)

,p_theme_id=>42

,p_name=>'RIGHT_ALIGNED_DETAILS'

,p_display_name=>'Right Aligned Details'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450170098162276987)

,p_css_classes=>'t-AVPList--rightAligned'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171062605276989)

,p_theme_id=>42

,p_name=>'LEFT_ALIGNED_DETAILS'

,p_display_name=>'Left Aligned Details'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--leftAligned'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171181980276989)

,p_theme_id=>42

,p_name=>'RIGHT_ALIGNED_DETAILS'

,p_display_name=>'Right Aligned Details'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--rightAligned'

,p_group_id=>wwv_flow_imp.id(450113619176276944)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171261361276989)

,p_theme_id=>42

,p_name=>'FIXED_SMALL'

,p_display_name=>'Fixed - Small'

,p_display_sequence=>10

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--fixedLabelSmall'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171337585276989)

,p_theme_id=>42

,p_name=>'FIXED_MEDIUM'

,p_display_name=>'Fixed - Medium'

,p_display_sequence=>20

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--fixedLabelMedium'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171453576276989)

,p_theme_id=>42

,p_name=>'FIXED_LARGE'

,p_display_name=>'Fixed - Large'

,p_display_sequence=>30

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--fixedLabelLarge'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171514779276989)

,p_theme_id=>42

,p_name=>'VARIABLE_SMALL'

,p_display_name=>'Variable - Small'

,p_display_sequence=>40

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--variableLabelSmall'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171671099276989)

,p_theme_id=>42

,p_name=>'VARIABLE_MEDIUM'

,p_display_name=>'Variable - Medium'

,p_display_sequence=>50

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--variableLabelMedium'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171731146276989)

,p_theme_id=>42

,p_name=>'VARIABLE_LARGE'

,p_display_name=>'Variable - Large'

,p_display_sequence=>60

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--variableLabelLarge'

,p_group_id=>wwv_flow_imp.id(450113590495276943)

,p_template_types=>'REPORT'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450171848230276989)

,p_theme_id=>42

,p_name=>'HIDE_EMPTY_VALUES'

,p_display_name=>'Hide Empty Values'

,p_display_sequence=>70

,p_report_template_id=>wwv_flow_imp.id(450170901301276988)

,p_css_classes=>'t-AVPList--hideNulls'

,p_template_types=>'REPORT'

,p_help_text=>'This option will hide the null rows. Note: This only works in browsers that supports :has() pseudo-class.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172051269276990)

,p_theme_id=>42

,p_name=>'ALLSTEPS'

,p_display_name=>'All Steps'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450171962574276989)

,p_css_classes=>'t-WizardSteps--displayLabels'

,p_group_id=>wwv_flow_imp.id(450106214204276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172137911276990)

,p_theme_id=>42

,p_name=>'CURRENTSTEPONLY'

,p_display_name=>'Current Step Only'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450171962574276989)

,p_css_classes=>'t-WizardSteps--displayCurrentLabelOnly'

,p_group_id=>wwv_flow_imp.id(450106214204276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172267107276990)

,p_theme_id=>42

,p_name=>'HIDELABELS'

,p_display_name=>'Hide Labels'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450171962574276989)

,p_css_classes=>'t-WizardSteps--hideLabels'

,p_group_id=>wwv_flow_imp.id(450106214204276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172356248276990)

,p_theme_id=>42

,p_name=>'VERTICAL_LIST'

,p_display_name=>'Vertical Orientation'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450171962574276989)

,p_css_classes=>'t-WizardSteps--vertical'

,p_template_types=>'LIST'

,p_help_text=>'Displays the wizard progress list in a vertical orientation and is suitable for displaying within a side column of a page.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172471515276990)

,p_theme_id=>42

,p_name=>'WIZARD_PROGRESS_LINKS'

,p_display_name=>'Make Wizard Steps Clickable'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450171962574276989)

,p_css_classes=>'js-wizardProgressLinks'

,p_template_types=>'LIST'

,p_help_text=>'This option will make the wizard steps clickable links.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172698795276990)

,p_theme_id=>42

,p_name=>'2_COLUMNS'

,p_display_name=>'2 Columns'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--layout2Cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172799420276990)

,p_theme_id=>42

,p_name=>'3_COLUMNS'

,p_display_name=>'3 Columns'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--layout3Cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172822257276990)

,p_theme_id=>42

,p_name=>'4_COLUMNS'

,p_display_name=>'4 Columns'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--layout4Cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450172958084276991)

,p_theme_id=>42

,p_name=>'5_COLUMNS'

,p_display_name=>'5 Columns'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--layout5Cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173008008276991)

,p_theme_id=>42

,p_name=>'STACKED'

,p_display_name=>'Stacked'

,p_display_sequence=>60

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--layoutStacked'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173151013276991)

,p_theme_id=>42

,p_name=>'CUSTOM'

,p_display_name=>'Custom'

,p_display_sequence=>60

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--layoutCustom'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173221045276991)

,p_theme_id=>42

,p_name=>'DISPLAY_MENU_CALLOUT'

,p_display_name=>'Display Menu Callout'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'js-menu-callout'

,p_template_types=>'LIST'

,p_help_text=>'Displays a callout arrow that points to where the menu was activated from.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173398813276991)

,p_theme_id=>42

,p_name=>'ADD_ACTIONS'

,p_display_name=>'Add Actions'

,p_display_sequence=>1

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'js-addActions'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add shortcuts for menu items. Note that actions.js must be included on your page to support this functionality.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173492328276991)

,p_theme_id=>42

,p_name=>'FULL_WIDTH'

,p_display_name=>'Full Width'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450172577625276990)

,p_css_classes=>'t-MegaMenu--fullWidth'

,p_template_types=>'LIST'

,p_help_text=>'Stretches the menu to fill the width of the screen.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173648024276991)

,p_theme_id=>42

,p_name=>'DISPLAY_MENU_CALLOUT'

,p_display_name=>'Display Menu Callout'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450173596258276991)

,p_css_classes=>'js-menu-callout'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add display a callout for the menu.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173706088276991)

,p_theme_id=>42

,p_name=>'ADD_ACTIONS'

,p_display_name=>'Add Actions'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450173596258276991)

,p_css_classes=>'js-addActions'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add shortcuts for menu items. Note that actions.js must be included on your page to support this functionality.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173851947276991)

,p_theme_id=>42

,p_name=>'BEHAVE_LIKE_TABS'

,p_display_name=>'Behave Like Tabs'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450173596258276991)

,p_css_classes=>'js-tabLike'

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450173994485276991)

,p_theme_id=>42

,p_name=>'SHOW_SUB_MENU_ICONS'

,p_display_name=>'Show Sub Menu Icons'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450173596258276991)

,p_css_classes=>'js-showSubMenuIcons'

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174148424276991)

,p_theme_id=>42

,p_name=>'APPLY_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'u-colors'

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174280928276992)

,p_theme_id=>42

,p_name=>'CIRCULAR'

,p_display_name=>'Circular'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--circular'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174359101276992)

,p_theme_id=>42

,p_name=>'GRID'

,p_display_name=>'Grid'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--dash'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174486527276992)

,p_theme_id=>42

,p_name=>'FLOATITEMS'

,p_display_name=>'Float Items'

,p_display_sequence=>70

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--float'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Float badges to left'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174519113276992)

,p_theme_id=>42

,p_name=>'FLEXIBLEBOX'

,p_display_name=>'Flexible Box'

,p_display_sequence=>80

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--flex'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Use flexbox to arrange items'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174693243276992)

,p_theme_id=>42

,p_name=>'FIXED'

,p_display_name=>'Span Horizontally'

,p_display_sequence=>60

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--fixed'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Span badges horizontally'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174760486276992)

,p_theme_id=>42

,p_name=>'STACKED'

,p_display_name=>'Stacked'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--stacked'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Stack badges on top of each other'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174867077276992)

,p_theme_id=>42

,p_name=>'2COLUMNGRID'

,p_display_name=>'2 Column Grid'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Arrange badges in a two column grid'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450174999814276992)

,p_theme_id=>42

,p_name=>'3COLUMNGRID'

,p_display_name=>'3 Column Grid'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--cols t-BadgeList--3cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Arrange badges in a 3 column grid'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175037931276992)

,p_theme_id=>42

,p_name=>'4COLUMNGRID'

,p_display_name=>'4 Column Grid'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--cols t-BadgeList--4cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Arrange badges in 4 column grid'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175188592276992)

,p_theme_id=>42

,p_name=>'5COLUMNGRID'

,p_display_name=>'5 Column Grid'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--cols t-BadgeList--5cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Arrange badges in a 5 column grid'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175208854276992)

,p_theme_id=>42

,p_name=>'SMALL'

,p_display_name=>'32px'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--small'

,p_group_id=>wwv_flow_imp.id(450105572258276940)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175388884276993)

,p_theme_id=>42

,p_name=>'MEDIUM'

,p_display_name=>'48px'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--medium'

,p_group_id=>wwv_flow_imp.id(450105572258276940)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175441323276993)

,p_theme_id=>42

,p_name=>'LARGE'

,p_display_name=>'64px'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--large'

,p_group_id=>wwv_flow_imp.id(450105572258276940)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175594395276993)

,p_theme_id=>42

,p_name=>'XXLARGE'

,p_display_name=>'128px'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--xxlarge'

,p_group_id=>wwv_flow_imp.id(450105572258276940)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175609038276993)

,p_theme_id=>42

,p_name=>'XLARGE'

,p_display_name=>'96px'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450174026884276991)

,p_css_classes=>'t-BadgeList--xlarge'

,p_group_id=>wwv_flow_imp.id(450105572258276940)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175810227276993)

,p_theme_id=>42

,p_name=>'SPANHORIZONTAL'

,p_display_name=>'Span Horizontal'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--horizontal'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Show all list items in one horizontal row.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450175958103276993)

,p_theme_id=>42

,p_name=>'2COLUMNGRID'

,p_display_name=>'2 Column Grid'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--cols t-MediaList--2cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176010531276993)

,p_theme_id=>42

,p_name=>'3COLUMNGRID'

,p_display_name=>'3 Column Grid'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--cols t-MediaList--3cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176197762276994)

,p_theme_id=>42

,p_name=>'4COLUMNGRID'

,p_display_name=>'4 Column Grid'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--cols t-MediaList--4cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176240593276994)

,p_theme_id=>42

,p_name=>'5COLUMNGRID'

,p_display_name=>'5 Column Grid'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--cols t-MediaList--5cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176345488276994)

,p_theme_id=>42

,p_name=>'APPLY_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'u-colors'

,p_template_types=>'LIST'

,p_help_text=>'Applies colors from the Theme''s color palette to icons in the list.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176410570276994)

,p_theme_id=>42

,p_name=>'LIST_SIZE_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--large force-fa-lg'

,p_group_id=>wwv_flow_imp.id(450106537755276941)

,p_template_types=>'LIST'

,p_help_text=>'Increases the size of the text and icons in the list.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176586027276994)

,p_theme_id=>42

,p_name=>'SHOW_ICONS'

,p_display_name=>'Show Icons'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--showIcons'

,p_template_types=>'LIST'

,p_help_text=>'Display an icon next to the list item.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176641972276994)

,p_theme_id=>42

,p_name=>'SHOW_DESCRIPTION'

,p_display_name=>'Show Description'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--showDesc'

,p_template_types=>'LIST'

,p_help_text=>'Shows the description (Attribute 1) for each list item.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176712927276994)

,p_theme_id=>42

,p_name=>'SHOW_BADGES'

,p_display_name=>'Show Badges'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--showBadges'

,p_template_types=>'LIST'

,p_help_text=>'Show a badge (Attribute 2) to the right of the list item.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176838122276994)

,p_theme_id=>42

,p_name=>'ICONS_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--iconsSquare'

,p_group_id=>wwv_flow_imp.id(450106137223276941)

,p_template_types=>'LIST'

,p_help_text=>'The icons are displayed within a square shape.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450176989419276994)

,p_theme_id=>42

,p_name=>'ICONS_ROUNDED'

,p_display_name=>'Rounded Corners'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450175712119276993)

,p_css_classes=>'t-MediaList--iconsRounded'

,p_group_id=>wwv_flow_imp.id(450106137223276941)

,p_template_types=>'LIST'

,p_help_text=>'The icons are displayed within a square with rounded corners.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177141669276994)

,p_theme_id=>42

,p_name=>'DISPLAY_MENU_CALLOUT'

,p_display_name=>'Display Menu Callout'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450177091870276994)

,p_css_classes=>'js-menu-callout'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add display a callout for the menu.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177251812276994)

,p_theme_id=>42

,p_name=>'ADD_ACTIONS'

,p_display_name=>'Add Actions'

,p_display_sequence=>1

,p_list_template_id=>wwv_flow_imp.id(450177091870276994)

,p_css_classes=>'js-addActions'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add shortcuts for menu items. Note that actions.js must be included on your page to support this functionality.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177348588276994)

,p_theme_id=>42

,p_name=>'BEHAVE_LIKE_TABS'

,p_display_name=>'Behave Like Tabs'

,p_display_sequence=>1

,p_list_template_id=>wwv_flow_imp.id(450177091870276994)

,p_css_classes=>'js-tabLike'

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177423374276994)

,p_theme_id=>42

,p_name=>'SHOW_SUB_MENU_ICONS'

,p_display_name=>'Show Sub Menu Icons'

,p_display_sequence=>1

,p_list_template_id=>wwv_flow_imp.id(450177091870276994)

,p_css_classes=>'js-showSubMenuIcons'

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177607496276995)

,p_theme_id=>42

,p_name=>'COLLAPSE_STYLE_HIDDEN'

,p_display_name=>'Hidden'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'js-navCollapsed--hidden'

,p_group_id=>wwv_flow_imp.id(450105716161276940)

,p_template_types=>'LIST'

,p_help_text=>'Completely hide the navigation menu when it is collapsed.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177776868276995)

,p_theme_id=>42

,p_name=>'ADD_ACTIONS'

,p_display_name=>'Add Actions'

,p_display_sequence=>1

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'js-addActions'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add shortcuts for menu items. Note that actions.js must be included on your page to support this functionality.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177881927276995)

,p_theme_id=>42

,p_name=>'ICON_DEFAULT'

,p_display_name=>'Icon'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'js-navCollapsed--default'

,p_group_id=>wwv_flow_imp.id(450105716161276940)

,p_template_types=>'LIST'

,p_help_text=>'Display icons when the navigation menu is collapsed for large screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450177942028276995)

,p_theme_id=>42

,p_name=>'COLLAPSED_DEFAULT'

,p_display_name=>'Collapsed by Default'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'js-defaultCollapsed'

,p_template_types=>'LIST'

,p_help_text=>'This option will load the side navigation menu in a collapsed state by default.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178041913276995)

,p_theme_id=>42

,p_name=>'STYLE_A'

,p_display_name=>'Style A'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'t-TreeNav--styleA'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'Style Variation A'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178114069276995)

,p_theme_id=>42

,p_name=>'STYLE_B'

,p_display_name=>'Style B'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'t-TreeNav--styleB'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'Style Variation B'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178226189276995)

,p_theme_id=>42

,p_name=>'STYLE_C'

,p_display_name=>'Classic'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450177583652276995)

,p_css_classes=>'t-TreeNav--classic'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'Classic Style'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178479131276996)

,p_theme_id=>42

,p_name=>'DISPLAY_MENU_CALLOUT'

,p_display_name=>'Display Menu Callout'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178304573276995)

,p_css_classes=>'js-menu-callout'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add display a callout for the menu.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178614064276996)

,p_theme_id=>42

,p_name=>'DISPLAY_SUBTITLE'

,p_display_name=>'Display Subtitle'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--displaySubtitle'

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178717029276996)

,p_theme_id=>42

,p_name=>'BLOCK'

,p_display_name=>'Block'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--featured t-Cards--block force-fa-lg'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178860192276996)

,p_theme_id=>42

,p_name=>'CARDS_STACKED'

,p_display_name=>'Stacked'

,p_display_sequence=>5

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--stacked'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Stacks the cards on top of each other.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450178936872276996)

,p_theme_id=>42

,p_name=>'COLOR_FILL'

,p_display_name=>'Color Fill'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--animColorFill'

,p_group_id=>wwv_flow_imp.id(450105493084276940)

,p_template_types=>'LIST'

,p_help_text=>'Fills the card background with the color of the icon or default link style.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179080575276996)

,p_theme_id=>42

,p_name=>'RAISE_CARD'

,p_display_name=>'Raise Card'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--animRaiseCard'

,p_group_id=>wwv_flow_imp.id(450105493084276940)

,p_template_types=>'LIST'

,p_help_text=>'Raises the card so it pops up.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179147871276996)

,p_theme_id=>42

,p_name=>'SPAN_HORIZONTALLY'

,p_display_name=>'Span Horizontally'

,p_display_sequence=>70

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--spanHorizontally'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179227740276996)

,p_theme_id=>42

,p_name=>'FLOAT'

,p_display_name=>'Float'

,p_display_sequence=>60

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--float'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179319189276996)

,p_theme_id=>42

,p_name=>'2_COLUMNS'

,p_display_name=>'2 Columns'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179480675276996)

,p_theme_id=>42

,p_name=>'3_COLUMNS'

,p_display_name=>'3 Columns'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--3cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179563537276997)

,p_theme_id=>42

,p_name=>'4_COLUMNS'

,p_display_name=>'4 Columns'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--4cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179652721276997)

,p_theme_id=>42

,p_name=>'5_COLUMNS'

,p_display_name=>'5 Columns'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--5cols'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179734658276997)

,p_theme_id=>42

,p_name=>'FEATURED'

,p_display_name=>'Featured'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--featured force-fa-lg'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179829613276997)

,p_theme_id=>42

,p_name=>'BASIC'

,p_display_name=>'Basic'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--basic'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450179996373276997)

,p_theme_id=>42

,p_name=>'USE_THEME_COLORS'

,p_display_name=>'Apply Theme Colors'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'u-colors'

,p_template_types=>'LIST'

,p_help_text=>'Applies the colors from the theme''s color palette to the icons or initials within cards.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180012055276997)

,p_theme_id=>42

,p_name=>'DISPLAY_ICONS'

,p_display_name=>'Display Icons'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--displayIcons'

,p_group_id=>wwv_flow_imp.id(450106075759276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180152342276997)

,p_theme_id=>42

,p_name=>'DISPLAY_INITIALS'

,p_display_name=>'Display Initials'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--displayInitials'

,p_group_id=>wwv_flow_imp.id(450106075759276941)

,p_template_types=>'LIST'

,p_help_text=>'Initials come from List Attribute 3'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180244656276997)

,p_theme_id=>42

,p_name=>'2_LINES'

,p_display_name=>'2 Lines'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--desc-2ln'

,p_group_id=>wwv_flow_imp.id(450105661358276940)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180316401276997)

,p_theme_id=>42

,p_name=>'3_LINES'

,p_display_name=>'3 Lines'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--desc-3ln'

,p_group_id=>wwv_flow_imp.id(450105661358276940)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180475028276997)

,p_theme_id=>42

,p_name=>'4_LINES'

,p_display_name=>'4 Lines'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--desc-4ln'

,p_group_id=>wwv_flow_imp.id(450105661358276940)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180565781276997)

,p_theme_id=>42

,p_name=>'COMPACT'

,p_display_name=>'Compact'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--compact'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'Use this option when you want to show smaller cards.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180648867276997)

,p_theme_id=>42

,p_name=>'HIDDEN_BODY_TEXT'

,p_display_name=>'Hidden'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--hideBody'

,p_group_id=>wwv_flow_imp.id(450105661358276940)

,p_template_types=>'LIST'

,p_help_text=>'This option hides the card body which contains description and subtext.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180703947276997)

,p_theme_id=>42

,p_name=>'ICONS_SQUARE'

,p_display_name=>'Square'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--iconsSquare'

,p_group_id=>wwv_flow_imp.id(450106137223276941)

,p_template_types=>'LIST'

,p_help_text=>'The icons are displayed within a square shape.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450180881897276998)

,p_theme_id=>42

,p_name=>'ICONS_ROUNDED'

,p_display_name=>'Rounded Corners'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450178557191276996)

,p_css_classes=>'t-Cards--iconsRounded'

,p_group_id=>wwv_flow_imp.id(450106137223276941)

,p_template_types=>'LIST'

,p_help_text=>'The icons are displayed within a square with rounded corners.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181044636276998)

,p_theme_id=>42

,p_name=>'LARGE'

,p_display_name=>'Large'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--large'

,p_group_id=>wwv_flow_imp.id(450106537755276941)

,p_template_types=>'LIST'

,p_help_text=>'Increases font size and white space around tab items.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181163902276998)

,p_theme_id=>42

,p_name=>'PILL'

,p_display_name=>'Pill'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--pill'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'Displays tabs in a pill container.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181267473276998)

,p_theme_id=>42

,p_name=>'INLINE_WITH_LABEL'

,p_display_name=>'Inline with Label'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--inlineIcons'

,p_group_id=>wwv_flow_imp.id(450106075759276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181300733276998)

,p_theme_id=>42

,p_name=>'ABOVE_LABEL'

,p_display_name=>'Above Label'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--iconsAbove'

,p_group_id=>wwv_flow_imp.id(450106075759276941)

,p_template_types=>'LIST'

,p_help_text=>'Places icons above tab label.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181498629276998)

,p_theme_id=>42

,p_name=>'FILL_LABELS'

,p_display_name=>'Fill Labels'

,p_display_sequence=>1

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--fillLabels'

,p_group_id=>wwv_flow_imp.id(450106398871276941)

,p_template_types=>'LIST'

,p_help_text=>'Stretch tabs to fill to the width of the tabs container.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181552529276998)

,p_theme_id=>42

,p_name=>'SMALL'

,p_display_name=>'Small'

,p_display_sequence=>5

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--small'

,p_group_id=>wwv_flow_imp.id(450106537755276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181644831276998)

,p_theme_id=>42

,p_name=>'SIMPLE'

,p_display_name=>'Simple'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450180939701276998)

,p_css_classes=>'t-Tabs--simple'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'A very simplistic tab UI.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181814068276999)

,p_theme_id=>42

,p_name=>'DISPLAY_MENU_CALLOUT'

,p_display_name=>'Display Menu Callout'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450181738537276998)

,p_css_classes=>'js-menu-callout'

,p_template_types=>'LIST'

,p_help_text=>'Use this option to add display a callout for the menu. Note that callout will only be displayed if the data-parent-element custom attribute is defined.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450181924352276999)

,p_theme_id=>42

,p_name=>'ADD_ACTIONS'

,p_display_name=>'Add Actions'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450181738537276998)

,p_css_classes=>'js-addActions'

,p_template_types=>'LIST'

,p_help_text=>'Enables you to define a keyboard shortcut to activate the menu item.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182126764276999)

,p_theme_id=>42

,p_name=>'SHOWICONS'

,p_display_name=>'For All Items'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450182025754276999)

,p_css_classes=>'t-LinksList--showIcons'

,p_group_id=>wwv_flow_imp.id(450105966364276940)

,p_template_types=>'LIST'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182254565276999)

,p_theme_id=>42

,p_name=>'SHOWGOTOARROW'

,p_display_name=>'Show Right Arrow'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450182025754276999)

,p_css_classes=>'t-LinksList--showArrow'

,p_template_types=>'LIST'

,p_help_text=>'Show arrow to the right of link'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182342025276999)

,p_theme_id=>42

,p_name=>'DISABLETEXTWRAPPING'

,p_display_name=>'Disable Text Wrapping'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450182025754276999)

,p_css_classes=>'t-LinksList--nowrap'

,p_template_types=>'LIST'

,p_help_text=>'Do not allow link text to wrap to new lines. Truncate with ellipsis.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182442476276999)

,p_theme_id=>42

,p_name=>'SHOWBADGES'

,p_display_name=>'Show Badges'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450182025754276999)

,p_css_classes=>'t-LinksList--showBadge'

,p_template_types=>'LIST'

,p_help_text=>'Show badge to right of link (requires Attribute 1 to be populated)'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182513129276999)

,p_theme_id=>42

,p_name=>'SHOWTOPICONS'

,p_display_name=>'For Top Level Items Only'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450182025754276999)

,p_css_classes=>'t-LinksList--showTopIcons'

,p_group_id=>wwv_flow_imp.id(450105966364276940)

,p_template_types=>'LIST'

,p_help_text=>'This will show icons for top level items of the list only. It will not show icons for sub lists.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182698924276999)

,p_theme_id=>42

,p_name=>'ACTIONS'

,p_display_name=>'Actions'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450182025754276999)

,p_css_classes=>'t-LinksList--actions'

,p_group_id=>wwv_flow_imp.id(450106634640276941)

,p_template_types=>'LIST'

,p_help_text=>'Render as actions to be placed on the right side column.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182834903277000)

,p_theme_id=>42

,p_name=>'LABEL_INLINE_LG'

,p_display_name=>'Display labels inline'

,p_display_sequence=>10

,p_list_template_id=>wwv_flow_imp.id(450182753600277000)

,p_css_classes=>'t-NavTabs--inlineLabels-lg'

,p_group_id=>wwv_flow_imp.id(450105815531276940)

,p_template_types=>'LIST'

,p_help_text=>'Display the label inline with the icon and badge'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450182935993277000)

,p_theme_id=>42

,p_name=>'LABEL_ABOVE_LG'

,p_display_name=>'Display labels above'

,p_display_sequence=>20

,p_list_template_id=>wwv_flow_imp.id(450182753600277000)

,p_css_classes=>'t-NavTabs--stacked'

,p_group_id=>wwv_flow_imp.id(450105815531276940)

,p_template_types=>'LIST'

,p_help_text=>'Display the label stacked above the icon and badge'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450183071097277000)

,p_theme_id=>42

,p_name=>'NO_LABEL_LG'

,p_display_name=>'Do not display labels'

,p_display_sequence=>30

,p_list_template_id=>wwv_flow_imp.id(450182753600277000)

,p_css_classes=>'t-NavTabs--hiddenLabels-lg'

,p_group_id=>wwv_flow_imp.id(450105815531276940)

,p_template_types=>'LIST'

,p_help_text=>'Hides the label for the list item'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450183160335277000)

,p_theme_id=>42

,p_name=>'DISPLAY_LABELS_SM'

,p_display_name=>'Display labels'

,p_display_sequence=>40

,p_list_template_id=>wwv_flow_imp.id(450182753600277000)

,p_css_classes=>'t-NavTabs--displayLabels-sm'

,p_group_id=>wwv_flow_imp.id(450106476686276941)

,p_template_types=>'LIST'

,p_help_text=>'Displays the label for the list items below the icon'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450183247215277000)

,p_theme_id=>42

,p_name=>'HIDE_LABELS_SM'

,p_display_name=>'Do not display labels'

,p_display_sequence=>50

,p_list_template_id=>wwv_flow_imp.id(450182753600277000)

,p_css_classes=>'t-NavTabs--hiddenLabels-sm'

,p_group_id=>wwv_flow_imp.id(450106476686276941)

,p_template_types=>'LIST'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450183552706277001)

,p_theme_id=>42

,p_name=>'INDICATOR_ASTERISK'

,p_display_name=>'Asterisk'

,p_display_sequence=>10

,p_field_template_id=>wwv_flow_imp.id(450183409494277001)

,p_css_classes=>'t-Form-fieldContainer--indicatorAsterisk'

,p_group_id=>wwv_flow_imp.id(450105037943276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays an asterisk * on required items.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450183698227277001)

,p_theme_id=>42

,p_name=>'INDICATOR_LABEL'

,p_display_name=>'Inline Label'

,p_display_sequence=>20

,p_field_template_id=>wwv_flow_imp.id(450183409494277001)

,p_css_classes=>'t-Form-fieldContainer--indicatorLabel'

,p_group_id=>wwv_flow_imp.id(450105037943276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays "Required" inline.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450184068268277001)

,p_theme_id=>42

,p_name=>'INDICATOR_ASTERISK'

,p_display_name=>'Asterisk'

,p_display_sequence=>10

,p_field_template_id=>wwv_flow_imp.id(450183937310277001)

,p_css_classes=>'t-Form-fieldContainer--indicatorAsterisk'

,p_group_id=>wwv_flow_imp.id(450105037943276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays an asterisk * on required items.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450184120019277002)

,p_theme_id=>42

,p_name=>'INDICATOR_LABEL'

,p_display_name=>'Inline Label'

,p_display_sequence=>20

,p_field_template_id=>wwv_flow_imp.id(450183937310277001)

,p_css_classes=>'t-Form-fieldContainer--indicatorLabel'

,p_group_id=>wwv_flow_imp.id(450105037943276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays "Required" inline.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450184460888277002)

,p_theme_id=>42

,p_name=>'INDICATOR_ASTERISK'

,p_display_name=>'Asterisk'

,p_display_sequence=>10

,p_field_template_id=>wwv_flow_imp.id(450184356084277002)

,p_css_classes=>'t-Form-fieldContainer--indicatorAsterisk'

,p_group_id=>wwv_flow_imp.id(450105037943276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays an asterisk * on required items.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450184574947277002)

,p_theme_id=>42

,p_name=>'INDICATOR_LABEL'

,p_display_name=>'Inline Label'

,p_display_sequence=>20

,p_field_template_id=>wwv_flow_imp.id(450184356084277002)

,p_css_classes=>'t-Form-fieldContainer--indicatorLabel'

,p_group_id=>wwv_flow_imp.id(450105037943276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays "Required" inline.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450184749056277002)

,p_theme_id=>42

,p_name=>'SPIN'

,p_display_name=>'Spin'

,p_display_sequence=>10

,p_button_template_id=>wwv_flow_imp.id(450184618947277002)

,p_css_classes=>'t-Button--hoverIconSpin'

,p_group_id=>wwv_flow_imp.id(450103307255276939)

,p_template_types=>'BUTTON'

,p_help_text=>'The icon will spin on button hover or focus.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450184808515277003)

,p_theme_id=>42

,p_name=>'PUSH'

,p_display_name=>'Push'

,p_display_sequence=>20

,p_button_template_id=>wwv_flow_imp.id(450184618947277002)

,p_css_classes=>'t-Button--hoverIconPush'

,p_group_id=>wwv_flow_imp.id(450103307255276939)

,p_template_types=>'BUTTON'

,p_help_text=>'The icon will animate to the right or left on button hover or focus.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450185105972277003)

,p_theme_id=>42

,p_name=>'LEFTICON'

,p_display_name=>'Left'

,p_display_sequence=>10

,p_button_template_id=>wwv_flow_imp.id(450185093093277003)

,p_css_classes=>'t-Button--iconLeft'

,p_group_id=>wwv_flow_imp.id(450103495027276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450185266282277003)

,p_theme_id=>42

,p_name=>'RIGHTICON'

,p_display_name=>'Right'

,p_display_sequence=>20

,p_button_template_id=>wwv_flow_imp.id(450185093093277003)

,p_css_classes=>'t-Button--iconRight'

,p_group_id=>wwv_flow_imp.id(450103495027276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450185307281277003)

,p_theme_id=>42

,p_name=>'HIDE_ICON_ON_DESKTOP'

,p_display_name=>'Hide Icon on Desktop'

,p_display_sequence=>20

,p_button_template_id=>wwv_flow_imp.id(450185093093277003)

,p_css_classes=>'t-Button--desktopHideIcon'

,p_template_types=>'BUTTON'

,p_help_text=>'This template options hides the button icon on large screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450185420611277003)

,p_theme_id=>42

,p_name=>'HIDE_LABEL_ON_MOBILE'

,p_display_name=>'Hide Label on Mobile'

,p_display_sequence=>10

,p_button_template_id=>wwv_flow_imp.id(450185093093277003)

,p_css_classes=>'t-Button--mobileHideLabel'

,p_template_types=>'BUTTON'

,p_help_text=>'This template options hides the button label on small screens.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450185553005277003)

,p_theme_id=>42

,p_name=>'SPIN'

,p_display_name=>'Spin'

,p_display_sequence=>10

,p_button_template_id=>wwv_flow_imp.id(450185093093277003)

,p_css_classes=>'t-Button--hoverIconSpin'

,p_group_id=>wwv_flow_imp.id(450103307255276939)

,p_template_types=>'BUTTON'

,p_help_text=>'The icon will spin on button hover or focus.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(450185670031277003)

,p_theme_id=>42

,p_name=>'PUSH'

,p_display_name=>'Push'

,p_display_sequence=>20

,p_button_template_id=>wwv_flow_imp.id(450185093093277003)

,p_css_classes=>'t-Button--hoverIconPush'

,p_group_id=>wwv_flow_imp.id(450103307255276939)

,p_template_types=>'BUTTON'

,p_help_text=>'The icon will animate to the right or left on button hover or focus.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709130382277212)

,p_theme_id=>42

,p_name=>'DEFERRED_PAGE_RENDERING'

,p_display_name=>'Deferred Page Rendering'

,p_display_sequence=>1

,p_css_classes=>'t-DeferredRendering'

,p_template_types=>'PAGE'

,p_help_text=>'Defer page rendering until all page components have finished loading.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709204891277212)

,p_theme_id=>42

,p_name=>'HIDE_WHEN_ALL_ROWS_DISPLAYED'

,p_display_name=>'Hide when all rows displayed'

,p_display_sequence=>10

,p_css_classes=>'t-Report--hideNoPagination'

,p_group_id=>wwv_flow_imp.id(450113760222276944)

,p_template_types=>'REPORT'

,p_help_text=>'This option will hide the pagination when all rows are displayed.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709320407277212)

,p_theme_id=>42

,p_name=>'HEADING_LEVEL_H1'

,p_display_name=>'H1'

,p_display_sequence=>10

,p_css_classes=>'js-headingLevel-1'

,p_group_id=>wwv_flow_imp.id(450109227132276942)

,p_template_types=>'REGION'

,p_help_text=>'H1'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709420465277212)

,p_theme_id=>42

,p_name=>'HEADING_LEVEL_H2'

,p_display_name=>'H2'

,p_display_sequence=>20

,p_css_classes=>'js-headingLevel-2'

,p_group_id=>wwv_flow_imp.id(450109227132276942)

,p_template_types=>'REGION'

,p_help_text=>'H2'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709532099277212)

,p_theme_id=>42

,p_name=>'HEADING_LEVEL_H3'

,p_display_name=>'H3'

,p_display_sequence=>30

,p_css_classes=>'js-headingLevel-3'

,p_group_id=>wwv_flow_imp.id(450109227132276942)

,p_template_types=>'REGION'

,p_help_text=>'H3'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709649590277212)

,p_theme_id=>42

,p_name=>'H4'

,p_display_name=>'H4'

,p_display_sequence=>40

,p_css_classes=>'js-headingLevel-4'

,p_group_id=>wwv_flow_imp.id(450109227132276942)

,p_template_types=>'REGION'

,p_help_text=>'H4'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709790260277213)

,p_theme_id=>42

,p_name=>'HEADING_LEVEL_H5'

,p_display_name=>'H5'

,p_display_sequence=>50

,p_css_classes=>'js-headingLevel-5'

,p_group_id=>wwv_flow_imp.id(450109227132276942)

,p_template_types=>'REGION'

,p_help_text=>'H5'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709865994277213)

,p_theme_id=>42

,p_name=>'HEADING_LEVEL_H6'

,p_display_name=>'H6'

,p_display_sequence=>60

,p_css_classes=>'js-headingLevel-6'

,p_group_id=>wwv_flow_imp.id(450109227132276942)

,p_template_types=>'REGION'

,p_help_text=>'H6'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415709914419277213)

,p_theme_id=>42

,p_name=>'DISPLAY_TEXT_STYLE_BOLD'

,p_display_name=>'Bold'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--boldDisplay'

,p_group_id=>wwv_flow_imp.id(450104441517276940)

,p_template_types=>'FIELD'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710086855277213)

,p_theme_id=>42

,p_name=>'DISPLAY_TEXT_STYLE_NORMAL'

,p_display_name=>'Normal'

,p_display_sequence=>20

,p_css_classes=>'t-Form-fieldContainer--normalDisplay'

,p_group_id=>wwv_flow_imp.id(450104441517276940)

,p_template_types=>'FIELD'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710110507277213)

,p_theme_id=>42

,p_name=>'REMOVE_PADDING'

,p_display_name=>'Remove Padding'

,p_display_sequence=>1

,p_css_classes=>'t-PageBody--noContentPadding'

,p_group_id=>wwv_flow_imp.id(450106797191276941)

,p_template_types=>'PAGE'

,p_help_text=>'Removes padding from the content region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710226815277213)

,p_theme_id=>42

,p_name=>'DISPLAY_AS_LINK'

,p_display_name=>'Display as Link'

,p_display_sequence=>30

,p_css_classes=>'t-Button--link'

,p_group_id=>wwv_flow_imp.id(450104079290276940)

,p_template_types=>'BUTTON'

,p_help_text=>'This option makes the button appear as a text link.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710323578277213)

,p_theme_id=>42

,p_name=>'SMALLTOPMARGIN'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_css_classes=>'t-Button--padTop'

,p_group_id=>wwv_flow_imp.id(450103982834276940)

,p_template_types=>'BUTTON'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710434918277213)

,p_theme_id=>42

,p_name=>'LARGETOPMARGIN'

,p_display_name=>'Large'

,p_display_sequence=>20

,p_css_classes=>'t-Button--gapTop'

,p_group_id=>wwv_flow_imp.id(450103982834276940)

,p_template_types=>'BUTTON'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710599907277213)

,p_theme_id=>42

,p_name=>'SMALLBOTTOMMARGIN'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_css_classes=>'t-Button--padBottom'

,p_group_id=>wwv_flow_imp.id(450103645335276940)

,p_template_types=>'BUTTON'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710632044277214)

,p_theme_id=>42

,p_name=>'LARGEBOTTOMMARGIN'

,p_display_name=>'Large'

,p_display_sequence=>20

,p_css_classes=>'t-Button--gapBottom'

,p_group_id=>wwv_flow_imp.id(450103645335276940)

,p_template_types=>'BUTTON'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710741118277214)

,p_theme_id=>42

,p_name=>'TINY'

,p_display_name=>'Tiny'

,p_display_sequence=>10

,p_css_classes=>'t-Button--tiny'

,p_group_id=>wwv_flow_imp.id(450103599350276940)

,p_template_types=>'BUTTON'

,p_help_text=>'A very small button.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710851862277214)

,p_theme_id=>42

,p_name=>'FORMSTANDARDPADDING'

,p_display_name=>'Standard'

,p_display_sequence=>5

,p_css_classes=>'t-Form--standardPadding'

,p_group_id=>wwv_flow_imp.id(450110014338276943)

,p_template_types=>'REGION'

,p_help_text=>'Uses the standard spacing between items.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415710927718277214)

,p_theme_id=>42

,p_name=>'PRIMARY'

,p_display_name=>'Primary'

,p_display_sequence=>10

,p_css_classes=>'t-Button--primary'

,p_group_id=>wwv_flow_imp.id(450104144288276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711031750277214)

,p_theme_id=>42

,p_name=>'STRETCH'

,p_display_name=>'Stretch'

,p_display_sequence=>10

,p_css_classes=>'t-Button--stretch'

,p_group_id=>wwv_flow_imp.id(450104295402276940)

,p_template_types=>'BUTTON'

,p_help_text=>'Stretches button to fill container'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711176677277214)

,p_theme_id=>42

,p_name=>'DANGER'

,p_display_name=>'Danger'

,p_display_sequence=>30

,p_css_classes=>'t-Button--danger'

,p_group_id=>wwv_flow_imp.id(450104144288276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711248412277214)

,p_theme_id=>42

,p_name=>'SUCCESS'

,p_display_name=>'Success'

,p_display_sequence=>40

,p_css_classes=>'t-Button--success'

,p_group_id=>wwv_flow_imp.id(450104144288276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711325060277214)

,p_theme_id=>42

,p_name=>'NOUI'

,p_display_name=>'Remove UI Decoration'

,p_display_sequence=>20

,p_css_classes=>'t-Button--noUI'

,p_group_id=>wwv_flow_imp.id(450104079290276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711443319277214)

,p_theme_id=>42

,p_name=>'LARGE'

,p_display_name=>'Large'

,p_display_sequence=>30

,p_css_classes=>'t-Button--large'

,p_group_id=>wwv_flow_imp.id(450103599350276940)

,p_template_types=>'BUTTON'

,p_help_text=>'A large button.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711580130277214)

,p_theme_id=>42

,p_name=>'SMALLLEFTMARGIN'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_css_classes=>'t-Button--padLeft'

,p_group_id=>wwv_flow_imp.id(450103738330276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711647876277214)

,p_theme_id=>42

,p_name=>'SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'t-Button--small'

,p_group_id=>wwv_flow_imp.id(450103599350276940)

,p_template_types=>'BUTTON'

,p_help_text=>'A small button.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711754219277215)

,p_theme_id=>42

,p_name=>'WARNING'

,p_display_name=>'Warning'

,p_display_sequence=>20

,p_css_classes=>'t-Button--warning'

,p_group_id=>wwv_flow_imp.id(450104144288276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711895591277215)

,p_theme_id=>42

,p_name=>'SIMPLE'

,p_display_name=>'Simple'

,p_display_sequence=>10

,p_css_classes=>'t-Button--simple'

,p_group_id=>wwv_flow_imp.id(450104079290276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415711998080277215)

,p_theme_id=>42

,p_name=>'LARGELEFTMARGIN'

,p_display_name=>'Large'

,p_display_sequence=>20

,p_css_classes=>'t-Button--gapLeft'

,p_group_id=>wwv_flow_imp.id(450103738330276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712048425277215)

,p_theme_id=>42

,p_name=>'SMALLRIGHTMARGIN'

,p_display_name=>'Small'

,p_display_sequence=>10

,p_css_classes=>'t-Button--padRight'

,p_group_id=>wwv_flow_imp.id(450103890491276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712130416277215)

,p_theme_id=>42

,p_name=>'LARGERIGHTMARGIN'

,p_display_name=>'Large'

,p_display_sequence=>20

,p_css_classes=>'t-Button--gapRight'

,p_group_id=>wwv_flow_imp.id(450103890491276940)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712244037277215)

,p_theme_id=>42

,p_name=>'PILLSTART'

,p_display_name=>'First Button'

,p_display_sequence=>10

,p_css_classes=>'t-Button--pillStart'

,p_group_id=>wwv_flow_imp.id(450103256250276939)

,p_template_types=>'BUTTON'

,p_help_text=>'Use this for the start of a pill button.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712398234277215)

,p_theme_id=>42

,p_name=>'PILL'

,p_display_name=>'Inner Button'

,p_display_sequence=>20

,p_css_classes=>'t-Button--pill'

,p_group_id=>wwv_flow_imp.id(450103256250276939)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712446271277216)

,p_theme_id=>42

,p_name=>'PILLEND'

,p_display_name=>'Last Button'

,p_display_sequence=>30

,p_css_classes=>'t-Button--pillEnd'

,p_group_id=>wwv_flow_imp.id(450103256250276939)

,p_template_types=>'BUTTON'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712584495277216)

,p_theme_id=>42

,p_name=>'FORMLEFTLABELS'

,p_display_name=>'Left'

,p_display_sequence=>20

,p_css_classes=>'t-Form--leftLabels'

,p_group_id=>wwv_flow_imp.id(450110393103276943)

,p_template_types=>'REGION'

,p_help_text=>'Align form labels to left.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712678820277216)

,p_theme_id=>42

,p_name=>'FORMSIZELARGE'

,p_display_name=>'Large'

,p_display_sequence=>10

,p_css_classes=>'t-Form--large'

,p_group_id=>wwv_flow_imp.id(450110155211276943)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712716407277216)

,p_theme_id=>42

,p_name=>'FORMSIZEXLARGE'

,p_display_name=>'X Large'

,p_display_sequence=>20

,p_css_classes=>'t-Form--xlarge'

,p_group_id=>wwv_flow_imp.id(450110155211276943)

,p_template_types=>'REGION'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712800442277216)

,p_theme_id=>42

,p_name=>'FORMSLIMPADDING'

,p_display_name=>'Slim'

,p_display_sequence=>10

,p_css_classes=>'t-Form--slimPadding'

,p_group_id=>wwv_flow_imp.id(450110014338276943)

,p_template_types=>'REGION'

,p_help_text=>'Reduces form item spacing.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415712943195277216)

,p_theme_id=>42

,p_name=>'FORMREMOVEPADDING'

,p_display_name=>'None'

,p_display_sequence=>20

,p_css_classes=>'t-Form--noPadding'

,p_group_id=>wwv_flow_imp.id(450110014338276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes spacing between items.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713083711277216)

,p_theme_id=>42

,p_name=>'SHOWFORMLABELSABOVE'

,p_display_name=>'Show Form Labels Above'

,p_display_sequence=>10

,p_css_classes=>'t-Form--labelsAbove'

,p_group_id=>wwv_flow_imp.id(450110486960276943)

,p_template_types=>'REGION'

,p_help_text=>'Show form labels above input fields.'

,p_is_advanced=>'N'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713119844277216)

,p_theme_id=>42

,p_name=>'STRETCH_FORM_FIELDS'

,p_display_name=>'Stretch Form Fields'

,p_display_sequence=>10

,p_css_classes=>'t-Form--stretchInputs'

,p_group_id=>wwv_flow_imp.id(450110265697276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713279876277216)

,p_theme_id=>42

,p_name=>'PRE_TEXT_BLOCK'

,p_display_name=>'Display as Block'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--preTextBlock'

,p_group_id=>wwv_flow_imp.id(450104635693276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays the Item Pre Text in a block style immediately before the item.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713345402277216)

,p_theme_id=>42

,p_name=>'POST_TEXT_BLOCK'

,p_display_name=>'Display as Block'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--postTextBlock'

,p_group_id=>wwv_flow_imp.id(450104529239276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays the Item Post Text in a block style immediately after the item.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713481141277216)

,p_theme_id=>42

,p_name=>'RTM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-top-none'

,p_group_id=>wwv_flow_imp.id(450111269993276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes the top margin for this region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713580520277216)

,p_theme_id=>42

,p_name=>'RTM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-top-sm'

,p_group_id=>wwv_flow_imp.id(450111269993276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a small top margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713616885277217)

,p_theme_id=>42

,p_name=>'RTM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-top-md'

,p_group_id=>wwv_flow_imp.id(450111269993276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a medium top margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713753015277217)

,p_theme_id=>42

,p_name=>'RTM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-top-lg'

,p_group_id=>wwv_flow_imp.id(450111269993276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a large top margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713869802277217)

,p_theme_id=>42

,p_name=>'RBM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-bottom-none'

,p_group_id=>wwv_flow_imp.id(450110713791276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes the bottom margin for this region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415713960643277217)

,p_theme_id=>42

,p_name=>'RBM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-bottom-sm'

,p_group_id=>wwv_flow_imp.id(450110713791276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a small bottom margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714052291277217)

,p_theme_id=>42

,p_name=>'RBM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-bottom-md'

,p_group_id=>wwv_flow_imp.id(450110713791276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a medium bottom margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714170054277217)

,p_theme_id=>42

,p_name=>'RBM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-bottom-lg'

,p_group_id=>wwv_flow_imp.id(450110713791276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a large bottom margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714256939277217)

,p_theme_id=>42

,p_name=>'RRM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-right-none'

,p_group_id=>wwv_flow_imp.id(450111017605276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes the right margin from the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714355594277217)

,p_theme_id=>42

,p_name=>'RRM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-right-sm'

,p_group_id=>wwv_flow_imp.id(450111017605276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a small right margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714451979277218)

,p_theme_id=>42

,p_name=>'RRM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-right-md'

,p_group_id=>wwv_flow_imp.id(450111017605276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a medium right margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714526725277218)

,p_theme_id=>42

,p_name=>'RRM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-right-lg'

,p_group_id=>wwv_flow_imp.id(450111017605276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a large right margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714682176277218)

,p_theme_id=>42

,p_name=>'RLM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-left-none'

,p_group_id=>wwv_flow_imp.id(450110833040276943)

,p_template_types=>'REGION'

,p_help_text=>'Removes the left margin from the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714741110277218)

,p_theme_id=>42

,p_name=>'RLM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-left-sm'

,p_group_id=>wwv_flow_imp.id(450110833040276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a small left margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714836197277218)

,p_theme_id=>42

,p_name=>'RLM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-left-md'

,p_group_id=>wwv_flow_imp.id(450110833040276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a medium right margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415714958127277218)

,p_theme_id=>42

,p_name=>'RLM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-left-lg'

,p_group_id=>wwv_flow_imp.id(450110833040276943)

,p_template_types=>'REGION'

,p_help_text=>'Adds a large right margin to the region.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715042452277218)

,p_theme_id=>42

,p_name=>'FBM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-bottom-none'

,p_group_id=>wwv_flow_imp.id(450104345858276940)

,p_template_types=>'FIELD'

,p_help_text=>'Removes the bottom margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715161508277218)

,p_theme_id=>42

,p_name=>'FBM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-bottom-sm'

,p_group_id=>wwv_flow_imp.id(450104345858276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a small bottom margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715238415277218)

,p_theme_id=>42

,p_name=>'FBM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-bottom-md'

,p_group_id=>wwv_flow_imp.id(450104345858276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a medium bottom margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715323449277219)

,p_theme_id=>42

,p_name=>'FBM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-bottom-lg'

,p_group_id=>wwv_flow_imp.id(450104345858276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a large bottom margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715404456277219)

,p_theme_id=>42

,p_name=>'FLM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-left-none'

,p_group_id=>wwv_flow_imp.id(450104844443276940)

,p_template_types=>'FIELD'

,p_help_text=>'Removes the left margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715522695277219)

,p_theme_id=>42

,p_name=>'FLM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-left-sm'

,p_group_id=>wwv_flow_imp.id(450104844443276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a small left margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715640846277219)

,p_theme_id=>42

,p_name=>'FLM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-left-md'

,p_group_id=>wwv_flow_imp.id(450104844443276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a medium left margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715751197277219)

,p_theme_id=>42

,p_name=>'FLM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-left-lg'

,p_group_id=>wwv_flow_imp.id(450104844443276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a large left margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715875010277219)

,p_theme_id=>42

,p_name=>'FRM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-right-none'

,p_group_id=>wwv_flow_imp.id(450105176521276940)

,p_template_types=>'FIELD'

,p_help_text=>'Removes the right margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415715963007277219)

,p_theme_id=>42

,p_name=>'FRM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-right-sm'

,p_group_id=>wwv_flow_imp.id(450105176521276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a small right margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716094359277220)

,p_theme_id=>42

,p_name=>'FRM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-right-md'

,p_group_id=>wwv_flow_imp.id(450105176521276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a medium right margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716123760277220)

,p_theme_id=>42

,p_name=>'FRM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-right-lg'

,p_group_id=>wwv_flow_imp.id(450105176521276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a large right margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716200329277220)

,p_theme_id=>42

,p_name=>'FTM_NONE'

,p_display_name=>'None'

,p_display_sequence=>10

,p_css_classes=>'margin-top-none'

,p_group_id=>wwv_flow_imp.id(450105355420276940)

,p_template_types=>'FIELD'

,p_help_text=>'Removes the top margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716301098277220)

,p_theme_id=>42

,p_name=>'FTM_SMALL'

,p_display_name=>'Small'

,p_display_sequence=>20

,p_css_classes=>'margin-top-sm'

,p_group_id=>wwv_flow_imp.id(450105355420276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a small top margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716403991277220)

,p_theme_id=>42

,p_name=>'FTM_MEDIUM'

,p_display_name=>'Medium'

,p_display_sequence=>30

,p_css_classes=>'margin-top-md'

,p_group_id=>wwv_flow_imp.id(450105355420276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a medium top margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716553775277220)

,p_theme_id=>42

,p_name=>'FTM_LARGE'

,p_display_name=>'Large'

,p_display_sequence=>40

,p_css_classes=>'margin-top-lg'

,p_group_id=>wwv_flow_imp.id(450105355420276940)

,p_template_types=>'FIELD'

,p_help_text=>'Adds a large top margin for this field.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716632759277220)

,p_theme_id=>42

,p_name=>'DISPLAY_AS_PILL_BUTTON'

,p_display_name=>'Display as Pill Button'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--radioButtonGroup'

,p_group_id=>wwv_flow_imp.id(450104999219276940)

,p_template_types=>'FIELD'

,p_help_text=>'Displays the radio buttons to look like a button set / pill button.  Note that the the radio buttons must all be in the same row for this option to work.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716747760277220)

,p_theme_id=>42

,p_name=>'LARGE_FIELD'

,p_display_name=>'Large'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--large'

,p_group_id=>wwv_flow_imp.id(450105213171276940)

,p_template_types=>'FIELD'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716894945277221)

,p_theme_id=>42

,p_name=>'X_LARGE_SIZE'

,p_display_name=>'X Large'

,p_display_sequence=>20

,p_css_classes=>'t-Form-fieldContainer--xlarge'

,p_group_id=>wwv_flow_imp.id(450105213171276940)

,p_template_types=>'FIELD'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415716966910277221)

,p_theme_id=>42

,p_name=>'STRETCH_FORM_ITEM'

,p_display_name=>'Stretch Form Item'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--stretchInputs'

,p_template_types=>'FIELD'

,p_help_text=>'Stretches the form item to fill its container.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415717099269277221)

,p_theme_id=>42

,p_name=>'HIDE_PASSWORD_VISIBILITY'

,p_display_name=>'Hide Password Visibility'

,p_display_sequence=>1

,p_css_classes=>'js-hidePasswordVisibility'

,p_template_types=>'FIELD'

,p_help_text=>'This option hides the password visibility toggle button for the password item type.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415717143164277221)

,p_theme_id=>42

,p_name=>'ITEM_SLIM_PADDING'

,p_display_name=>'Slim'

,p_display_sequence=>10

,p_css_classes=>'t-Form-fieldContainer--slimPadding'

,p_group_id=>wwv_flow_imp.id(450104703441276940)

,p_template_types=>'FIELD'

,p_help_text=>'Reduces item spacing.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415717222780277221)

,p_theme_id=>42

,p_name=>'ITEM_REMOVE_PADDING'

,p_display_name=>'None'

,p_display_sequence=>20

,p_css_classes=>'t-Form-fieldContainer--noPadding'

,p_group_id=>wwv_flow_imp.id(450104703441276940)

,p_template_types=>'FIELD'

,p_help_text=>'Removes item spacing.'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415717361589277221)

,p_theme_id=>42

,p_name=>'SORT_CENTER'

,p_display_name=>'Center'

,p_display_sequence=>10

,p_css_classes=>'t-Region-orderBy--center'

,p_group_id=>wwv_flow_imp.id(450111476818276943)

,p_template_types=>'REGION'

);

wwv_flow_imp_shared.create_template_option(

 p_id=>wwv_flow_imp.id(415717497646277221)

,p_theme_id=>42

,p_name=>'SORT_END'

,p_display_name=>'End'

,p_display_sequence=>20

,p_css_classes=>'t-Region-orderBy--end'

,p_group_id=>wwv_flow_imp.id(450111476818276943)

,p_template_types=>'REGION'

);

wwv_flow_imp.component_end;

end;

/

