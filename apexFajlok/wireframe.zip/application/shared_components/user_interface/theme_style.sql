prompt --application/shared_components/user_interface/theme_style

begin

--   Manifest

--     THEME STYLE: 200

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_theme_style(

 p_id=>wwv_flow_imp.id(415708668003277211)

,p_theme_id=>42

,p_is_current=>false

,p_name=>'Redwood Light'

,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(

'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',

'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))

,p_is_public=>true

,p_is_accessible=>false

,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'

,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'

,p_theme_roller_read_only=>true

,p_reference_id=>2613472541943458133

);

wwv_flow_imp_shared.create_theme_style(

 p_id=>wwv_flow_imp.id(415708773136277212)

,p_theme_id=>42

,p_is_current=>false

,p_name=>'Vita'

,p_is_public=>true

,p_is_accessible=>true

,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'

,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'

,p_theme_roller_read_only=>true

,p_reference_id=>2736921419689987137

);

wwv_flow_imp_shared.create_theme_style(

 p_id=>wwv_flow_imp.id(415708862717277212)

,p_theme_id=>42

,p_is_current=>false

,p_name=>'Vita - Slate'

,p_is_public=>true

,p_is_accessible=>false

,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'

,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'

,p_theme_roller_read_only=>true

,p_reference_id=>3309029453101587610

);

wwv_flow_imp_shared.create_theme_style(

 p_id=>wwv_flow_imp.id(415708946632277212)

,p_theme_id=>42

,p_is_current=>false

,p_name=>'Vita - Dark'

,p_is_public=>true

,p_is_accessible=>false

,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'

,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'

,p_theme_roller_read_only=>true

,p_reference_id=>3560394517133712294

);

wwv_flow_imp_shared.create_theme_style(

 p_id=>wwv_flow_imp.id(415709025193277212)

,p_theme_id=>42

,p_is_current=>false

,p_name=>'Vita - Red'

,p_is_public=>true

,p_is_accessible=>false

,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'

,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'

,p_theme_roller_read_only=>true

,p_reference_id=>1955503817542310817

);





wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(415709100000277213)
,p_theme_id=>42
,p_name=>'NAV Forms2APEX'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Roboto+Mono:wght@400;500&display=swap',
'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#',
'#APP_FILES#theme.css'))
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_read_only=>false
,p_theme_roller_config=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{"classes": [], "vars": {}, "customCSS": "/* ============================================================\n   1. TYPOGRAPHY\n   ============================================================ */\n\n:root {\n  /* Font families */\n  --app-fontText: ''Inter'', ''Roboto'', -apple-system, BlinkMacSystemFont, ''Segoe UI'', sans-serif;\n  --app-fontMono: ''Roboto Mono'', ''Consolas'', ''Courier New'', monospace;\n\n  /* NAV Showcase action colors */\n  --app-colorSave: #2e7d32;\n  --app-colorSaveHover: #1b5e20;\n  --app-colorSaveBg: #e8f5e9;\n  --app-colorDelete: #c62828;\n  --app-colorDeleteHover: #b71c1c;\n  --app-colorDeleteBg: #ffebee;\n  --app-colorPrimary: #1565c0;\n  --app-colorPrimaryHover: #0d47a1;\n  --app-colorPrimaryBg: #e3f2fd;\n  --app-colorEdit: #e65100;\n  --app-colorEditHover: #bf360c;\n  --app-colorSearch: #1565c0;\n  --app-colorConfirm: #2e7d32;\n  --app-colorExport: #4a148c;\n  --app-colorExportHover: #311b92;\n  --app-colorUpload: #00695c;\n  --app-colorRefresh: #0277bd;\n\n  /* Semantic colors */\n  --app-colorError: #c62828;\n  --app-colorErrorBg: #ffebee;\n  --app-colorErrorBorder: #ef5350;\n  --app-colorWarning: #e65100;\n  --app-colorWarningBg: #fff3e0;\n  --app-colorInfo: #1565c0;\n  --app-colorInfoBg: #e3f2fd;\n  --app-colorSuccess: #2e7d32;\n  --app-colorSuccessBg: #e8f5e9;\n\n  /* Field colors */\n  --app-fieldBgEditable: #ffffff;\n  --app-fieldBgReadonly: #f5f5f5;\n  --app-fieldBgDisabled: #eeeeee;\n  --app-fieldBorder: #bdbdbd;\n  --app-fieldBorderFocus: #1565c0;\n  --app-fieldBorderError: #ef5350;\n  --app-labelRequired: #c62828;\n\n  /* Table colors */\n  --app-tableHeaderBg: #f5f5f5;\n  --app-tableHeaderText: #424242;\n  --app-tableRowAlt: #fafafa;\n  --app-tableRowHover: #e3f2fd;\n  --app-tableCellActive: #1565c0;\n  --app-tableCellError: #ef5350;\n  --app-tableFooterBg: #e0e0e0;\n}\n\n/* Base font */\nbody,\n.t-Body,\n.t-PageBody {\n  font-family: var(--app-fontText);\n}\n\n/* ============================================================\n',
'   2. FORM FIELDS\n   ============================================================ */\n\n/* Floating labels — ensure labels above fields */\n.t-Form-fieldContainer .t-Form-label {\n  font-family: var(--app-fontText);\n  font-weight: 500;\n  font-size: 0.8125rem;\n}\n\n/* Required field labels — red */\n.t-Form-fieldContainer.is-required .t-Form-label,\n.t-Form-fieldContainer .t-Form-label.is-required {\n  color: var(--app-labelRequired);\n}\n\n/* Editable inputs — white background for visual depth */\n.t-Form-fieldContainer input[type=\"text\"],\n.t-Form-fieldContainer input[type=\"number\"],\n.t-Form-fieldContainer input[type=\"password\"],\n.t-Form-fieldContainer input[type=\"email\"],\n.t-Form-fieldContainer input[type=\"tel\"],\n.t-Form-fieldContainer input[type=\"search\"],\n.t-Form-fieldContainer textarea,\n.t-Form-fieldContainer select,\n.apex-item-text,\n.apex-item-select,\n.apex-item-textarea {\n  background-color: var(--app-fieldBgEditable);\n  font-family: var(--app-fontText);\n}\n\n/* Read-only / Display Only — grey background */\n.t-Form-fieldContainer--readOnly input,\n.t-Form-fieldContainer--readOnly textarea,\n.t-Form-fieldContainer--readOnly select,\n.display_only,\n.apex-item-display-only,\ninput[readonly],\ntextarea[readonly] {\n  background-color: var(--app-fieldBgReadonly) !important;\n  color: #616161;\n}\n\n/* Disabled fields — muted grey */\n.t-Form-fieldContainer input:disabled,\n.t-Form-fieldContainer textarea:disabled,\n.t-Form-fieldContainer select:disabled,\ninput:disabled,\ntextarea:disabled,\nselect:disabled {\n  background-color: var(--app-fieldBgDisabled) !important;\n  color: #9e9e9e;\n  cursor: not-allowed;\n}\n\n/* Error state — red border + red label */\n.t-Form-fieldContainer.has-error input,\n.t-Form-fieldContainer.has-error textarea,\n.t-Form-fieldContainer.has-error select,\n.apex-page-item-error {\n  border-color: var(--app-fieldBorderError) !important;\n}\n\n.t-Form-fieldContainer.has-error .t-Form-label {\n  color: var(--a',
'pp-colorError);\n}\n\n.t-Form-fieldContainer .t-Form-error {\n  color: var(--app-colorError);\n  font-size: 0.75rem;\n}\n\n/* Focus state */\n.t-Form-fieldContainer input:focus,\n.t-Form-fieldContainer textarea:focus,\n.t-Form-fieldContainer select:focus {\n  border-color: var(--app-fieldBorderFocus);\n  box-shadow: 0 0 0 1px var(--app-fieldBorderFocus);\n}\n\n/* Auto-style by APEX item type */\n.apex-item-number {\n  font-family: var(--app-fontMono);\n  text-align: right;\n}\n\n.apex-item-datepicker {\n  font-family: var(--app-fontMono);\n  text-align: center;\n}\n\n/* Semantic classes — for text fields that need type-specific styling */\n.app-amount {                         /* ár, összeg — right-aligned, monospace, thousands grouping */\n  font-family: var(--app-fontMono);\n  text-align: right;\n}\n\n.app-date {                           /* dátum — centered, monospace */\n  font-family: var(--app-fontMono);\n  text-align: center;\n}\n\n.app-code {                           /* azonosító, adószám, iktatószám — monospace */\n  font-family: var(--app-fontMono);\n}\n\n.app-count {                          /* darabszám, eltelt napok — right-aligned, monospace */\n  font-family: var(--app-fontMono);\n  text-align: right;\n}\n\n/* Field groups — boxed variant */\n.app-fieldGroup {\n  border: 1px solid #e0e0e0;\n  border-radius: 4px;\n  padding: 1rem;\n  margin-bottom: 1rem;\n}\n\n.app-fieldGroupTitle {\n  font-weight: 600;\n  font-size: 0.875rem;\n  color: #424242;\n  margin-bottom: 0.75rem;\n}\n\n/* ============================================================\n   3. BUTTONS — NAV Showcase function colors\n   ============================================================ */\n\n/* Button groups — right-aligned */\n.t-ButtonRegion-buttons,\n.app-btnGroup {\n  justify-content: flex-end;\n}\n\n/* --- Save / Accept (green) --- */\n.app-btnSave,\n.t-Button.app-btnSave {\n  background-color: var(--app-colorSave) !important;\n  border-color: var(--app-colorSave) !important;\n  col',
'or: #fff !important;\n}\n.app-btnSave:hover,\n.t-Button.app-btnSave:hover {\n  background-color: var(--app-colorSaveHover) !important;\n  border-color: var(--app-colorSaveHover) !important;\n}\n\n/* --- Confirm (green) --- */\n.app-btnConfirm,\n.t-Button.app-btnConfirm {\n  background-color: var(--app-colorConfirm) !important;\n  border-color: var(--app-colorConfirm) !important;\n  color: #fff !important;\n}\n.app-btnConfirm:hover,\n.t-Button.app-btnConfirm:hover {\n  background-color: var(--app-colorSaveHover) !important;\n  border-color: var(--app-colorSaveHover) !important;\n}\n\n/* --- Delete (red) --- */\n.app-btnDelete,\n.t-Button.app-btnDelete {\n  background-color: var(--app-colorDelete) !important;\n  border-color: var(--app-colorDelete) !important;\n  color: #fff !important;\n}\n.app-btnDelete:hover,\n.t-Button.app-btnDelete:hover {\n  background-color: var(--app-colorDeleteHover) !important;\n  border-color: var(--app-colorDeleteHover) !important;\n}\n\n/* --- Edit (orange) --- */\n.app-btnEdit,\n.t-Button.app-btnEdit {\n  background-color: var(--app-colorEdit) !important;\n  border-color: var(--app-colorEdit) !important;\n  color: #fff !important;\n}\n.app-btnEdit:hover,\n.t-Button.app-btnEdit:hover {\n  background-color: var(--app-colorEditHover) !important;\n  border-color: var(--app-colorEditHover) !important;\n}\n\n/* --- Search / Primary (blue) --- */\n.app-btnSearch,\n.app-btnPrimary,\n.t-Button.app-btnSearch,\n.t-Button.app-btnPrimary {\n  background-color: var(--app-colorPrimary) !important;\n  border-color: var(--app-colorPrimary) !important;\n  color: #fff !important;\n}\n.app-btnSearch:hover,\n.app-btnPrimary:hover,\n.t-Button.app-btnSearch:hover,\n.t-Button.app-btnPrimary:hover {\n  background-color: var(--app-colorPrimaryHover) !important;\n  border-color: var(--app-colorPrimaryHover) !important;\n}\n\n/* --- Export (purple) --- */\n.app-btnExport,\n.t-Button.app-btnExport {\n  background-color: var(--app-colorExport) !important;\n  border-c',
'olor: var(--app-colorExport) !important;\n  color: #fff !important;\n}\n.app-btnExport:hover,\n.t-Button.app-btnExport:hover {\n  background-color: var(--app-colorExportHover) !important;\n  border-color: var(--app-colorExportHover) !important;\n}\n\n/* --- Upload (teal) --- */\n.app-btnUpload,\n.t-Button.app-btnUpload {\n  background-color: var(--app-colorUpload) !important;\n  border-color: var(--app-colorUpload) !important;\n  color: #fff !important;\n}\n\n/* --- Refresh (light blue) --- */\n.app-btnRefresh,\n.t-Button.app-btnRefresh {\n  background-color: var(--app-colorRefresh) !important;\n  border-color: var(--app-colorRefresh) !important;\n  color: #fff !important;\n}\n\n/* --- Close / Technical close (dark grey) --- */\n.app-btnClose,\n.t-Button.app-btnClose {\n  background-color: #616161 !important;\n  border-color: #616161 !important;\n  color: #fff !important;\n}\n\n/* --- Reject (red, same as delete) --- */\n.app-btnReject,\n.t-Button.app-btnReject {\n  background-color: var(--app-colorDelete) !important;\n  border-color: var(--app-colorDelete) !important;\n  color: #fff !important;\n}\n\n/* --- Check / Verify (blue) --- */\n.app-btnCheck,\n.t-Button.app-btnCheck {\n  background-color: var(--app-colorPrimary) !important;\n  border-color: var(--app-colorPrimary) !important;\n  color: #fff !important;\n}\n\n/* --- Cancel (default grey) --- */\n.app-btnCancel,\n.t-Button.app-btnCancel {\n  background-color: #f5f5f5 !important;\n  border-color: #bdbdbd !important;\n  color: #424242;\n}\n.app-btnCancel:hover,\n.t-Button.app-btnCancel:hover {\n  background-color: #e0e0e0 !important;\n}\n\n/* --- Register / Iktatás (blue) --- */\n.app-btnRegister,\n.t-Button.app-btnRegister {\n  background-color: var(--app-colorPrimary) !important;\n  border-color: var(--app-colorPrimary) !important;\n  color: #fff !important;\n}\n\n/* Disabled buttons — faded */\n.t-Button:disabled,\n.t-Button[disabled],\n.t-Button.is-disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n',
'/* ============================================================\n   4. TABLES — IR / IG\n   ============================================================ */\n\n/* Alternating rows */\n.t-Report-report tbody tr:nth-child(even),\n.a-IRR-table tbody tr:nth-child(even),\n.a-GV-table tbody tr:nth-child(even) {\n  background-color: var(--app-tableRowAlt);\n}\n\n/* Row hover — light blue */\n.t-Report-report tbody tr:hover,\n.a-IRR-table tbody tr:hover,\n.a-GV-table tbody tr:hover {\n  background-color: var(--app-tableRowHover);\n}\n\n/* Table header */\n.t-Report-report thead th,\n.a-IRR-table thead th,\n.a-GV-table .a-GV-header .a-GV-headerCell {\n  background-color: var(--app-tableHeaderBg);\n  color: var(--app-tableHeaderText);\n  font-weight: 600;\n  text-align: center;\n  font-family: var(--app-fontText);\n}\n\n/* Sortable header — blue on hover */\n.a-IRR-table thead th.a-IRR-header--sortable:hover,\n.a-GV-table .a-GV-headerCell:hover {\n  color: var(--app-colorPrimary);\n}\n\n/* Number columns — right-aligned, monospace */\n.app-colNumber,\ntd.app-colNumber,\n.a-GV-cell.app-colNumber {\n  text-align: right;\n  font-family: var(--app-fontMono);\n}\n\n/* Date columns — centered, monospace */\n.app-colDate,\ntd.app-colDate,\n.a-GV-cell.app-colDate {\n  text-align: center;\n  font-family: var(--app-fontMono);\n}\n\n/* Icon columns — centered */\n.app-colIcon,\ntd.app-colIcon,\n.a-GV-cell.app-colIcon {\n  text-align: center;\n}\n\n/* IG active cell — blue border */\n.a-GV-cell.is-active,\n.a-GV-cell.is-focused {\n  outline: 2px solid var(--app-tableCellActive);\n  outline-offset: -2px;\n}\n\n/* IG error cell — red border */\n.a-GV-cell.has-error,\n.a-GV-cell.is-error {\n  outline: 2px solid var(--app-tableCellError);\n  outline-offset: -2px;\n}\n\n/* Table footer / summary */\n.t-Report-report tfoot td,\n.a-GV-table .a-GV-footer {\n  background-color: var(--app-tableFooterBg);\n  font-weight: 600;\n}\n\n/* ============================================================\n   ',
'5. TABS\n   ============================================================ */\n\n/* Tab \"Mindent mutat\" — no special styling needed, it shows all regions stacked.\n   APEX Display Selector with \"Show All\" option handles this natively. */\n\n/* ============================================================\n   6. MESSAGES / ALERTS — NAV Showcase colored\n   ============================================================ */\n\n/* Success message */\n.t-Alert--success .t-Alert-header,\n.t-Alert--success.t-Alert--colorBG {\n  background-color: var(--app-colorSuccessBg);\n}\n.t-Alert--success .t-Alert-icon .t-Icon {\n  color: var(--app-colorSuccess);\n}\n\n/* Error / Danger message */\n.t-Alert--danger .t-Alert-header,\n.t-Alert--danger.t-Alert--colorBG {\n  background-color: var(--app-colorErrorBg);\n}\n.t-Alert--danger .t-Alert-icon .t-Icon {\n  color: var(--app-colorError);\n}\n\n/* Warning message */\n.t-Alert--warning .t-Alert-header,\n.t-Alert--warning.t-Alert--colorBG {\n  background-color: var(--app-colorWarningBg);\n}\n.t-Alert--warning .t-Alert-icon .t-Icon {\n  color: var(--app-colorWarning);\n}\n\n/* Info message */\n.t-Alert--info .t-Alert-header,\n.t-Alert--info.t-Alert--colorBG {\n  background-color: var(--app-colorInfoBg);\n}\n.t-Alert--info .t-Alert-icon .t-Icon {\n  color: var(--app-colorInfo);\n}\n\n/* ============================================================\n   7. UTILITY CLASSES\n   ============================================================ */\n\n/* Monospace text */\n.app-mono {\n  font-family: var(--app-fontMono);\n}\n\n/* Right-aligned text */\n.app-right {\n  text-align: right;\n}\n\n/* Centered text */\n.app-center {\n  text-align: center;\n}\n\n/* Hungarian amount formatting helper (applied via class) */\n.app-amountDisplay {\n  font-family: var(--app-fontMono);\n  text-align: right;\n  white-space: nowrap;\n}\n\n/* ============================================================\n   8. SHOWCASE LAYOUT HELPERS\n   ===============================',
'============================= */\n\n/* Navigation cards (used with APEX 12-column grid: .row > .col.col-4) */\na.app-card {\n  display: block;\n  text-decoration: none;\n  padding: 1.5rem;\n  border: 1px solid #e0e0e0;\n  border-radius: 8px;\n  text-align: center;\n  transition: box-shadow 0.15s;\n}\n\na.app-card:hover {\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);\n}\n\n.app-card-grid .app-cardIcon {\n  font-size: 2rem;\n  display: block;\n  margin-bottom: 0.5rem;\n}\n\n.app-card-grid .app-cardTitle {\n  font-weight: 600;\n  font-size: 0.9375rem;\n  margin-bottom: 0.25rem;\n  color: #212121;\n}\n\n.app-card-grid .app-cardDesc {\n  color: #757575;\n  font-size: 0.8125rem;\n}\n\n/* Color swatch in reference tables */\n.app-swatch {\n  display: inline-block;\n  width: 3rem;\n  height: 1.25rem;\n  border-radius: 3px;\n  vertical-align: middle;\n}\n\n/* Unmapped element warning (for mockups/development) */\n.app-unmapped {\n  border: 2px dashed #ffa000 !important;\n  position: relative;\n}\n.app-unmapped::after {\n  content: ''UNMAPPED'';\n  position: absolute;\n  top: -0.5rem;\n  right: 0.25rem;\n  font-size: 0.625rem;\n  font-weight: 700;\n  color: #e65100;\n  background: #fff8e1;\n  padding: 0 0.25rem;\n  border-radius: 2px;\n}", "useCustomLess": "N"}'))
);

wwv_flow_imp.component_end;

end;

/

