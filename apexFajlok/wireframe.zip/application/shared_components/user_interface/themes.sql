prompt --application/shared_components/user_interface/themes

begin

--   Manifest

--     THEME: 200

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(450103133223276939)

,p_theme_id=>42

,p_theme_name=>'Universal Theme'

,p_theme_internal_name=>'UNIVERSAL_THEME'

,p_navigation_type=>'L'

,p_nav_bar_type=>'LIST'

,p_reference_id=>4087963239531451994

,p_is_locked=>false

,p_default_page_template=>wwv_flow_imp.id(450118183428276947)

,p_default_dialog_template=>wwv_flow_imp.id(450121884387276949)

,p_error_template=>wwv_flow_imp.id(450122427938276949)

,p_printer_friendly_template=>wwv_flow_imp.id(450118183428276947)

,p_login_template=>wwv_flow_imp.id(450122427938276949)

,p_default_button_template=>wwv_flow_imp.id(450184957065277003)

,p_default_region_template=>wwv_flow_imp.id(450130417347276955)

,p_default_chart_template=>wwv_flow_imp.id(450130417347276955)

,p_default_form_template=>wwv_flow_imp.id(450130417347276955)

,p_default_reportr_template=>wwv_flow_imp.id(450130417347276955)

,p_default_tabform_template=>wwv_flow_imp.id(450130417347276955)

,p_default_wizard_template=>wwv_flow_imp.id(450130417347276955)

,p_default_menur_template=>wwv_flow_imp.id(450151473035276970)

,p_default_listr_template=>wwv_flow_imp.id(450130417347276955)

,p_default_irr_template=>wwv_flow_imp.id(450146394097276967)

,p_default_report_template=>wwv_flow_imp.id(450163518385276981)

,p_default_label_template=>wwv_flow_imp.id(450183366684277001)

,p_default_menu_template=>wwv_flow_imp.id(450185743325277003)

,p_default_calendar_template=>wwv_flow_imp.id(450185863735277003)

,p_default_list_template=>wwv_flow_imp.id(450182025754276999)

,p_default_nav_list_template=>wwv_flow_imp.id(450177091870276994)

,p_default_top_nav_list_temp=>wwv_flow_imp.id(450177091870276994)

,p_default_side_nav_list_temp=>wwv_flow_imp.id(450177583652276995)

,p_default_nav_list_position=>'SIDE'

,p_default_dialogbtnr_template=>wwv_flow_imp.id(450148253115276968)

,p_default_dialogr_template=>wwv_flow_imp.id(450134743187276959)

,p_default_option_label=>wwv_flow_imp.id(450183366684277001)

,p_default_required_label=>wwv_flow_imp.id(450183409494277001)

,p_default_navbar_list_template=>wwv_flow_imp.id(450178304573276995)

,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.1/')

,p_files_version=>64

,p_icon_library=>'FONTAPEX'

,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(

'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',

'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))

,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'

);

wwv_flow_imp.component_end;

end;

/

