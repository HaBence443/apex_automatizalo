prompt --application/shared_components/user_interface/templates/list/tabs

begin

--   Manifest

--     REGION TEMPLATE: TABS

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_list_template(

 p_id=>wwv_flow_imp.id(450180939701276998)

,p_list_template_current=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<li class="t-Tabs-item is-active #A03#" aria-current="page" id="#A01#">',

'  <a href="#LINK#" class="t-Tabs-link #A04#" data-otel-label="#A10#">',

'    <span class="t-Icon #ICON_CSS_CLASSES#" aria-hidden="true"></span>',

'    <span class="t-Tabs-label">#TEXT#</span>',

'  </a>',

'</li>'))

,p_list_template_noncurrent=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<li class="t-Tabs-item #A03#" id="#A01#">',

'  <a href="#LINK#" class="t-Tabs-link #A04#" data-otel-label="#A10#">',

'    <span class="t-Icon #ICON_CSS_CLASSES#" aria-hidden="true"></span>',

'    <span class="t-Tabs-label">#TEXT#</span>',

'  </a>',

'</li>'))

,p_list_template_name=>'Tabs'

,p_internal_name=>'TABS'

,p_javascript_file_urls=>'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.apexTabs#MIN#.js?v=#APEX_VERSION#'

,p_theme_id=>42

,p_theme_class_id=>7

,p_preset_template_options=>'t-Tabs--simple'

,p_list_template_before_rows=>'<ul class="t-Tabs #COMPONENT_CSS_CLASSES#">'

,p_list_template_after_rows=>'</ul>'

,p_a01_label=>'List Item ID'

,p_a03_label=>'List Item Class'

,p_a04_label=>'Link Class'

,p_a10_label=>'OpenTelemetry Label'

,p_reference_id=>3305252791810202641

);

wwv_flow_imp.component_end;

end;

/

