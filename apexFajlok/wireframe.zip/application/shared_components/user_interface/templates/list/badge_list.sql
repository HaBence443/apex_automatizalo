prompt --application/shared_components/user_interface/templates/list/badge_list

begin

--   Manifest

--     REGION TEMPLATE: BADGE_LIST

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_list_template(

 p_id=>wwv_flow_imp.id(450174026884276991)

,p_list_template_current=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<li class="t-BadgeList-item #A02# is-current" aria-current="page">',

'  <a class="t-BadgeList-wrap u-color #A04#" href="#LINK#" #A03# data-otel-label="#A10#">',

'    <span class="t-BadgeList-label">#TEXT#</span>',

'    <span class="t-BadgeList-value">#A01#</span>',

'  </a>',

'</li>',

''))

,p_list_template_noncurrent=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<li class="t-BadgeList-item #A02#">',

'  <a class="t-BadgeList-wrap u-color #A04#" href="#LINK#" #A03# data-otel-label="#A10#">',

'    <span class="t-BadgeList-label">#TEXT#</span>',

'    <span class="t-BadgeList-value">#A01#</span>',

'  </a>',

'</li>',

''))

,p_list_template_name=>'Badge List'

,p_internal_name=>'BADGE_LIST'

,p_theme_id=>42

,p_theme_class_id=>3

,p_preset_template_options=>'t-BadgeList--circular:t-BadgeList--cols t-BadgeList--3cols:t-BadgeList--large'

,p_list_template_before_rows=>'<ul class="t-BadgeList #COMPONENT_CSS_CLASSES#">'

,p_list_template_after_rows=>'</ul>'

,p_a01_label=>'Value'

,p_a02_label=>'List item CSS Classes'

,p_a03_label=>'Link Attributes'

,p_a04_label=>'Link Classes'

,p_a10_label=>'OpenTelemetry Label'

,p_reference_id=>2079528952386479308

,p_list_template_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(

'A01: Large Number',

'A02: List Item Classes',

'A03: Link Attributes'))

);

wwv_flow_imp.component_end;

end;

/

