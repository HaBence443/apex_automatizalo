prompt --application/shared_components/user_interface/templates/region/inline_drawer

begin

--   Manifest

--     REGION TEMPLATE: INLINE_DRAWER

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_plug_template(

 p_id=>wwv_flow_imp.id(450139427103276962)

,p_layout=>'TABLE'

,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<div id="#REGION_STATIC_ID#_parent">',

'  <div id="#REGION_STATIC_ID#" class="t-DrawerRegion js-dialog-class-ui-dialog--drawer #REGION_CSS_CLASSES# js-regionDialog" #REGION_LANDMARK_ATTRIBUTES# #REGION_ATTRIBUTES# #APEX_CSP_DISPLAY_NONE# title="#TITLE!ATTR#">',

'    <div class="t-DrawerRegion-wrap">',

'      <div class="t-DrawerRegion-bodyWrapperOut">',

'        <div class="t-DrawerRegion-bodyWrapperIn">',

'          <div class="t-DrawerRegion-body">#BODY##SUB_REGIONS#</div>',

'        </div>',

'      </div>',

'      <div class="t-DrawerRegion-buttons">',

'        <div class="t-ButtonRegion t-ButtonRegion--dialogRegion">',

'          <div class="t-ButtonRegion-wrap">',

'            <div class="t-ButtonRegion-col t-ButtonRegion-col--left">',

'              <div class="t-ButtonRegion-buttons">#PREVIOUS##DELETE##CLOSE#</div>',

'            </div>',

'            <div class="t-ButtonRegion-col t-ButtonRegion-col--right">',

'              <div class="t-ButtonRegion-buttons">#EDIT##CREATE##NEXT#</div>',

'            </div>',

'          </div>',

'        </div>',

'      </div>',

'    </div>',

'  </div>',

'</div>'))

,p_page_plug_template_name=>'Inline Drawer'

,p_internal_name=>'INLINE_DRAWER'

,p_theme_id=>42

,p_theme_class_id=>24

,p_default_template_options=>'js-modal'

,p_preset_template_options=>'js-dialog-class-t-Drawer--pullOutEnd'

,p_default_label_alignment=>'RIGHT'

,p_default_field_alignment=>'LEFT'

,p_reference_id=>1676572438765902030

,p_translate_this_template=>'N'

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450139552876276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Region Body'

,p_placeholder=>'BODY'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450139674226276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Close'

,p_placeholder=>'CLOSE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450139755408276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Create'

,p_placeholder=>'CREATE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450139869768276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Delete'

,p_placeholder=>'DELETE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450139950687276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Edit'

,p_placeholder=>'EDIT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450140080646276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Next'

,p_placeholder=>'NEXT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450140169668276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Previous'

,p_placeholder=>'PREVIOUS'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450140282758276962)

,p_plug_template_id=>wwv_flow_imp.id(450139427103276962)

,p_name=>'Sub Regions'

,p_placeholder=>'SUB_REGIONS'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>false

,p_has_button_support=>false

,p_glv_new_row=>true

);

wwv_flow_imp.component_end;

end;

/

