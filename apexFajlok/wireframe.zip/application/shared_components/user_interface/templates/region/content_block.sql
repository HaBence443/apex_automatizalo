prompt --application/shared_components/user_interface/templates/region/content_block

begin

--   Manifest

--     REGION TEMPLATE: CONTENT_BLOCK

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_plug_template(
 p_id=>wwv_flow_imp.id(450149724285276969)

,p_layout=>'TABLE'

,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<div class="t-ContentBlock #REGION_CSS_CLASSES#" id="#REGION_STATIC_ID#" #REGION_LANDMARK_ATTRIBUTES# #REGION_ATTRIBUTES#>',

'  <div class="t-ContentBlock-header">',

'    <div class="t-ContentBlock-headerItems t-ContentBlock-headerItems--title">',

'      <span class="t-ContentBlock-headerIcon"><span class="t-Icon #ICON_CSS_CLASSES#" aria-hidden="true"></span></span>',

'      <h2 class="t-ContentBlock-title" id="#REGION_STATIC_ID#_heading" data-apex-heading>#TITLE#</h2>',

'      #EDIT#',

'    </div>',

'    <div class="t-ContentBlock-headerItems t-ContentBlock-headerItems--buttons">#CHANGE#</div>',

'  </div>',

'  <div class="t-ContentBlock-body">#BODY##SUB_REGIONS#</div>',

'  <div class="t-ContentBlock-buttons">#PREVIOUS##NEXT#</div>',

'</div>',

''))

,p_page_plug_template_name=>'Content Block'

,p_internal_name=>'CONTENT_BLOCK'

,p_theme_id=>42

,p_theme_class_id=>21

,p_preset_template_options=>'t-ContentBlock--h1'

,p_default_label_alignment=>'RIGHT'

,p_default_field_alignment=>'LEFT'


,p_reference_id=>2337714969857234818

,p_translate_this_template=>'N'

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(450149824471276969)

,p_plug_template_id=>wwv_flow_imp.id(450149724285276969)

,p_name=>'Region Body'

,p_placeholder=>'BODY'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(450149965163276969)

,p_plug_template_id=>wwv_flow_imp.id(450149724285276969)

,p_name=>'Change'

,p_placeholder=>'CHANGE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(450150061028276969)

,p_plug_template_id=>wwv_flow_imp.id(450149724285276969)

,p_name=>'Edit'

,p_placeholder=>'EDIT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(450150121782276969)

,p_plug_template_id=>wwv_flow_imp.id(450149724285276969)

,p_name=>'Next'

,p_placeholder=>'NEXT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(450150212294276969)

,p_plug_template_id=>wwv_flow_imp.id(450149724285276969)

,p_name=>'Previous'

,p_placeholder=>'PREVIOUS'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(450150397890276969)

,p_plug_template_id=>wwv_flow_imp.id(450149724285276969)

,p_name=>'Sub Regions'

,p_placeholder=>'SUB_REGIONS'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>false

,p_has_button_support=>false

,p_glv_new_row=>true

);

wwv_flow_imp.component_end;

end;

/

