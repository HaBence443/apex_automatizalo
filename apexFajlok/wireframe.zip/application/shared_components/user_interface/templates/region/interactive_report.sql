prompt --application/shared_components/user_interface/templates/region/interactive_report

begin

--   Manifest

--     REGION TEMPLATE: INTERACTIVE_REPORT

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_plug_template(

 p_id=>wwv_flow_imp.id(450146394097276967)

,p_layout=>'TABLE'

,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<div id="#REGION_STATIC_ID#" #REGION_LANDMARK_ATTRIBUTES# #REGION_ATTRIBUTES# class="t-IRR-region #REGION_CSS_CLASSES#">',

'  <h2 class="t-IRR-title" id="#REGION_STATIC_ID#_heading" data-apex-heading>#TITLE#</h2>',

'    <div class="t-Region-orderBy">#ORDER_BY_ITEM#</div>',

'    #PREVIOUS#',

'    #BODY#',

'    #SUB_REGIONS#',

'    #NEXT#',

'</div>',

'',

''))

,p_page_plug_template_name=>'Interactive Report'

,p_internal_name=>'INTERACTIVE_REPORT'

,p_theme_id=>42

,p_theme_class_id=>9

,p_preset_template_options=>'t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'

,p_default_label_alignment=>'RIGHT'

,p_default_field_alignment=>'LEFT'


,p_reference_id=>2116125943337183254

,p_translate_this_template=>'N'

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450146401444276967)

,p_plug_template_id=>wwv_flow_imp.id(450146394097276967)

,p_name=>'Region Body'

,p_placeholder=>'BODY'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450146568365276967)

,p_plug_template_id=>wwv_flow_imp.id(450146394097276967)

,p_name=>'Next'

,p_placeholder=>'NEXT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450146649659276967)

,p_plug_template_id=>wwv_flow_imp.id(450146394097276967)

,p_name=>'Sort Order'

,p_placeholder=>'ORDER_BY_ITEM'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450146769111276967)

,p_plug_template_id=>wwv_flow_imp.id(450146394097276967)

,p_name=>'Previous'

,p_placeholder=>'PREVIOUS'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450146898874276967)

,p_plug_template_id=>wwv_flow_imp.id(450146394097276967)

,p_name=>'Sub Regions'

,p_placeholder=>'SUB_REGIONS'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>false

,p_has_button_support=>false

,p_glv_new_row=>true

);

wwv_flow_imp.component_end;

end;

/

