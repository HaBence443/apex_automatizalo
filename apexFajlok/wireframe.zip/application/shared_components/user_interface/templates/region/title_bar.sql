prompt --application/shared_components/user_interface/templates/region/title_bar

begin

--   Manifest

--     REGION TEMPLATE: TITLE_BAR

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_plug_template(

 p_id=>wwv_flow_imp.id(450151473035276970)

,p_layout=>'TABLE'

,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(

'<nav id="#REGION_STATIC_ID#" #REGION_LANDMARK_ATTRIBUTES# #REGION_ATTRIBUTES# class="t-BreadcrumbRegion #REGION_CSS_CLASSES#">',

'  <div class="t-BreadcrumbRegion-top">',

'    <div class="t-BreadcrumbRegion-buttons t-BreadcrumbRegion-buttons--start">#UP#</div>',

'    <div class="t-BreadcrumbRegion-body">',

'      <div class="t-BreadcrumbRegion-breadcrumb">#BODY#</div>',

'        <div class="t-BreadcrumbRegion-title">',

'        <h1 id="#REGION_STATIC_ID#_heading" class="t-BreadcrumbRegion-titleText" data-apex-heading>#TITLE#</h1>',

'      </div>',

'    </div>',

'    <div class="t-BreadcrumbRegion-buttons t-BreadcrumbRegion-buttons--end">#PREVIOUS##CLOSE##DELETE##HELP##CHANGE##EDIT##COPY##CREATE##NEXT#</div>',

'  </div>',

'  <div class="t-BreadcrumbRegion-bottom">#SMART_FILTERS#</div>',

'</nav>',

''))

,p_page_plug_template_name=>'Title Bar'

,p_internal_name=>'TITLE_BAR'

,p_theme_id=>42

,p_theme_class_id=>6

,p_default_template_options=>'t-BreadcrumbRegion--showBreadcrumb'

,p_preset_template_options=>'t-BreadcrumbRegion--useBreadcrumbTitle'

,p_default_label_alignment=>'RIGHT'

,p_default_field_alignment=>'LEFT'


,p_reference_id=>2547062628952524734

,p_translate_this_template=>'N'

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450151528787276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Region Body'

,p_placeholder=>'BODY'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450151624936276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Change'

,p_placeholder=>'CHANGE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450151720233276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Close'

,p_placeholder=>'CLOSE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450151877872276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Copy'

,p_placeholder=>'COPY'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450151928433276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Create'

,p_placeholder=>'CREATE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152063496276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Delete'

,p_placeholder=>'DELETE'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152168598276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Edit'

,p_placeholder=>'EDIT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152214254276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Help'

,p_placeholder=>'HELP'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152389661276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Next'

,p_placeholder=>'NEXT'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152477570276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Previous'

,p_placeholder=>'PREVIOUS'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152592598276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Search Field and Smart Filters'

,p_placeholder=>'SMART_FILTERS'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>true

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152618333276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Sub Regions'

,p_placeholder=>'SUB_REGIONS'

,p_has_grid_support=>true

,p_has_region_support=>true

,p_has_item_support=>false

,p_has_button_support=>false

,p_glv_new_row=>true

);

wwv_flow_imp_shared.create_plug_tmpl_display_point(

 p_id=>wwv_flow_imp.id(450152706020276970)

,p_plug_template_id=>wwv_flow_imp.id(450151473035276970)

,p_name=>'Up'

,p_placeholder=>'UP'

,p_has_grid_support=>false

,p_has_region_support=>false

,p_has_item_support=>false

,p_has_button_support=>true

,p_glv_new_row=>true

);

wwv_flow_imp.component_end;

end;

/

