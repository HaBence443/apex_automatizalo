prompt --application/shared_components/user_interface/templates/button/icon

begin

--   Manifest

--     BUTTON TEMPLATE: ICON

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_button_templates(

 p_id=>wwv_flow_imp.id(450184618947277002)

,p_template_name=>'Icon'

,p_internal_name=>'ICON'

,p_template=>'<button class="t-Button t-Button--noLabel  t-Button--icon #BUTTON_CSS_CLASSES#" #BUTTON_ATTRIBUTES# #ONCLICK# type="button" id="#BUTTON_ID#" title="#LABEL!ATTR#" aria-label="#LABEL!ATTR#" data-otel-label="#BUTTON_NAME!ATTR#"><span class="t-Icon #ICON'

||'_CSS_CLASSES#" aria-hidden="true"></span></button>'

,p_hot_template=>'<button class="t-Button t-Button--noLabel t-Button--icon #BUTTON_CSS_CLASSES# t-Button--hot" #BUTTON_ATTRIBUTES# #ONCLICK# type="button" id="#BUTTON_ID#" title="#LABEL!ATTR#" aria-label="#LABEL!ATTR#" data-otel-label="#BUTTON_NAME!ATTR#"><span class='

||'"t-Icon #ICON_CSS_CLASSES#" aria-hidden="true"></span></button>'

,p_reference_id=>2364707024798713902

,p_translate_this_template=>'N'

,p_theme_class_id=>5

,p_theme_id=>42

);

wwv_flow_imp.component_end;

end;

/

