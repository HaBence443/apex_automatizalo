prompt --application/shared_components/user_interface/templates/button/text

begin

--   Manifest

--     BUTTON TEMPLATE: TEXT

--   Manifest End

wwv_flow_imp.component_begin (

 p_version_yyyy_mm_dd=>'2022.04.12'

,p_release=>'22.1.0'

,p_default_workspace_id=>1471193222291710

,p_default_application_id=>300

,p_default_id_offset=>70000000000000000

,p_default_owner=>'HOTEL_APP'

);

wwv_flow_imp_shared.create_button_templates(

 p_id=>wwv_flow_imp.id(450184957065277003)

,p_template_name=>'Text'

,p_internal_name=>'TEXT'

,p_template=>'<button class="t-Button #BUTTON_CSS_CLASSES#" type="button" #BUTTON_ATTRIBUTES# #ONCLICK# id="#BUTTON_ID#" data-otel-label="#BUTTON_NAME!ATTR#"><span class="t-Button-label">#LABEL#</span></button>'

,p_hot_template=>'<button class="t-Button t-Button--hot #BUTTON_CSS_CLASSES#" type="button" #BUTTON_ATTRIBUTES# #ONCLICK# id="#BUTTON_ID#" data-otel-label="#BUTTON_NAME!ATTR#"><span class="t-Button-label">#LABEL#</span></button>'

,p_reference_id=>4087962263153451966

,p_translate_this_template=>'N'

,p_theme_class_id=>1

,p_theme_id=>42

);

wwv_flow_imp.component_end;

end;

/

