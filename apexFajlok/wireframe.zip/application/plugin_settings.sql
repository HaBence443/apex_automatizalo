prompt --application/plugin_settings

begin
null;
end;
/
