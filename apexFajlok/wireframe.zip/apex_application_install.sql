-- Override settings for deploying wireframe-FRM_ELJ0250.
-- This file is run by apex_deploy.py before install.sql.

-- Drop any other apps in this workspace that share the same alias.
-- APEX permits duplicate aliases across apps; once that happens the
-- friendly URL `/ords/r/<workspace>/<alias>/` resolves ambiguously and
-- often lands on the workspace home instead of our app. Wiping siblings
-- with the same alias before install keeps the friendly URL deterministic.
declare
  l_ws_id number;
begin
  l_ws_id := apex_util.find_security_group_id(p_workspace => 'NAV');
  apex_util.set_security_group_id(p_security_group_id => l_ws_id);
  for r in (
    select application_id
      from apex_applications
     where workspace      = 'NAV'
       and alias          = 'FRM_ELJ0250'
       and application_id <> 9300
  ) loop
    dbms_output.put_line('Removing duplicate-alias app id=' ||
                         r.application_id || ' alias=' || 'FRM_ELJ0250');
    wwv_flow_imp.remove_flow(r.application_id);
  end loop;
end;
/

begin
  apex_application_install.set_workspace('NAV');
  apex_application_install.set_application_id(9300);
  apex_application_install.generate_offset();
  apex_application_install.set_schema('NAV');
  apex_application_install.set_application_name('Határozatkészítés');
  apex_application_install.set_application_alias('FRM_ELJ0250');
end;
/
